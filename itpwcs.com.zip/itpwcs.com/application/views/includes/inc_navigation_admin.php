<div id="m_header_menu" class="m-header-menu m-aside-header-menu-mobile m-aside-header-menu-mobile--offcanvas  m-header-menu--skin-dark m-header-menu--submenu-skin-light m-aside-header-menu-mobile--skin-light m-aside-header-menu-mobile--submenu-skin-light "  >
    <ul class="m-menu__nav  m-menu__nav--submenu-arrow ">



        
    

      <li id="menu_blog" class="m-menu__item  m-menu__item--submenu m-menu__item--rel"  aria-haspopup="true">
            <a  href="<?php echo base_url().$user_directory.'blog'?>" class="m-menu__link m-menu__toggle">
                <span class="m-menu__item-here"></span>
                <span class="m-menu__link-text">
                                                    Blog
                                                </span>
            </a>
      </li>

        <li id="menu_news" class="m-menu__item  m-menu__item--submenu m-menu__item--rel"  aria-haspopup="true">
            <a  href="<?php echo base_url().$user_directory.'news'?>" class="m-menu__link m-menu__toggle">
                <span class="m-menu__item-here"></span>
                <span class="m-menu__link-text">
                                                    News
                                                </span>
            </a>

        </li>


        <li id="menu_student" class="m-menu__item  m-menu__item--submenu m-menu__item--rel"  aria-haspopup="true">
            <a  href="<?php echo base_url().$user_directory.'students'?>" class="m-menu__link m-menu__toggle">
                <span class="m-menu__item-here"></span>
                <span class="m-menu__link-text">
                                                    Students
                                                </span>
            </a>

        </li>



  
      <li id="menu_corporate" class="m-menu__item  m-menu__item--submenu m-menu__item--rel"  aria-haspopup="true">
            <a  href="<?php echo base_url().$user_directory.'corporates'?>" class="m-menu__link m-menu__toggle">
                <span class="m-menu__item-here"></span>
                <span class="m-menu__link-text">
                                                    Corporates
                                                </span>
            </a>

        </li>
        
       
        
        <li id="menu_proffesional" class="m-menu__item  m-menu__item--submenu m-menu__item--rel"  aria-haspopup="true">
            <a  href="<?php echo base_url().$user_directory.'proffesionals'?>" class="m-menu__link m-menu__toggle">
                <span class="m-menu__item-here"></span>
                <span class="m-menu__link-text">
                                                   Proffesionals
                                                </span>
            </a>

        </li>



        
       
    </ul>
</div>