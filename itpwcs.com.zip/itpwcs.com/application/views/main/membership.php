<!doctype html>
<html class="no-js" lang="en">
    <head>
        <!-- title -->
        <title>ITPWCS</title>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1" />
        <meta name="author" content=" ">
        <!-- description -->
        <meta name="description" content="ITPWCS">
        <!-- keywords -->
        <meta name="keywords" content="ITPWCS">
        <!-- favicon -->
        <link rel="shortcut icon" href="<?php echo base_url() ?>maintemp/images/favicon.png">
 
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/animate.css" />
        <!-- bootstrap -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/bootstrap.min.css" />
        <!-- et line icon --> 
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/et-line-icons.css" />
        <!-- font-awesome icon -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/font-awesome.min.css" />
        <!-- themify icon -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/themify-icons.css">
        <!-- swiper carousel -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/swiper.min.css">
        <!-- justified gallery  -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/justified-gallery.min.css">
        <!-- magnific popup -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/magnific-popup.css" />
        <!-- revolution slider -->
        <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>maintemp/revolution/css/settings.css" media="screen" />
        <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>maintemp/revolution/css/layers.css">
        <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>maintemp/revolution/css/navigation.css">
        <!-- bootsnav -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/bootsnav.css">
        <!-- style -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/style.css" />
        <!-- responsive css -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/responsive.css" />
        <!--[if IE]>
            <script src="js/html5shiv.js"></script>
        <![endif]-->
    </head>
    <body>
        

 
    <?php include 'header.php';?>




    <!-- start page title section -->
    <section class="   padding-0px-tb  top-space"></section>
    <!-- end page title section -->



 <!-- start feature box section -->
        <section class=" padding-80px-tb  new-bg  wow fadeIn"  >
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-4 col-xl-4 col-md-4  md-margin-20px-bottom sm-margin-10px-bottom text-center">
                        <a class="btn btn-small btn-white btn-rounded lg-margin-1px-bottom d-table d-lg-inline-block md-margin-lr-auto" href="#">JOIN AS STUDENT</a>
                    </div>

                    <div class="col-4 col-xl-4 col-md-4  md-margin-20px-bottom sm-margin-10px-bottom text-center">
                        <a class="btn btn-small btn-white btn-rounded lg-margin-1px-bottom d-table d-lg-inline-block md-margin-lr-auto" href="#">JOIN AS PROFESSIONAL </a>
                    </div>

                     <div class="col-4 col-xl-4 col-md-4  md-margin-20px-bottom sm-margin-10px-bottom text-center">
                        <a class="btn btn-small btn-white btn-rounded lg-margin-1px-bottom d-table d-lg-inline-block md-margin-lr-auto" href="#">JOIN AS CORPORATES</a>
                    </div>

                </div>
               
            </div>
        </section>
        <!-- start feature box section -->

        <!-- start feature box section -->
        <section class="wow fadeIn ">
            <div class="container">
                <div class="row ">

                    <div class="col-md-12 margin-two-bottom md-margin-20px-bottom sm-margin-20px-bottom ">
                        <img src="<?php echo base_url() ?>maintemp/images/itpwcs-wall.png"><br> 
                        <!-- <h4>Strategic Partner</h4>
                        <p class="alt-font text-extra-dark-gray font-weight-400 mb-0">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum is simply dummy text of the printing and typesetting industry.Lorem Ipsum is simply dummy text of the printing and typesetting industry.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum is simply dummy text of the printing and typesetting industry.Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p> -->
                    </div>
                </div>
            </div>
        </section>

     <section class="padding-40px-tb  fadeIn">
            <div class="container">
                <div class="row ">
                    <div class="col-12 col-xl-12 col-md-12 margin-two-bottom  ">
                        <h5 class="alt-font  font-weight-600 mb-0">ITWPCS Membership Types</h5>
                 
                </div>
                
                    <!-- start features box -->
                    <div class="col-12 col-lg-12 col-md-6 md-margin-30px-bottom wow fadeInUp">
                  
                         <h5 href="#">Student Membership </h5>
                        <p>Take the charge of your career - to get an scholarships , IT research program , industry network programs , access to our events , webinars , seminars Etc.. </p>
                        <a class="btn btn-medium btn-transparent-dark-gray  e lg-margin-15px-bottom d-table d-lg-inline-block md-margin-lr-auto" href="#">Learn More</a><br><br><br>
                    </div>
                    <!-- end feature box -->

                    <!-- start features box -->
                    <div class="col-12 col-lg-12 col-md-6 wow fadeInUp sm-margin-30px-bottom" data-wow-delay="0.4s">
                        
                          <h5 href="#">Professionals Membership </h5>
                        <p>Take your next plan of your career to get an industrial chapter program , IT research programs , events , webinars , seminars , IT career planner , IT certification Coupons</p>
                        <a class="btn btn-medium  btn-transparent-dark-gray e lg-margin-15px-bottom d-table d-lg-inline-block md-margin-lr-auto" href="#">Learn More</a><br><br><br>

                    </div>
                    <!-- end feature box -->
                    <!-- start features box -->
                    <div class="col-12 col-lg-12 col-md-6 wow fadeInUp" data-wow-delay="0.6s">
                        <h5 href="#">Corporate Partner </h5>
                        <p>Growing together with ITPWCS program - Unlimited IT workforce accessing , partner level programs , product demo webinars with Top IT companies etc</p>
                        <a class="btn btn-medium btn-transparent-dark-gray  e lg-margin-15px-bottom d-table d-lg-inline-block md-margin-lr-auto" href="#">Learn More</a><br><br><br>
                    </div>
                    <!-- end feature box -->
                </div>
            </div>
        </section>
        <!-- start feature box section -->


        <section class="wow fadeIn bg-light-gray">
            <div class="container">
                <div class="row">
                      
                    <div class="col-12 col-lg-12 col-md-12  text-center  md-margin-10px-bottom sm-margin-10px-bottom text-center last-paragraph-no-margin">
                        <h5 class="alt-font font-weight-700 text-extra-dark-gray text-uppercase"> Benefits Chart</h5>
                            <div class="table-responsive">
                      <table class="table">
                        
                        <table class="table-bordered">
                <!--       <thead>
                        <tr>
                          <th colspan="2" style="color: darkblue">Card No: 0001991</th>

                        </tr> -->
                        <tr>
                          <th style="color: darkblue">Member benefits</th>
                          <th style="color: darkblue">Students</th>
                          <th style="color: darkblue">Associate </th>
                          <th style="color: darkblue">Professional </th>
                          <th style="color: darkblue">Corporate  </th>
                        </tr>
                      </thead>
                      <tbody>

                        <tr>
                          <td  class="center">Digital Badge</td>
                          <td  class="center">Gen.badge</td>
                           <td  class="center">Ass.badge</td>
                          <td  class="center">Prof.badge</td>
                           <td  class="center">Corp.badge</td>
                        </tr>

                        <tr>
                          <td  class="center">Seminar</td>
                          <td  class="center">Yes</td>
                           <td  class="center">Yes</td>
                          <td  class="center">Yes</td>
                           <td  class="center">Yes</td>
                        </tr>

                        <tr>
                          <td  class="center">Webinar </td>
                          <td  class="center">Yes</td>
                           <td  class="center">Yes</td>
                          <td  class="center">Yes</td>
                           <td  class="center">Yes</td>
                        </tr>


                        <tr>
                          <td  class="center">Events </td>
                          <td  class="center">20% off</td>
                           <td  class="center">30%off</td>
                          <td  class="center">30%off</td>
                           <td  class="center">Free(4persons) </td>
                        </tr>


                        <tr>
                          <td  class="center">Scholarships  </td>
                          <td  class="center">Yes</td>
                           <td  class="center">Yes</td>
                          <td  class="center">Yes</td>
                           <td  class="center">Yes</td>
                        </tr>


                        <tr>
                          <td  class="center">Mentorships from Experts  </td>
                          <td  class="center">No</td>
                           <td  class="center">Yes</td>
                          <td  class="center">Yes</td>
                           <td  class="center">Yes</td>
                        </tr>

                        <tr>
                          <td  class="center">BMIT   </td>
                          <td  class="center">No</td>
                           <td  class="center">Yes</td>
                          <td  class="center">No</td>
                           <td  class="center">Yes</td>
                        </tr>


                        <tr>
                          <td  class="center">Industrial Communities   </td>
                          <td  class="center">No</td>
                           <td  class="center">Yes</td>
                          <td  class="center">Yes</td>
                           <td  class="center">Yes</td>
                        </tr>


                        <tr>
                          <td  class="center">Use ITPWCS logo </td>
                          <td  class="center">---</td>
                           <td  class="center">---</td>
                          <td  class="center">---</td>
                           <td  class="center">Yes</td>
                        </tr>


                        <tr>
                          <td  class="center">Member  to member directory </td>
                          <td  class="center">No</td>
                           <td  class="center">Yes</td>
                          <td  class="center">Yes</td>
                           <td  class="center">Yes</td>
                        </tr>

                         <tr>
                          <td  class="center">IT Course training Coupons </td>
                          <td  class="center">No</td>
                           <td  class="center">Yes</td>
                          <td  class="center">Yes</td>
                           <td  class="center">Yes</td>
                        </tr>      
                        
                         <tr>
                          <td  class="center">IT Course training Coupons </td>
                          <td  class="center">No</td>
                           <td  class="center">Yes</td>
                          <td  class="center">Yes</td>
                           <td  class="center">Yes</td>
                        </tr>  

                        
                         <tr>
                          <td  class="center">IT Course training Coupons </td>
                          <td  class="center">Yes</td>
                           <td  class="center">Yes</td>
                          <td  class="center">Yes</td>
                           <td  class="center">Yes</td>
                        </tr>  

                         <tr>
                          <td  class="center">Student Directory Access </td>
                          <td  class="center">---</td>
                           <td  class="center">---</td>
                          <td  class="center">---</td>
                           <td  class="center">Yes</td>
                        </tr>    


                         <tr>
                          <td  class="center">Awards </td>
                          <td  class="center">No</td>
                           <td  class="center">Yes</td>
                          <td  class="center">Yes</td>
                           <td  class="center">No</td>
                        </tr>  


                         <tr>
                          <td  class="center">Competitions </td>
                          <td  class="center">No</td>
                           <td  class="center">Yes</td>
                          <td  class="center">Yes</td>
                           <td  class="center">No</td>
                        </tr>      


                      </tbody>
                    </table>
                </table>


                    </div>
                    </div>  
       
            </div>
                     
                </div>
            </div>
        </section>
         
  
    <?php include 'footer.php';?>

 
        <!-- start scroll to top -->
        <a class="scroll-top-arrow" href="javascript:void(0);"><i class="ti-arrow-up"></i></a>
        <!-- end scroll to top  -->
        <!-- javascript libraries -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/modernizr.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/bootstrap.bundle.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.easing.1.3.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/skrollr.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/smooth-scroll.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.appear.js"></script>
        <!-- menu navigation -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/bootsnav.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.nav.js"></script>
        <!-- animation -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/wow.min.js"></script>
        <!-- page scroll -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/page-scroll.js"></script>
        <!-- swiper carousel -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/swiper.min.js"></script>
        <!-- counter -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.count-to.js"></script>
        <!-- parallax -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.stellar.js"></script>
        <!-- magnific popup -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.magnific-popup.min.js"></script>
        <!-- portfolio with shorting tab -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/isotope.pkgd.min.js"></script>
        <!-- images loaded -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/imagesloaded.pkgd.min.js"></script>
        <!-- pull menu -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/classie.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/hamburger-menu.js"></script>
        <!-- counter  -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/counter.js"></script>
        <!-- fit video  -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.fitvids.js"></script>
        <!-- skill bars  -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/skill.bars.jquery.js"></script> 
        <!-- justified gallery  -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/justified-gallery.min.js"></script>
        <!--pie chart-->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.easypiechart.min.js"></script>
        <!-- instagram -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/instafeed.min.js"></script>
        <!-- retina -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/retina.min.js"></script>
        <!-- revolution -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/revolution/js/jquery.themepunch.tools.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/revolution/js/jquery.themepunch.revolution.min.js"></script>
        <!-- revolution slider extensions (load below extensions JS files only on local file systems to make the slider work! The following part can be removed on server for on demand loading) -->
        <!--<script type="text/javascript" src="revolution/js/extensions/revolution.extension.actions.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.carousel.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.kenburn.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.layeranimation.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.migration.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.navigation.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.parallax.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.slideanims.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.video.min.js"></script>-->
        <!-- setting -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/main.js"></script>
    </body>
</html>