<!doctype html>
<html class="no-js" lang="en">
    <head>
        <!-- title -->
        <title>ITPWCS</title>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1" />
        <meta name="author" content=" ">
        <!-- description -->
        <meta name="description" content="ITPWCS">
        <!-- keywords -->
        <meta name="keywords" content="ITPWCS">
        <!-- favicon -->
        <link rel="shortcut icon" href="<?php echo base_url() ?>maintemp/images/favicon.png">
<!--         <link rel="apple-touch-icon" href="images/apple-touch-icon-57x57.png">
        <link rel="apple-touch-icon" sizes="72x72" href="images/apple-touch-icon-72x72.png">
        <link rel="apple-touch-icon" sizes="114x114" href="images/apple-touch-icon-114x114.png"> -->
        <!-- animation -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/animate.css" />
        <!-- bootstrap -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/bootstrap.min.css" />
        <!-- et line icon --> 
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/et-line-icons.css" />
        <!-- font-awesome icon -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/font-awesome.min.css" />
        <!-- themify icon -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/themify-icons.css">
        <!-- swiper carousel -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/swiper.min.css">
        <!-- justified gallery  -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/justified-gallery.min.css">
        <!-- magnific popup -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/magnific-popup.css" />
        <!-- revolution slider -->
        <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>maintemp/revolution/css/settings.css" media="screen" />
        <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>maintemp/revolution/css/layers.css">
        <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>maintemp/revolution/css/navigation.css">
        <!-- bootsnav -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/bootsnav.css">
        <!-- style -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/style.css" />
        <!-- responsive css -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/responsive.css" />

        
        <!--[if IE]>
            <script src="js/html5shiv.js"></script>
        <![endif]-->
    </head>
    <body>
        

    <?php $page = 'services';?>
    <?php include 'header.php';?>


    <!-- start page title section -->
    <section class="   padding-0px-tb  top-space"></section>
    <!-- end page title section -->

        <!-- start hero section -->
        <section class="pb-0 wow fadeIn" id="section-down">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12 abt-bmit  col-lg-7  text-left  last-paragraph-no-margin">
                        <h5 class="alt-font text-extra-dark-gray font-weight-600"> BMIT</h5>
                        <p style="text-align: justify;" class="mx-auto d-inline-block sm-width-100">We go the extra Brain-mapping for information technology program, is an essential part
                        of any IT students nowadays. According to our survey there are 70% IT
                        students forced to take this degree for his/her parents or friends. And the
                        remaining students don't have any idea after their degree or diploma pro-
                        gram. This is the reason BMIT comes into the picture, in the case of infor-
                        mation technology jobs are increasing rapidly, according to the bureau of
                        labour statistics says there is a 13 million IT jobs are there in 2020. But
                        the IT companies are more sophisticated approaches to hiring a new em-
                        ployee to their team, is not depends upon what degree he/she held on,
                        which framework are familiar with etc. In our persecution into IT. There is
                        Lots of IT jobs are available in the market all jobs have needed skill sets.
                        So we are identifying all the potentials in your brain using Psychometric
                        tests and finding your most suitable area’s in information technology
                        career</p><br><br>
                <a style="margin-left: 23%;" class="btn-primary btn btn-small button margin-5px-all btn-rounded lg-margin-15px-bottom d-table d-lg-inline-block md-margin-lr-auto" href="students.php">For Students</a>

                    <a  class="btn-primary btn btn-small button margin-5px-all btn-rounded lg-margin-15px-bottom d-table d-lg-inline-block md-margin-lr-auto" href="professional.php">IT Professionals</a>
                    </div>
                    <div class="col-12 col-lg-5 text-left   md-margin-40px-bottom sm-margin-30px-bottom p-0">
                        <img src="<?php echo base_url() ?>maintemp/images/bmit-wall.png">
                    </div>


                    
            </div>
        </section>
        <!-- end banner section -->

        <section class="pb-0 wow fadeIn" id="section-down">
            <div class="container">
                <div class="row ">
                    <div class="col-12  col-lg-7  text-left  last-paragraph-no-margin">
                        <h5 class="alt-font text-extra-dark-gray font-weight-600">Why BMIT ?</h5>
                        <ul class="p-0 list-style-1" style="text-align: justify;">

                           <ol>
                            <label>Employee Level Problems</label>
                            <li class="bg-green"> 9 out of 10 IT Students unhappy with their Course</li>
                            <li class="bg-green"> Only 24% IT Professionals get growth with their job</li>
                            <li class="bg-green"> Plan for a IT career is Fulfilling and Motivating</li>
                            <li class="bg-green"> Take a first step towards a meaningful journey</li>
                            <li class="bg-green"> Globally only 24% IT employees satisfied this job remaining employees hate this field</li>
                            
                            </ol>
                        </ul>
                
                    </div>
                    <div class="col-12 col-lg-5 text-left   md-margin-40px-bottom sm-margin-30px-bottom">
                        <img src="<?php echo base_url() ?>maintemp/images/Whybmit2.png">
                    </div>
            </div>
        </section>

        <section class="pb-0 wow fadeIn" id="section-down">
            <div class="container">
                <div class="row ">
                    <div class="col-12 col-lg-3 text-left   md-margin-40px-bottom sm-margin-30px-bottom">
                        <img src="<?php echo base_url() ?>maintemp/images/Whybimt.png">
                    </div>
                    <div class="col-12  col-lg-9  text-left  last-paragraph-no-margin">
                        
                        <ul class="p-0 list-style-1" style="text-align: justify;">

                           <ol>
                            <label>Employer Level Problems</label>
                            <li class="bg-green">56% Recruiters who say they can’t make good hires because of lengthy hiring procedures.</li>
                            <li class="bg-green">83% Fortune 500 executives who don’t believe that their companies recruits highly talents peoples</li>
                            <li class="bg-green">23% Managers and senior executives who believe their current aquasition and retention strategies will work</li>
                            <li class="bg-green">76% Hiring managers who say that attracting top talents is their greatest challenge.</li>
                            <li class="bg-green">54% Employers who currently open positions for which they cant find qualified candidates</li>
                            <li class="bg-green">35% Employers who have positions that stay open for 12 week or longer</li>
                            
                            </ol>
                        </ul>
                
                    </div>
                    
            </div>
        </section>
        

        <section class="wow fadeIn we-wre">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-12 col-lg-10 col-md-11 text-center wow fadeInUp margin-two-bottom">
                        <h4 class="text-extra-dark-gray font-weight-700">WHY WE ARE UNIQUE</h4>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4 why-unique text-center wow fadeInUp">
                        <img class="img-fluid" src="<?php echo base_url() ?>maintemp/images/Unique_1.png">
                        <h6>Dedicted IT Career Assessments</h6>
                        <p>Comprehensive career
assessment for IT graduates</p>
                    </div>
                    <div class="col-md-4 why-unique text-center wow fadeInUp" data-wow-delay="0.6s">
                        <img class="img-fluid" src="<?php echo base_url() ?>maintemp/images/Unique_2.png">
                        <h6>Employee Analysis</h6>
                        <p>Tech exploration among 48+
career and 300+ occupation for every candidate</p>
                    </div>
                    <div class="col-md-4 why-unique text-center wow fadeInUp" data-wow-delay="0.4s">
                        <img class="img-fluid" src="<?php echo base_url() ?>maintemp/images/Unique_3.png">
                        <h6>Highly Reliable Assessment</h6>
                        <p>Our Career assessment is of
Industry standard and we
Use state of the art AI technology
to give you tailored assessment</p>
                    </div>
                    <div class="col-md-4 why-unique text-center wow fadeInUp" data-wow-delay="0.4s">
                        <img class="img-fluid" src="<?php echo base_url() ?>maintemp/images/Unique_4.png">
                        <h6>Online & Offline Counseling</h6>
                        <p>Tailored counselling for each &
Every members from to level
Industry experts</p>
                    </div>
                    <div class="col-md-4 why-unique text-center wow fadeInUp" data-wow-delay="0.4s">
                        <img class="img-fluid" src="<?php echo base_url() ?>maintemp/images/Unique_6.png">
                        <h6>24/7 Customer Support</h6>
                        <p>most reliable customer support
                        for clearing all your doubts</p>
                    </div>
                    <div class="col-md-4 why-unique text-center wow fadeInUp" data-wow-delay="0.4s">
                        <img class="img-fluid" src="<?php echo base_url() ?>maintemp/images/Unique_5.png">
                        <h6>Affordable Prices</h6>
                        <p>We offer high quality services
which comes at a belllow
Average cost.</p>
                    </div>
                    <div class="col-md-4 why-unique text-center wow fadeInUp" data-wow-delay="0.4s">
                        <img class="img-fluid" src="<?php echo base_url() ?>maintemp/images/Unique_9.png">
                        <h6>Multilingual Assessment</h6>
                        <p>Assessments available in both<br>
English and Hindi</p>
                    </div>
                    <div class="col-md-4 why-unique text-center wow fadeInUp" data-wow-delay="0.4s">
                        <img class="img-fluid" src="<?php echo base_url() ?>maintemp/images/Unique_7.png">
                        <h6>Get Industry Support </h6>
                        <p>We are Associated 100+ IT companies all over kerala so you can connect all the companies for your career growth </p>
                    </div>
                    <div class="col-md-4 why-unique text-center wow fadeInUp" data-wow-delay="0.4s">
                        <img class="img-fluid" src="<?php echo base_url() ?>maintemp/images/Unique_8.png">
                        <h6>Free Internship Opportunity </h6>
                        <p>If you complete the assessment I will share your job matching results with the required companies</p>
                    </div>

                </div>
                

                    <!-- end feature box -->
                </div>
            </div>
        </section>
<section>
<section class="wow fadeIn testiminial">
    <h4>TESTIMONIALS</h4>
     <div class="container px-2 px-md-4 py-5 mx-auto wow fadeInUp" data-wow-delay="0.6s">

     <div class="row d-flex justify-content-center ">
         <div class="col-md-10">
             <div id="carouselExampleIndicators" class="carousel slide d-flex" data-ride="carousel">
                 <ol class="carousel-indicators">
                     <li data-target="#carouselExampleIndicators" data-slide-to="0"></li>
                     <li data-target="#carouselExampleIndicators" data-slide-to="1" class="active"></li>
                     <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                 </ol>
                 <div class="carousel-inner ">
                     <div class="carousel-item testi">
                         <div class="card border-0 ">
                             <div class="card-header">
                                <h5>I believe that one defines oneself by reinvention. To not be like your parents. To not be like your friends. To be yourself. To cut yourself out of stone.</h5>
                             </div>
                             <div class="card-body text-center "><img class="img-1 img-fluid" src="https://i.imgur.com/nUNhspp.jpg">
                                 <div class="testi-p">
                                     
                                     <h6>Sophia V./ Company Inc</h6>
                                     <p>Wholises</p>
                                 </div>
                             </div>
                         </div>
                     </div>
                     <div class="carousel-item testi active">
                         <div class="card border-0 ">
                             <div class="card-header">
                                <h5>I believe that one defines oneself by reinvention. To not be like your parents. To not be like your friends. To be yourself. To cut yourself out of stone.</h5>
                             </div>
                             <div class="card-body text-center "><img class="img-1 img-fluid" src="https://i.imgur.com/kkjs7EC.png">
                                 <div class="testi-p">
                                     
                                     <h6>Sophia V./ Company Inc</h6>
                                     <p>Wholises</p>
                                 </div>
                             </div>
                         </div>
                     </div>
                     <div class="carousel-item testi">
                         <div class="card border-0 ">
                             <div class="card-header">
                               <h5>I believe that one defines oneself by reinvention. To not be like your parents. To not be like your friends. To be yourself. To cut yourself out of stone.</h5>
                             </div>
                             <div class="card-body text-center "><img class="img-1 img-fluid" src="https://i.imgur.com/At1IG6H.png">
                                 <div class="testi-p">
                                     
                                    <h6>Sophia V./ Company Inc</h6>
                                     <p>Wholises</p>
                                 </div>
                             </div>
                         </div>
                     </div>
                 </div>
             </div>
         </div>
     </div>
 </div>
</section>
      

 
        <section class="wow fadeIn">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <h6 class="text-uppercase alt-font text-extra-dark-gray font-weight-600 margin-four-bottom">Frequently Asked Questions (FAQ)</h6>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <!-- start accordion -->
                        <div class="panel-group accordion-style1" id="accordion-one">
                            <!-- start accordion item -->
                            <div class="panel">
                                <div class="panel-heading">
                                    <a data-toggle="collapse" data-parent="#accordion-one" href="#accordion-one-link1" class="collapsed" aria-expanded="false"><div class="panel-title font-weight-500 text-uppercase position-relative padding-20px-right">What is the full form of BMIT?<span class="position-absolute right-0 top-0"><i class="ti-plus"></i></span></div></a>
                                </div>
                                <div id="accordion-one-link1" data-parent="#accordion-one" class="panel-collapse collapse">
                                    <div class="panel-body">
                                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
                                        
                                        
                                    </div>
                                </div>
                            </div>
                            <!-- end accordion item -->
                            <!-- start accordion item -->
                            <div class="panel">
                                <div class="panel-heading">
                                    <a data-toggle="collapse" data-parent="#accordion-one" href="#accordion-one-link2" class="collapsed" aria-expanded="false"><div class="panel-title font-weight-500 text-uppercase position-relative padding-20px-right">Why BMIT?<span class="position-absolute right-0 top-0"><i class="ti-plus"></i></span></div></a>
                                </div>
                                <div id="accordion-one-link2" data-parent="#accordion-one" class="panel-collapse collapse">
                                    <div class="panel-body">
                                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
                                         
                                    </div>
                                </div>
                            </div>
                            <!-- end accordion item -->
                            <!-- start accordion item -->
                            <div class="panel">
                                <div class="panel-heading">
                                    <a data-toggle="collapse" data-parent="#accordion-one" href="#accordion-one-link3" class="collapsed" aria-expanded="false"><div class="panel-title font-weight-500 text-uppercase position-relative padding-20px-right">Who can Take this Exam?<span class="position-absolute right-0 top-0"><i class="ti-plus"></i></span></div></a>
                                </div>
                                <div id="accordion-one-link3" data-parent="#accordion-one" class="panel-collapse collapse">
                                    <div class="panel-body">
                                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
                                        
                                    </div>
                                </div>
                            </div>
                            <!-- end accordion item -->
                            <!-- start accordion item -->
                            <div class="panel">
                                <div class="panel-heading">
                                    <a data-toggle="collapse" data-parent="#accordion-one" href="#accordion-one-link4" class="collapsed" aria-expanded="false"><div class="panel-title font-weight-500 text-uppercase position-relative padding-20px-right">What are the advantages of BMIT?<span class="position-absolute right-0 top-0"><i class="ti-plus"></i></span></div></a>
                                </div>
                                <div id="accordion-one-link4" data-parent="#accordion-one" class="panel-collapse collapse">
                                    <div class="panel-body">
                                        <p>It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
                                        
                                    </div>
                                </div>
                            </div>
                            <!-- end accordion item -->
                            <!-- start accordion item -->
                            <div class="panel">
                                <div class="panel-heading">
                                    <a data-toggle="collapse" data-parent="#accordion-one" href="#accordion-one-link5" class="collapsed" aria-expanded="false"><div class="panel-title font-weight-500 text-uppercase position-relative padding-20px-right">Should a working empolyee take BMIT test?<span class="position-absolute right-0 top-0"><i class="ti-plus"></i></span></div></a>
                                </div>
                                <div id="accordion-one-link5" data-parent="#accordion-one" class="panel-collapse collapse">
                                    <div class="panel-body">
                                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
                                        
                                    </div>
                                </div>
                            </div>
                            <!-- end accordion item -->
                        </div>
                        <!-- end accordion -->
                    </div>
                </div>
            </div>
        </section>



























        
 
           
           
    
    <?php include 'footer.php';?>


        <!-- end footer -->
        <!-- start scroll to top -->
        <a class="scroll-top-arrow" href="javascript:void(0);"><i class="ti-arrow-up"></i></a>

        <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
        <!-- end scroll to top  -->
        <!-- javascript libraries -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/modernizr.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/bootstrap.bundle.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.easing.1.3.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/skrollr.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/smooth-scroll.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.appear.js"></script>
        <!-- menu navigation -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/bootsnav.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.nav.js"></script>
        <!-- animation -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/wow.min.js"></script>
        <!-- page scroll -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/page-scroll.js"></script>
        <!-- swiper carousel -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/swiper.min.js"></script>
        <!-- counter -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.count-to.js"></script>
        <!-- parallax -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.stellar.js"></script>
        <!-- magnific popup -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.magnific-popup.min.js"></script>
        <!-- portfolio with shorting tab -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/isotope.pkgd.min.js"></script>
        <!-- images loaded -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/imagesloaded.pkgd.min.js"></script>
        <!-- pull menu -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/classie.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/hamburger-menu.js"></script>
        <!-- counter  -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/counter.js"></script>
        <!-- fit video  -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.fitvids.js"></script>
        <!-- skill bars  -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/skill.bars.jquery.js"></script> 
        <!-- justified gallery  -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/justified-gallery.min.js"></script>
        <!--pie chart-->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.easypiechart.min.js"></script>
        <!-- instagram -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/instafeed.min.js"></script>
        <!-- retina -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/retina.min.js"></script>
        <!-- revolution -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/revolution/js/jquery.themepunch.tools.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/revolution/js/jquery.themepunch.revolution.min.js"></script>
        <!-- revolution slider extensions (load below extensions JS files only on local file systems to make the slider work! The following part can be removed on server for on demand loading) -->
        <!--<script type="text/javascript" src="revolution/js/extensions/revolution.extension.actions.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.carousel.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.kenburn.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.layeranimation.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.migration.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.navigation.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.parallax.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.slideanims.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.video.min.js"></script>-->
        <!-- setting -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/main.js"></script>





<script type="text/javascript">
    
function resetActive(event, percent, step) {
        $(".progress-bar").css("width", percent + "%").attr("aria-valuenow", percent);
        $(".progress-completed").text(percent + "%");

        $("div").each(function () {
            if ($(this).hasClass("activestep")) {
                $(this).removeClass("activestep");
            }
        });

        if (event.target.className == "col-md-2") {
            $(event.target).addClass("activestep");
        }
        else {
            $(event.target.parentNode).addClass("activestep");
        }

        hideSteps();
        showCurrentStepInfo(step);
    }

    function hideSteps() {
        $("div").each(function () {
            if ($(this).hasClass("activeStepInfo")) {
                $(this).removeClass("activeStepInfo");
                $(this).addClass("hiddenStepInfo");
            }
        });
    }

    function showCurrentStepInfo(step) {        
        var id = "#" + step;
        $(id).addClass("activeStepInfo");
    }



</script>
    </body>
</html>