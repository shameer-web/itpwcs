﻿<!doctype html>
<html class="no-js" lang="en">
    <head>
        <!-- title -->
        <title>ITPWCS</title>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1" />
        <meta name="author" content=" ">
        <!-- description -->
        <meta name="description" content="ITPWCS">
        <!-- keywords -->
        <meta name="keywords" content="ITPWCS">
        <!-- favicon -->
        <link rel="shortcut icon" href="<?php echo base_url() ?>maintemp/images/favicon.png">
<!--         <link rel="apple-touch-icon" href="images/apple-touch-icon-57x57.png">
        <link rel="apple-touch-icon" sizes="72x72" href="images/apple-touch-icon-72x72.png">
        <link rel="apple-touch-icon" sizes="114x114" href="images/apple-touch-icon-114x114.png"> -->
        <!-- animation -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/animate.css" />
        <!-- bootstrap -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/bootstrap.min.css" />
        <!-- et line icon --> 
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/et-line-icons.css" />
        <!-- font-awesome icon -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/font-awesome.min.css" />
        <!-- themify icon -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/themify-icons.css">
        <!-- swiper carousel -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/swiper.min.css">
        <!-- justified gallery  -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/justified-gallery.min.css">
        <!-- magnific popup -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/magnific-popup.css" />
        <!-- revolution slider -->
        <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>maintemp/revolution/css/settings.css" media="screen" />
        <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>maintemp/revolution/css/layers.css">
        <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>maintemp/revolution/css/navigation.css">
        <!-- bootsnav -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/bootsnav.css">
        <!-- style -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/style.css" />
        <!-- responsive css -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/responsive.css" />
        <!--[if IE]>
            <script src="js/html5shiv.js"></script>
        <![endif]-->
    </head>
    <body>
        

    <?php $page = 'members';?>
    <?php include 'header.php';?>

    <!-- start page title section -->
    <section class="   padding-0px-tb  top-space"></section>
    <!-- end page title section -->

 
        <section class=" padding-80px-tb  new-bg  wow fadeIn"  >
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-12 col-xl-5 col-md-6  md-margin-20px-bottom sm-margin-10px-bottom text-center">
                         
                       
                        <a class="btn btn-small btn-white btn-rounded lg-margin-1px-bottom d-table d-lg-inline-block md-margin-lr-auto" href="proffesional-form.php">JOIN AS PROFESSIONAL</a>

                    </div>
                </div>
               
            </div>
        </section>
       

        
        <!-- end page title section -->
        <!-- end page title section -->
        <section style="padding: 0px;">
            <div class="container"><h4 style="color:#232323; font-size: 20px; font-weight: 600; padding-top: 40px;">ITPWCS PROFFESSIONAL MEMBERSHIP</h4><p style="font-size: 18px; font-weight: 300; color: #6f6f6f; font-family: 'Roboto', sans-serif;">Are you really updated?<br>
We can help you out through regular updates on existing and innovative technologies!

</p></div>
            <div class="corporate-page">
            <div class="container">
            
    <h4>ENHANCE YOUR TECHNOLOGY CAREER</h4>
<p>Enhance your future, become an ITPWCS Professional Member. All who have the relevant qualifications and the required level of experience can apply for Professional Membership of ITPWCS. The organization offers independent validation and integrity. Each level of membership reflects an individual’s professional training, experience and qualifications. Academic qualifications aren't a requirement if applicants can demonstrate the required levels of competence through their experience, skills and professional development.<br><br>

The key word is “professional” when applied to men and woman who are making a hit in their careers and have the required levels of data and expertise. Professional recognition may be a visible mark of quality, competence and commitment, and may offer a big advantage in today’s competitive environment

</p>
</div>

</div>

        </section>

         
        
           <section class="  padding-0px-tb  memb  fadeIn">
            <div class="container benifits"><h2>BENEFITS</h2>
                <div class="row ">
             <div class="col-12 col-lg-12 col-md-12 wow mrg-btm-3  fadeInUp sm-margin-30px-bottom " data-wow-delay="0.4s">
                        <div class="row">
                          

                            <div class="col-8">
                                 <p class="text-large font-weight-300  padding-40px-tb  line-height-26  ">Take the charge of your career - to get an scholarships , IT reasearch program , industry network programs , access to our events , webinars , seminars Etc.. </p><br>

                         <h5 href="#">Retail product Discounts </h5>
                        <p>Get upto 50% Discount from all the ITPWCS partnering company products </p>
                        <a class="btn btn-medium btn-transparent-dark-gray  e lg-margin-15px-bottom d-table d-lg-inline-block md-margin-lr-auto" href="already-member.php">Learn More</a><br><br><br>
                        </div>
                        <div class="col-4"><img src="<?php echo base_url() ?>maintemp/images/meb-1.jpg"><br></div>
                     </div>

                    </div>
                    <!-- end feature box -->

                
      

                   <!-- start features box -->
                    <div class="col-12 col-lg-12 col-md-12 bg-light-gray mrg-btm-3 wow fadeInUp sm-margin-30px-bottom " data-wow-delay="0.4s">
                     <div class="row padding-50px-tb ">
                            <div class="col-4"><img src="<?php echo base_url() ?>maintemp/images/stud-3.png"><br></div>
                            <div class="col-8 ">
                          <h5 href="#"> Workforce Committee</h5>
                        <p>Join this collaborative group as we work together to develop a comprehensive workforce capable of filling the pipeline for today’s and tomorrow’s tech careers.</p>
                        <a class="btn btn-medium  btn-transparent-dark-gray e lg-margin-15px-bottom d-table d-lg-inline-block md-margin-lr-auto" href="already-member.php">Learn More</a><br><br><br>
                    </div>
                    </div>

                    </div>

                    <div class="col-12 col-lg-12 col-md-12 wow fadeInUp mrg-btm-3  sm-margin-30px-bottom " data-wow-delay="0.4s">
                      <div class="row padding-50px-tb ">
                          
                            <div class="col-8">
                          <h5 href="#">ITPWCS Tech Pro Program </h5>
                        <p>Technical skill development is an essential part of an IT student to get a main stream IT career journey, that is the reason  ITPWCS provides wide varieties of scholarship programmes across the state.  We have number of IT training institutes across kerala. If you are an ITPWCS member, you can get exclusive membership program while you take a course from our partnering institutes</p>
                        <a class="btn btn-medium  btn-transparent-dark-gray e lg-margin-15px-bottom d-table d-lg-inline-block md-margin-lr-auto" href="already-member.php">Learn More</a><br><br><br>
                        </div>
                          <div class="col-4"><img src="<?php echo base_url() ?>maintemp/images/stud-2.png"><br></div>
                    </div>

                    </div>
                    <!-- end feature box -->

      <!-- start features box -->
                    <div class="col-12 col-lg-12 bg-light-gray mrg-btm-3  col-md-12 wow fadeInUp sm-margin-30px-bottom " data-wow-delay="0.4s">
                        <div class="row padding-50px-tb ">
                            <div class="col-4"><img src="<?php echo base_url() ?>maintemp/images/stud-1.png"><br></div>
                            <div class="col-8 ">
                           
                          <h5 href="#">ITPWCS student Rising Star program </h5>
                        <p>This Rising star award to any student member looking to pursue a career in information technology. Who are contributing significantly to the success of our community and making a lasting and valuable impact on their collages technology programs or the IT industry</p>
                        <a class="btn btn-medium  btn-transparent-dark-gray e lg-margin-15px-bottom d-table d-lg-inline-block md-margin-lr-auto" href="already-member.php">Learn More</a><br><br><br>
                        </div>
                     </div>

                    </div>
                    <!-- end feature box -->

              <!-- start features box -->
                    <div class="col-12 col-lg-12 col-md-12 wow mrg-btm-3  fadeInUp sm-margin-30px-bottom " data-wow-delay="0.4s">
                     <div class="row padding-50px-tb ">
                       
                            <div class="col-8">
                          <h5 href="#">Access to Career Encyclopaedia</h5>
                        <p>You can access to career encyclopaedia which briefly discuss about careers in IT sector, skills needed, qualifications and everything you need to attain for each career</p>
                        <a class="btn btn-medium  btn-transparent-dark-gray e lg-margin-15px-bottom d-table d-lg-inline-block md-margin-lr-auto" href="already-member.php">Learn More</a><br><br><br>
                    </div>
                      <div class="col-4"><img src="<?php echo base_url() ?>maintemp/images/stud-3.png"><br></div>
                    </div>
                    </div>
                 
                    <!-- end feature box -->

                </div>
            </div>
        </section>
        <!-- start feature box section -->
        

 
     
       
    <?php include 'footer.php';?>

        <!-- javascript libraries -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/modernizr.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/bootstrap.bundle.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.easing.1.3.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/skrollr.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/smooth-scroll.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.appear.js"></script>
        <!-- menu navigation -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/bootsnav.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.nav.js"></script>
        <!-- animation -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/wow.min.js"></script>
        <!-- page scroll -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/page-scroll.js"></script>
        <!-- swiper carousel -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/swiper.min.js"></script>
        <!-- counter -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.count-to.js"></script>
        <!-- parallax -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.stellar.js"></script>
        <!-- magnific popup -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.magnific-popup.min.js"></script>
        <!-- portfolio with shorting tab -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/isotope.pkgd.min.js"></script>
        <!-- images loaded -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/imagesloaded.pkgd.min.js"></script>
        <!-- pull menu -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/classie.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/hamburger-menu.js"></script>
        <!-- counter  -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/counter.js"></script>
        <!-- fit video  -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.fitvids.js"></script>
        <!-- skill bars  -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/skill.bars.jquery.js"></script> 
        <!-- justified gallery  -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/justified-gallery.min.js"></script>
        <!--pie chart-->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.easypiechart.min.js"></script>
        <!-- instagram -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/instafeed.min.js"></script>
        <!-- retina -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/retina.min.js"></script>
        <!-- revolution -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/revolution/js/jquery.themepunch.tools.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/revolution/js/jquery.themepunch.revolution.min.js"></script>
        <!-- revolution slider extensions (load below extensions JS files only on local file systems to make the slider work! The following part can be removed on server for on demand loading) -->
        <!--<script type="text/javascript" src="revolution/js/extensions/revolution.extension.actions.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.carousel.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.kenburn.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.layeranimation.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.migration.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.navigation.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.parallax.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.slideanims.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.video.min.js"></script>-->
        <!-- setting -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/main.js"></script>
    </body>
</html>