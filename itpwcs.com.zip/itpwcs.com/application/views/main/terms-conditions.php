<!doctype html>
<html class="no-js" lang="en">
    <head>
        <!-- title -->
        <title>ITPWCS</title>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1" />
        <meta name="author" content=" ">
        <!-- description -->
        <meta name="description" content="ITPWCS">
        <!-- keywords -->
        <meta name="keywords" content="ITPWCS">
        <!-- favicon -->
        <link rel="shortcut icon" href="<?php echo base_url() ?>maintemp/images/favicon.png">
<!--         <link rel="apple-touch-icon" href="images/apple-touch-icon-57x57.png">
        <link rel="apple-touch-icon" sizes="72x72" href="images/apple-touch-icon-72x72.png">
        <link rel="apple-touch-icon" sizes="114x114" href="images/apple-touch-icon-114x114.png"> -->
        <!-- animation -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/animate.css" />
        <!-- bootstrap -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/bootstrap.min.css" />
        <!-- et line icon --> 
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/et-line-icons.css" />
        <!-- font-awesome icon -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/font-awesome.min.css" />
        <!-- themify icon -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/themify-icons.css">
        <!-- swiper carousel -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/swiper.min.css">
        <!-- justified gallery  -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/justified-gallery.min.css">
        <!-- magnific popup -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/magnific-popup.css" />
        <!-- revolution slider -->
        <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>maintemp/revolution/css/settings.css" media="screen" />
        <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>maintemp/revolution/css/layers.css">
        <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>maintemp/revolution/css/navigation.css">
        <!-- bootsnav -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/bootsnav.css">
        <!-- style -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/style.css" />
        <!-- responsive css -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/responsive.css" />
        <!--[if IE]>
            <script src="js/html5shiv.js"></script>
        <![endif]-->
    </head>
    <body>
        

    <?php $page = 'about';?>
    <?php include 'header.php';?>

    <!-- start page title section -->
    <section class="   padding-0px-tb  top-space"></section>
    <!-- end page title section -->



        <!-- end page title section -->     
        <!-- start story section -->
        <section class="wow fadeIn">
            <div class="container"> 
               <div class="row align-items-center">
                  
                    <div class="col-12 col-lg-12 md-margin-15px-bottom">
                        <h5>Terms and Conditions</h5>
                       
                        <p>By accessing any part of this website you agree to be subject to the following terms and conditions that you must read carefully<br>
ITPWCS may change these terms at any time without prior notice. By continuing access and use of this Website, you agree to be bound by the latest version of the Site Terms and Conditions. Please check these periodically for changes made.
</p>

 <h5>Disclaimer</h5>
                       
                        <p>We use our reasonable efforts to ensure the accuracy of the information provided in the ITPWCS service.<br>

We do not guarantee the accuracy, reliability or legitimacy of any information contained in ITPWCS.<br>

We make no warranty that the contents of this site are free from viruses, contaminants or any other malicious infections.<br>

We reserve the right, from time to time, to make changes to the information provided in the ITPWCS Service or to change the nature of the ITPWCS Service.<br>

You / User are not responsible for any direct, indirect, consequential, punishable or specific damages resulting from your use of the ITPWCS Service.<br>

This does not guarantee the availability of ITPWCS service during the maintenance of the Website. Site content provided by advertisers, including product / service performance claims, advertising and / or sales promotions, is not the sole responsibility of any such advertisers and they are solely liable for any disputes and liabilities arising out of it. ITPWCS and its affiliates, associates, agents or staff are not liable at any time for any damages (including loss of profit or loss of business) caused by the Contract, or the inability to use the Site or any of its Content, or the Site or its Content Avoidance, interruption, deletion, malfunction, delay in operation or transmission, computer virus, communication line failure, theft or destruction or unauthorized access, modification or use of site information.<br><br>

This Website reserves the right to collect data from the various sources on this website and to correct any errors or omissions in any part of the Site. ITPWCS may bring the site, materials, products, programs, services or prices (if any) without notice at any time as described on the Site.<br>

Therefore, you are advised to verify the information provided to you by the ITPWCS Service, as any reliance on the accuracy of that information is at your own risk. ITPWCS reserves the right to terminate these promo-generated promotions at any time when users are granted genuine access to the ITPWCS service.

</p>



                      <h5>Restriction on use of the Service</h5>
                       
                        <p>Users are permitted to read, print and download text, data and / or graphics from the Site for their personal and non-commercial use only. Saving copies of any of these pages to disk or any other storage media will only be used to print extracts for further viewing purposes or for personal use.<br>

You may not integrate the ITPWCS service into another Internet / Extranet without the written permission of our Customer Relations Department. Unauthorized access, redistribution, transmission and / or handling of any information contained on this Site, reproduction in any other way, in whole or in part, is strictly prohibited and strict legal action will be initiated against such users. You must not use automated scripts, software, spiders, or any other automated means to search ITPWCS. Any attempt to extract or download significant data from ITPWCS or to compile a database of data obtained from ITPWCS is strictly prohibited. For more information about such access, please call our Customer Contact Section at 7012674903 or e-mail: info@itpwcs.in You are entitled to use the information provided in the ITPWCS Service in a responsible manner only and not to use this information in any malicious, illegal or anti-social activity. We reserve the right to suspend accounts where a user has entered ITPWCS incorrect information.

</p>




 <h5>The Rights Of Itpwcs</h5>
<p>Please send us e-mails related to your registration, purchase and account, including site updates. Keep a log file of all searches, which may be available for data matters and / or law enforcement.</p>

 <h5>Cookies</h5>
<p>By accessing our site, you allow us to place our cookies on your hard disk subject. If you are interested, you can discard the cookies we sent.</p>

 <h5>Hypertext Links To Third Party Sites</h5>

<p>Through this site, ITPWCS can provide links to websites run by others. If you decide to visit any of the linked sites, you are doing so at your own risk and it is your responsibility to take all precautionary measures against viruses or other destructive factors. ITPWCS does not provide any warranty or representation on any of the Linked Websites, the information contained therein, or any of the products or services described therein. ITPWCS or this site's sponsors, licenses, affiliates or affiliates, or any other trademark, logo, or copyright symbol that may be displayed on or accessed by links, are not authorized to be authorized. To use any trademark, trade name, logo or copyright symbol of ITPWCS</p>



 <h5>Information Provided By User</h5>

<p>You acknowledge that any material, information or ideas you transfer to this Site may become the property of ITPWCS, and that the broadcasts will not be considered confidential and proprietary, and that ITPWCS will not be liable for any such use, and will disclose, redistribute or redistribute it to others without restriction. ITPWCS reserves the right to use for any purpose any ideas, concepts, knowledge, or technology contained in such information. You agree that ITPWCS may in any way use information about your demographics and the use of this site. Unlawful, intimidating, defamatory, defamatory, inflammatory, pornographic, or obscene material or any criminal liability under civil or law. You are solely responsible for the content of any comments you make. ITPWCS does not request information from you for hosting on the Website. Any information you send will be sent to you manually, so ITPWCS is not obligated to give you any consideration for hosting the information sent.</p>


 <h5>Indemnity</h5>

<p>Consider posting information sent by users on our website or received via a cookie or sent by users; ITPWCS will not indemnify you for any actions, claims, costs or liabilities that may or may not be incurred by users through ITPWCS or for environmental reasons.</p>

 <h5>Endorsements</h5>

<p>All product and service marks other than the ITPWCS or ITPWCS marks are trademarks of their respective owners. The references we make to any third party or informational information, marks, products or services do not imply our approval or sponsorship or reference to any third party, information, product or service recommendation.</p>

 <h5>Jurisdiction As Per Indian Laws</h5>

<p>Conditions These Terms will be governed and regulated in accordance with Indian laws. All disputes are subject to the jurisdiction of the courts in New Delhi. This website can be accessed from anywhere in the world. However, by accessing this Website, you agree that the laws in India apply to all matters relating to your use of this Website, regardless of the laws governing the use of this Website. Users who access this website from outside India acknowledge that they do so voluntarily and are responsible for complying with local laws. ITPWCS reserves the right to disclose any information, material, regulatory, legal process or application required to comply with, or to edit, post, or reject any information or material, in whole or in part, as applicable. At the discretion of ITPWCS.<br><br>

Site The Terms and Conditions of this Site include the entire Agreement between the Clients in relation to its subject matter, and it nullifies and replaces any previous or co-operational agreements / agreements related to the subject matter. If a court of competent jurisdiction decides that any of these terms are illegal, invalid or unenforceable, that provision shall be separated from these Terms and the remaining provisions shall remain in full force and effect.</p>

 <h5>For Any Issues </h5>
<p>In case the customer has any issue/query he/she will contact on 7012674903 number Or send mail on email id support@itpwcs.in and will be resolved on basis of severability of the complaint.</p>





                    </div>

                    

                                        
                </div>
                
            </div>
        </section>
        <!-- end story section -->
 



 
 
        
        
    
    <?php include 'footer.php';?>

        
        <!-- start scroll to top -->
        <a class="scroll-top-arrow" href="javascript:void(0);"><i class="ti-arrow-up"></i></a>
        <!-- end scroll to top  -->
        <!-- javascript libraries -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/modernizr.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/bootstrap.bundle.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.easing.1.3.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/skrollr.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/smooth-scroll.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.appear.js"></script>
        <!-- menu navigation -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/bootsnav.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.nav.js"></script>
        <!-- animation -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/wow.min.js"></script>
        <!-- page scroll -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/page-scroll.js"></script>
        <!-- swiper carousel -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/swiper.min.js"></script>
        <!-- counter -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.count-to.js"></script>
        <!-- parallax -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.stellar.js"></script>
        <!-- magnific popup -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.magnific-popup.min.js"></script>
        <!-- portfolio with shorting tab -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/isotope.pkgd.min.js"></script>
        <!-- images loaded -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/imagesloaded.pkgd.min.js"></script>
        <!-- pull menu -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/classie.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/hamburger-menu.js"></script>
        <!-- counter  -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/counter.js"></script>
        <!-- fit video  -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.fitvids.js"></script>
        <!-- skill bars  -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/skill.bars.jquery.js"></script> 
        <!-- justified gallery  -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/justified-gallery.min.js"></script>
        <!--pie chart-->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.easypiechart.min.js"></script>
        <!-- instagram -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/instafeed.min.js"></script>
        <!-- retina -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/retina.min.js"></script>
        <!-- revolution -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/revolution/js/jquery.themepunch.tools.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/revolution/js/jquery.themepunch.revolution.min.js"></script>
         
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/main.js"></script>
    </body>
</html>