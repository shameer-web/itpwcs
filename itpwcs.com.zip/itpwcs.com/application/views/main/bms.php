<!doctype html>
<html class="no-js" lang="en">
    <head>
        <!-- title -->
        <title>ITPWCS</title>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1" />
        <meta name="author" content=" ">
        <!-- description -->
        <meta name="description" content="ITPWCS">
        <!-- keywords -->
        <meta name="keywords" content="ITPWCS">
        <!-- favicon -->
        <link rel="shortcut icon" href="<?php echo base_url() ?>maintemp/images/favicon.png">
<!--         <link rel="apple-touch-icon" href="images/apple-touch-icon-57x57.png">
        <link rel="apple-touch-icon" sizes="72x72" href="images/apple-touch-icon-72x72.png">
        <link rel="apple-touch-icon" sizes="114x114" href="images/apple-touch-icon-114x114.png"> -->
        <!-- animation -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/animate.css" />
        <!-- bootstrap -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/bootstrap.min.css" />
        <!-- et line icon --> 
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/et-line-icons.css" />
        <!-- font-awesome icon -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/font-awesome.min.css" />
        <!-- themify icon -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/themify-icons.css">
        <!-- swiper carousel -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/swiper.min.css">
        <!-- justified gallery  -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/justified-gallery.min.css">
        <!-- magnific popup -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/magnific-popup.css" />
        <!-- revolution slider -->
        <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>maintemp/revolution/css/settings.css" media="screen" />
        <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>maintemp/revolution/css/layers.css">
        <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>maintemp/revolution/css/navigation.css">
        <!-- bootsnav -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/bootsnav.css">
        <!-- style -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/style.css" />
        <!-- responsive css -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/responsive.css" />
        <!--[if IE]>
            <script src="js/html5shiv.js"></script>
        <![endif]-->
    </head>
    <body>
        

    <?php $page = 'services';?>
    <?php include 'header.php';?>


    <!-- start page title section -->
    <section class="   padding-0px-tb  top-space"></section>
    <!-- end page title section -->


<div style="display: block; width: 100%; clear: both;" class="clearfix"></div>

        <!-- start hero section -->
        <section class="pb-0 wow fadeIn" id="section-down">
            <div class="container">
                <div class="row ">
                    
                    <div class="col-12  col-lg-12  text-left  last-paragraph-no-margin">
                        <h5 class="alt-font text-extra-dark-gray font-weight-600" style="text-align: right;">BMS (Brain Mapping for Students)</h5>

                        <p class=" mx-auto d-inline-block sm-width-100" style="text-align: justify;">You are most likely to realize life if you create use of BMS Self Analysis check for your skills for Career opportunity. Likewise, you’ll suffer lesser issues
once you recognize what your core Strength and Weakness square measure, and after you manage of these strengths and Weakness in order that they
don’t matter inside the work you would like to do. thus, however, you'll act discovering these strengths and Weakness and considering the Career chance
& threats that move from them? Personal Self Analysis check may be a helpful technique which will assist you to appreciate Career chance What makes
ITPWCS Brain mapping check particularly powerful is often that, with a small amount of thought, it'll assist you to uncover potentialities that you just won't
otherwise possess spotted. And easily by understanding your Personal Strength and Weakness, you'll be able to handle and eliminate risks that may
typically hurt your capability to move forward. Whenever you're taking a look at yourself with all the privates Self Analysis check, for you'll be able to begin
to separate yourself from your associates, and additionally build the specialized skills and talents you have got to advance yours to a future career.</p><br><br>
                
                    </div>


                    
<!-- 

                    <div class="col-md-12">
                        <div class="caption">
                            <h5>Our professional job hiring strategy goes through three levels of talent acquisition.</h5>
                            <div class="caption-qa"></div>
                        </div>
                    </div> -->
            </div>
            <a href="start-assesment.php" target="_self">
        <div class="start-ass"><button type="button" class="btn btn-primary">START ASSESSMENT</button></div>
        </a>
        </section>
        <!-- end banner section -->


        <!-- start feature box section -->
        
        <!-- end feature box section -->
        <section class="pb-0 wow fadeIn" id="section-down">
            <div class="container">
                <div class="row ">
                    <div class="col-12 col-lg-6 text-left   md-margin-40px-bottom sm-margin-30px-bottom">
                        <img src="<?php echo base_url() ?>maintemp/images/BMSwall.png">
                    </div>
                    <div class="col-12  col-lg-6  text-left  last-paragraph-no-margin">
                        
                        <ul class="p-0 list-style-1" style="text-align: justify;">

                           <ol>
                            <label>Benefits</label>
                            <li class="bg-green"> Completely perceive your Strength and Weakness (Self Analysis)</li>
                            <li class="bg-green"> Understand your all-natural character traits</li>
                            <li class="bg-green"> Know your Opportunities and future Threats</li>
                            <li class="bg-green"> Identify and improve your core competencies</li>
                            <li class="bg-green"> Develop acceptive & comfort just by better communication</li>
                            <li class="bg-green"> Plan earlier ahead to achieve your goals & live your needs
</li>
                            <li class="bg-green"> Recognize the simplest possibility for learning and management styles</li>

                             <li class="bg-green"> Know your passion to urge living and convey back dreams through the past</li>
                             <li class="bg-green"> Discover your personal capabilities and choose right profession path</li>
                             <li class="bg-green"> Reorganize your individual favored one’s correspondence character</li>
                            
                            </ol>
                        </ul>
                
                    </div>
                    
            </div>
        </section>

               <section class="wow fadeIn we-wre">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-12 col-lg-10 col-md-11 text-center wow fadeInUp margin-two-bottom">
                        <h4 class="text-extra-dark-gray font-weight-700">WHY WE ARE UNIQUE</h4>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4 why-unique text-center wow fadeInUp">
                        <img class="img-fluid" src="<?php echo base_url() ?>maintemp/images/Unique_1.png">
                        <h6>Dedicted IT Career Assessments</h6>
                        <p>Comprehensive career
assessment for IT graduates</p>
                    </div>
                    <div class="col-md-4 why-unique text-center wow fadeInUp" data-wow-delay="0.6s">
                        <img class="img-fluid" src="<?php echo base_url() ?>maintemp/images/Unique_2.png">
                        <h6>Employee Analysis</h6>
                        <p>Tech exploration among 48+
career and 300+ occupation for every candidate</p>
                    </div>
                    <div class="col-md-4 why-unique text-center wow fadeInUp" data-wow-delay="0.4s">
                        <img class="img-fluid" src="<?php echo base_url() ?>maintemp/images/Unique_3.png">
                        <h6>Highly Reliable Assessment</h6>
                        <p>Our Career assessment is of
Industry standard and we
Use state of the art AI technology
to give you tailored assessment</p>
                    </div>
                    <div class="col-md-4 why-unique text-center wow fadeInUp" data-wow-delay="0.4s">
                        <img class="img-fluid" src="<?php echo base_url() ?>maintemp/images/Unique_4.png">
                        <h6>Online & Offline Counseling</h6>
                        <p>Tailored counselling for each &
Every members from to level
Industry experts</p>
                    </div>
                    <div class="col-md-4 why-unique text-center wow fadeInUp" data-wow-delay="0.4s">
                        <img class="img-fluid" src="<?php echo base_url() ?>maintemp/images/Unique_6.png">
                        <h6>24/7 Customer Support</h6>
                        <p>most reliable customer support
                        for clearing all your doubts</p>
                    </div>
                    <div class="col-md-4 why-unique text-center wow fadeInUp" data-wow-delay="0.4s">
                        <img class="img-fluid" src="<?php echo base_url() ?>maintemp/images/Unique_5.png">
                        <h6>Affordable Prices</h6>
                        <p>We offer high quality services
which comes at a belllow
Average cost.</p>
                    </div>
                    <div class="col-md-4 why-unique text-center wow fadeInUp" data-wow-delay="0.4s">
                        <img class="img-fluid" src="<?php echo base_url() ?>maintemp/images/Unique_9.png">
                        <h6>Multilingual Assessment</h6>
                        <p>Assessments available in both<br>
English and Hindi</p>
                    </div>
                    <div class="col-md-4 why-unique text-center wow fadeInUp" data-wow-delay="0.4s">
                        <img class="img-fluid" src="<?php echo base_url() ?>maintemp/images/Unique_7.png">
                        <h6>Get Industry Support </h6>
                        <p>We are Associated 100+ IT companies all over kerala so you can connect all the companies for your career growth </p>
                    </div>
                    <div class="col-md-4 why-unique text-center wow fadeInUp" data-wow-delay="0.4s">
                        <img class="img-fluid" src="images/Unique_8.png">
                        <h6>Free Internship Opportunity </h6>
                        <p>If you complete the assessment I will share your job matching results with the required companies</p>
                    </div>

                </div>
                

                    <!-- end feature box -->
                </div>
            </div>
        </section>


<section style="background-color: #000;">
    <div class="container">
        <div class="row">
            
            <div class="col-md-8 mx-auto">
                
                <div class="row">
                    <div class="col-md-4 p-0 price-tb prs-1"><div class="pric-bg-1"><h4>BMS<br>Test</h4><h5><i class="fas fa-rupee-sign"></i>1500</h5></div>
                    <ul>
                        <li style="display: block;">6 Dimensional Al<br>Career Assessment</li>
                        <li style="display: block;">Explore your most<br>Suitable Tech Options<br>among 300+ IT jobs</li>
                        <li style="display: block;">FREE ITPWCS<br>Membership</li>
                        <li style="display: block;">Well Researched Job<br>information's</li>
                        <li style="display: block;">35+ Details Job Analysis &<br>Execution plan for 10 years</li>
                         <li style="display: block;"><i style="color: #d5d4d4;" class="fas fa-times"></i></li>
                          <li style="display: block;"><i style="color: #d5d4d4;" class="fas fa-times"></i></li>
                    </ul>
                    <button type="button" class="btn btn-primary">Buy Now</button>
                </div>
                    <div class="col-md-4 p-0 price-tb prs-2"><div class="pric-bg-2"><h4>Online<br>Consulting</h4><h5><i class="fas fa-rupee-sign"></i>2500</h5></div>

<ul>
                        <li style="display: block;">6 Dimensional Al<br>Career Assessment</li>
                        <li style="display: block;">Explore your most<br>Suitable Tech Options<br>among 300+ IT jobs</li>
                        <li style="display: block;">FREE ITPWCS<br>Membership</li>
                        <li style="display: block;">Well Researched Job<br>information's</li>
                        <li style="display: block;">35+ Details Job Analysis &<br>Execution plan for 10 years</li>
                         <li style="display: block;">Book Your appointment with<br>best Tech consultant</li>
                          <li style="display: block;">Post Counselling<br>Support included</li>
                    </ul>
                    <button type="button" class="btn btn-primary">Buy Now</button>

                </div>
                    <div class="col-md-4 p-0 price-tb prs-3"><div class="pric-bg-3"><h4>Offline<br> Consulting</h4><h5><i class="fas fa-rupee-sign"></i>3500</h5></div>
<ul>
                        <li style="display: block;">6 Dimensional Al<br>Career Assessment</li>
                        <li style="display: block;">Explore your most<br>Suitable Tech Options<br>among 300+ IT jobs</li>
                        <li style="display: block;">FREE ITPWCS<br>Membership</li>
                        <li style="display: block;">Well Researched Job<br>information's</li>
                        <li style="display: block;">35+ Details Job Analysis &<br>Execution plan for 10 years</li>
                         <li style="display: block;">Book Your appointment with<br>best Tech Consultant</li>
                          <li style="display: block;">Post Counselling<br>Support included</li>
                    </ul>
                    <button type="button" class="btn btn-primary">Buy Now</button>
                </div>
                    
                </div></div>
            </div>
        </div>

    </div>

</section>

        
        <section class="wow fadeIn testiminial">
    <h4>TESTIMONIALS</h4>
     <div class="container px-2 px-md-4 py-5 mx-auto wow fadeInUp" data-wow-delay="0.6s">

     <div class="row d-flex justify-content-center ">
         <div class="col-md-10">
             <div id="carouselExampleIndicators" class="carousel slide d-flex" data-ride="carousel">
                 <ol class="carousel-indicators">
                     <li data-target="#carouselExampleIndicators" data-slide-to="0"></li>
                     <li data-target="#carouselExampleIndicators" data-slide-to="1" class="active"></li>
                     <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                 </ol>
                 <div class="carousel-inner ">
                     <div class="carousel-item testi">
                         <div class="card border-0 ">
                             <div class="card-header">
                                <h5>I believe that one defines oneself by reinvention. To not be like your parents. To not be like your friends. To be yourself. To cut yourself out of stone.</h5>
                             </div>
                             <div class="card-body text-center "><img class="img-1 img-fluid" src="https://i.imgur.com/nUNhspp.jpg">
                                 <div class="testi-p">
                                     
                                     <h6>Sophia V./ Company Inc</h6>
                                     <p>Wholises</p>
                                 </div>
                             </div>
                         </div>
                     </div>
                     <div class="carousel-item testi active">
                         <div class="card border-0 ">
                             <div class="card-header">
                                <h5>I believe that one defines oneself by reinvention. To not be like your parents. To not be like your friends. To be yourself. To cut yourself out of stone.</h5>
                             </div>
                             <div class="card-body text-center "><img class="img-1 img-fluid" src="https://i.imgur.com/kkjs7EC.png">
                                 <div class="testi-p">
                                     
                                     <h6>Sophia V./ Company Inc</h6>
                                     <p>Wholises</p>
                                 </div>
                             </div>
                         </div>
                     </div>
                     <div class="carousel-item testi">
                         <div class="card border-0 ">
                             <div class="card-header">
                               <h5>I believe that one defines oneself by reinvention. To not be like your parents. To not be like your friends. To be yourself. To cut yourself out of stone.</h5>
                             </div>
                             <div class="card-body text-center "><img class="img-1 img-fluid" src="https://i.imgur.com/At1IG6H.png">
                                 <div class="testi-p">
                                     
                                    <h6>Sophia V./ Company Inc</h6>
                                     <p>Wholises</p>
                                 </div>
                             </div>
                         </div>
                     </div>
                 </div>
             </div>
         </div>
     </div>
 </div>
</section>
       
 

 
           
           
    
    <?php include 'footer.php';?>


        <!-- end footer -->
        <!-- start scroll to top -->
        <a class="scroll-top-arrow" href="javascript:void(0);"><i class="ti-arrow-up"></i></a>

        <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
        <!-- end scroll to top  -->
        <!-- javascript libraries -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/modernizr.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/bootstrap.bundle.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.easing.1.3.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/skrollr.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/smooth-scroll.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.appear.js"></script>
        <!-- menu navigation -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/bootsnav.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.nav.js"></script>
        <!-- animation -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/wow.min.js"></script>
        <!-- page scroll -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/page-scroll.js"></script>
        <!-- swiper carousel -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/swiper.min.js"></script>
        <!-- counter -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.count-to.js"></script>
        <!-- parallax -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.stellar.js"></script>
        <!-- magnific popup -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.magnific-popup.min.js"></script>
        <!-- portfolio with shorting tab -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/isotope.pkgd.min.js"></script>
        <!-- images loaded -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/imagesloaded.pkgd.min.js"></script>
        <!-- pull menu -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/classie.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/hamburger-menu.js"></script>
        <!-- counter  -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/counter.js"></script>
        <!-- fit video  -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.fitvids.js"></script>
        <!-- skill bars  -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/skill.bars.jquery.js"></script> 
        <!-- justified gallery  -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/justified-gallery.min.js"></script>
        <!--pie chart-->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.easypiechart.min.js"></script>
        <!-- instagram -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/instafeed.min.js"></script>
        <!-- retina -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/retina.min.js"></script>
        <!-- revolution -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/revolution/js/jquery.themepunch.tools.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/revolution/js/jquery.themepunch.revolution.min.js"></script>
        <!-- revolution slider extensions (load below extensions JS files only on local file systems to make the slider work! The following part can be removed on server for on demand loading) -->
        <!--<script type="text/javascript" src="revolution/js/extensions/revolution.extension.actions.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.carousel.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.kenburn.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.layeranimation.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.migration.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.navigation.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.parallax.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.slideanims.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.video.min.js"></script>-->
        <!-- setting -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/main.js"></script>





<script type="text/javascript">
    
function resetActive(event, percent, step) {
        $(".progress-bar").css("width", percent + "%").attr("aria-valuenow", percent);
        $(".progress-completed").text(percent + "%");

        $("div").each(function () {
            if ($(this).hasClass("activestep")) {
                $(this).removeClass("activestep");
            }
        });

        if (event.target.className == "col-md-2") {
            $(event.target).addClass("activestep");
        }
        else {
            $(event.target.parentNode).addClass("activestep");
        }

        hideSteps();
        showCurrentStepInfo(step);
    }

    function hideSteps() {
        $("div").each(function () {
            if ($(this).hasClass("activeStepInfo")) {
                $(this).removeClass("activeStepInfo");
                $(this).addClass("hiddenStepInfo");
            }
        });
    }

    function showCurrentStepInfo(step) {        
        var id = "#" + step;
        $(id).addClass("activeStepInfo");
    }



</script>
    </body>
</html>