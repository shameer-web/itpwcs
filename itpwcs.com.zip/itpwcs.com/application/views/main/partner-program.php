﻿<!doctype html>
<html class="no-js" lang="en">
    <head>
        <!-- title -->
        <title>ITPWCS</title>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1" />
        <meta name="author" content=" ">
        <!-- description -->
        <meta name="description" content="ITPWCS">
        <!-- keywords -->
        <meta name="keywords" content="ITPWCS">
        <!-- favicon -->
        <link rel="shortcut icon" href="<?php echo base_url() ?>maintemp/images/favicon.png">
<!--         <link rel="apple-touch-icon" href="images/apple-touch-icon-57x57.png">
        <link rel="apple-touch-icon" sizes="72x72" href="images/apple-touch-icon-72x72.png">
        <link rel="apple-touch-icon" sizes="114x114" href="images/apple-touch-icon-114x114.png"> -->
        <!-- animation -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/animate.css" />
        <!-- bootstrap -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/bootstrap.min.css" />
        <!-- et line icon --> 
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/et-line-icons.css" />
        <!-- font-awesome icon -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/font-awesome.min.css" />
        <!-- themify icon -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/themify-icons.css">
        <!-- swiper carousel -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/swiper.min.css">
        <!-- justified gallery  -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/justified-gallery.min.css">
        <!-- magnific popup -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/magnific-popup.css" />
        <!-- revolution slider -->
        <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>maintemp/revolution/css/settings.css" media="screen" />
        <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>maintemp/revolution/css/layers.css">
        <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>maintemp/revolution/css/navigation.css">
        <!-- bootsnav -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/bootsnav.css">
        <!-- style -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/style.css" />
        <!-- responsive css -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/responsive.css" />
        <!--[if IE]>
            <script src="js/html5shiv.js"></script>
        <![endif]-->
    </head>
    <body>
        

    <?php $page = 'services';?>
    <?php include 'header.php';?>



    <!-- start page title section -->
    <section class="   padding-0px-tb  top-space"></section>
    <!-- end page title section -->


        <!-- start hero section -->
        <section class="pb-0 wow fadeIn" id="section-down">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-12 col-xl-8 col-lg-9 margin-six-bottom text-center last-paragraph-no-margin">
                        <div class="alt-font text-deep-pink margin-10px-bottom text-uppercase text-small">Lorem Ipsum</div>
                        <h5 class="alt-font text-extra-dark-gray font-weight-600">Lorem Ipsum</h5>
                        <p class="width-80 mx-auto d-inline-block sm-width-100">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                    </div>
                </div>
            </div>
 
        </section>
        <!-- end banner section -->
        <!-- start feature box section -->
        <section class="parallax wow fadeIn" data-stellar-background-ratio="0.4" style="background-image:url('<?php echo base_url() ?>maintemp/images/bg-ser.jpg');">
            <div class="container">
                <div class="row">
                    <!-- start feature box item -->
                    <div class="col-12 col-lg-4 last-paragraph-no-margin md-margin-30px-bottom wow fadeInRight">
                        <div class="padding-50px-all lg-padding-40px-all sm-padding-30px-all bg-white box-shadow text-center">
                            <div class="padding-35px-all d-inline-block rounded-circle margin-40px-bottom sm-margin-30px-bottom bg-light-gray"><img src="<?php echo base_url() ?>maintemp/images/image-icon4.png" alt=""/></div>
                            <div class="text-small alt-font text-medium-gray text-uppercase">Lorem Ipsum</div>
                            <span class="alt-font text-extra-dark-gray font-weight-600 d-block margin-20px-bottom">Lorem Ipsum is simply</span>
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem ipsum has been the industry's standard dummy text.</p>
                        </div>                    
                    </div>
                    <!-- end feature box block -->
                    <!-- start feature box item -->
                    <div class="col-12 col-lg-4 last-paragraph-no-margin md-margin-30px-bottom wow fadeInRight" data-wow-delay="0.2s">
                        <div class="padding-50px-all lg-padding-40px-all sm-padding-30px-all bg-white box-shadow text-center">
                            <div class="padding-35px-all d-inline-block rounded-circle margin-40px-bottom sm-margin-30px-bottom bg-light-gray"><img src="<?php echo base_url() ?>maintemp/images/image-icon2.png" alt=""/></div>
                            <div class="text-small alt-font text-medium-gray text-uppercase">Lorem Ipsum</div>
                            <span class="alt-font text-extra-dark-gray font-weight-600 d-block margin-20px-bottom">Lorem Ipsum is simply</span>
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text.</p>
                        </div>                    
                    </div>
                    <!-- end feature box block -->
                    <!-- start feature box item -->
                    <div class="col-12 col-lg-4 last-paragraph-no-margin wow fadeInRight" data-wow-delay="0.4s">
                        <div class="padding-50px-all lg-padding-40px-all sm-padding-30px-all bg-white box-shadow text-center">
                            <div class="padding-35px-all d-inline-block rounded-circle margin-40px-bottom sm-margin-30px-bottom bg-light-gray"><img src="<?php echo base_url() ?>maintemp/images/image-icon3.png" alt=""/></div>
                            <div class="text-small alt-font text-medium-gray text-uppercase">Lorem Ipsum</div>
                            <span class="alt-font text-extra-dark-gray font-weight-600 d-block margin-20px-bottom">Lorem Ipsum is simply</span>
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text.</p>
                        </div>                    
                    </div>
                    <!-- end feature box block -->
                </div>
            </div>
        </section>
        <!-- end feature box section -->
       
        <!-- start feature box section -->
        <section class="wow fadeIn last-paragraph-no-margin">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-12 col-xl-8 col-lg-9 margin-eight-bottom text-center last-paragraph-no-margin">
                        <div class="alt-font text-deep-pink margin-10px-bottom text-uppercase text-small">Technology Expert Analysis</div>
                        <h5 class="alt-font text-extra-dark-gray font-weight-600 mb-0">We provide high quality and cost effective offshore web development services</h5>                        
                    </div>
                </div>
                <div class="row">
                    <!-- start feature box item -->
                    <div class="col-12 col-md-4 sm-margin-30px-bottom wow fadeInUp">
                        <div class="feature-box-16 sm-width-100">
                            <img src="<?php echo base_url() ?>maintemp/images/ser.jpg" alt="">
                            <div class="feature-box-content text-center">
                                <div class="opacity-full-dark bg-extra-dark-gray"></div>
                                <div class="d-table h-100 w-100 position-relative">
                                    <div class="align-middle d-table-cell padding-15px-lr padding-20px-tb">
                                        <div class="text-white-2 alt-font text-medium margin-15px-bottom">We believe in creativity</div> 
                                        <p class="width-85 mx-auto text-extra-light-gray">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since.</p>
                                    </div>
                                </div>
                            </div>
                        </div>  
                    </div>
                    <!-- end feature box item -->
                    <!-- start feature box item -->
                    <div class="col-12 col-md-4 sm-margin-30px-bottom wow fadeInUp" data-wow-delay="0.25s">
                        <div class="feature-box-16 sm-width-100">
                            <img src="<?php echo base_url() ?>maintemp/images/ser2.jpg" alt="">
                            <div class="feature-box-content text-center text-white-2">
                                <div class="opacity-full-dark bg-extra-dark-gray"></div>
                                <div class="d-table h-100 w-100 position-relative">
                                    <div class="align-middle d-table-cell padding-15px-lr padding-20px-tb">
                                        <div class="text-white-2 alt-font text-medium margin-15px-bottom">We believe in quality</div> 
                                        <p class="width-85 mx-auto text-extra-light-gray">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- end feature box item -->
                    <!-- start feature box item -->
                    <div class="col-12 col-md-4 wow fadeInUp" data-wow-delay="0.6s">
                        <div class="feature-box-16 sm-width-100">
                            <img src="<?php echo base_url() ?>maintemp/images/ser3.jpg" alt="">
                            <div class="feature-box-content text-center text-white-2">
                                <div class="opacity-full-dark bg-extra-dark-gray"></div>
                                <div class="d-table h-100 w-100 position-relative">
                                    <div class="align-middle d-table-cell padding-15px-lr padding-20px-tb">
                                        <div class="text-white-2 alt-font text-medium margin-15px-bottom">We believe in relation</div> 
                                        <p class="width-85 mx-auto text-extra-light-gray">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- end feature box item -->
                </div> 
            </div>
        </section>
        <!-- end feature box section -->
        <!-- start feature box section  -->
        <section class="bg-extra-dark-gray">
            <div class="container-fluid">
                <div class="row">
                    <!-- start feature box item -->
                    <div class="col-12 col-xl-3 col-md-6 last-paragraph-no-margin lg-margin-30px-bottom wow fadeInLeft" data-wow-delay="0.6s">
                        <div class="padding-40px-lr text-center border-right border-width-1 border-color-medium-dark-gray lg-no-border-right sm-padding-15px-lr">
                            <h3 class="font-weight-300 letter-spacing-minus-2 text-deep-pink alt-font margin-10px-bottom">01</h3>
                            <span class="alt-font d-block text-uppercase text-small">Save your Time</span>
                            <span class="text-white-2 text-uppercase alt-font text-extra-large font-weight-700 margin-20px-bottom d-block">Best Services</span>
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley.</p>
                        </div>
                    </div>
                    <!-- end feature box item -->
                    <!-- start feature box item -->
                    <div class="col-12 col-xl-3 col-md-6 last-paragraph-no-margin lg-margin-30px-bottom wow fadeInLeft" data-wow-delay="0.4s">
                        <div class="padding-40px-lr text-center border-right border-color-medium-dark-gray lg-no-border-right sm-padding-15px-lr">
                            <h3 class="font-weight-300 letter-spacing-minus-2 text-deep-pink alt-font margin-10px-bottom">02</h3>
                            <span class="alt-font d-block text-uppercase text-small">All you Need</span>
                            <span class="text-white-2 text-uppercase alt-font text-extra-large font-weight-700 margin-20px-bottom d-block">Professional</span>
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley.</p>
                        </div>
                    </div>
                    <!-- end feature box item -->
                    <!-- start feature box item -->
                    <div class="col-12 col-xl-3 col-md-6 last-paragraph-no-margin md-margin-30px-bottom wow fadeInLeft" data-wow-delay="0.2s">
                        <div class="padding-40px-lr text-center border-right border-color-medium-dark-gray lg-no-border-right sm-padding-15px-lr">
                            <h3 class="font-weight-300 letter-spacing-minus-2 text-deep-pink alt-font margin-10px-bottom">03</h3>
                            <span class="alt-font d-block text-uppercase text-small">Dedicated Supports</span>
                            <span class="text-white-2 text-uppercase alt-font text-extra-large font-weight-700 margin-20px-bottom d-block">Support</span>
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley.</p>
                        </div>
                    </div>
                    <!-- end feature box item -->
                    <!-- start feature box item -->
                    <div class="col-12 col-xl-3 col-md-6 last-paragraph-no-margin wow fadeInLeft">
                        <div class="padding-40px-lr text-center sm-padding-15px-lr">
                            <h3 class="font-weight-300 letter-spacing-minus-2 text-deep-pink alt-font margin-10px-bottom">04</h3>
                            <span class="alt-font d-block text-uppercase text-small">Creative Thinking</span>
                            <span class="text-white-2 text-uppercase alt-font text-extra-large font-weight-700 margin-20px-bottom d-block">Lorem Ipsum is </span>
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley.</p>
                        </div>
                    </div>
                    <!-- end feature box item -->
                </div>
            </div>
        </section>
        <!-- end feature box section  -->
        <!-- start feature box section -->
        <section class="wow fadeIn">
            <div class="container">
                <div class="row">
                    <div class="col-12 text-center">
                        <img src="<?php echo base_url() ?>maintemp/images/image-right.png" alt=""/>
                    </div>
                </div>
            </div>
            <div class="container margin-one-top lg-margin-three-top md-no-margin-top">  
                <div class="row">
                    <div class="col-12 col-lg-4 text-center text-lg-left md-margin-40px-bottom sm-margin-30px-bottom">
                        <h5 class="text-extra-dark-gray font-weight-600 alt-font mb-0">Lorem Ipsum is simply dummy</h5>
                    </div>
                    <!-- start feature box item -->
                    <div class="col-12 col-lg-4 col-md-6 text-center text-lg-left sm-margin-30px-bottom wow fadeIn last-paragraph-no-margin" data-wow-delay="0.2s">
                        <div class="row m-0">
                            <div class="col-12 col-lg-3 text-center md-no-padding-lr">
                                <h2 class="text-light-gray alt-font letter-spacing-minus-3 mb-0 md-margin-10px-bottom">01</h2>
                            </div>
                            <div class="col-12 col-lg-9 margin-5px-top text-center text-lg-left md-no-margin-top sm-no-padding-lr">
                                <span class="alt-font text-medium text-extra-dark-gray margin-5px-bottom d-block">Modern Framework</span>
                                <p class="width-80 lg-width-100">Lorem Ipsum is simply text the printing and typesetting standard industry.</p>
                            </div>
                        </div>
                    </div>
                    <!-- end feature box item -->
                    <!-- start feature box item -->
                    <div class="col-12 col-lg-4 col-md-6 text-center text-lg-left wow fadeIn last-paragraph-no-margin" data-wow-delay="0.4s">
                        <div class="row m-0">
                            <div class="col-12 col-lg-3 text-center sm-no-padding-lr">
                                <h2 class="text-light-gray alt-font letter-spacing-minus-3 mb-0 md-margin-10px-bottom">02</h2>
                            </div>
                            <div class="col-12 col-lg-9 margin-5px-top text-center text-lg-left md-no-margin-top sm-no-padding-lr">
                                <span class="alt-font text-medium text-extra-dark-gray margin-5px-bottom d-block">Live Website Builder</span>
                                <p class="width-80 lg-width-100">Lorem Ipsum is simply text the printing and typesetting standard industry.</p>
                            </div>
                        </div>
                    </div>
                    <!-- end feature box item -->
                </div>
            </div>
        </section>
        <!-- start feature box section -->
       
           
    
    <?php include 'footer.php';?>


        <!-- end footer -->
        <!-- start scroll to top -->
        <a class="scroll-top-arrow" href="javascript:void(0);"><i class="ti-arrow-up"></i></a>
        <!-- end scroll to top  -->
        <!-- javascript libraries -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/modernizr.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/bootstrap.bundle.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.easing.1.3.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/skrollr.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/smooth-scroll.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.appear.js"></script>
        <!-- menu navigation -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/bootsnav.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.nav.js"></script>
        <!-- animation -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/wow.min.js"></script>
        <!-- page scroll -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/page-scroll.js"></script>
        <!-- swiper carousel -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/swiper.min.js"></script>
        <!-- counter -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.count-to.js"></script>
        <!-- parallax -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.stellar.js"></script>
        <!-- magnific popup -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.magnific-popup.min.js"></script>
        <!-- portfolio with shorting tab -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/isotope.pkgd.min.js"></script>
        <!-- images loaded -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/imagesloaded.pkgd.min.js"></script>
        <!-- pull menu -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/classie.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/hamburger-menu.js"></script>
        <!-- counter  -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/counter.js"></script>
        <!-- fit video  -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.fitvids.js"></script>
        <!-- skill bars  -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/skill.bars.jquery.js"></script> 
        <!-- justified gallery  -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/justified-gallery.min.js"></script>
        <!--pie chart-->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.easypiechart.min.js"></script>
        <!-- instagram -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/instafeed.min.js"></script>
        <!-- retina -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/retina.min.js"></script>
        <!-- revolution -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/revolution/js/jquery.themepunch.tools.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/revolution/js/jquery.themepunch.revolution.min.js"></script>
        <!-- revolution slider extensions (load below extensions JS files only on local file systems to make the slider work! The following part can be removed on server for on demand loading) -->
        <!--<script type="text/javascript" src="revolution/js/extensions/revolution.extension.actions.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.carousel.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.kenburn.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.layeranimation.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.migration.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.navigation.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.parallax.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.slideanims.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.video.min.js"></script>-->
        <!-- setting -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/main.js"></script>
    </body>
</html>