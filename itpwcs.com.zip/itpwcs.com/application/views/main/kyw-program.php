﻿<!doctype html>
<html class="no-js" lang="en">
    <head>
        <!-- title -->
        <title>ITPWCS</title>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1" />
        <meta name="author" content=" ">
        <!-- description -->
        <meta name="description" content="ITPWCS">
        <!-- keywords -->
        <meta name="keywords" content="ITPWCS">
        <!-- favicon -->
        <link rel="shortcut icon" href="<?php echo base_url() ?>maintemp/images/favicon.png">
<!--         <link rel="apple-touch-icon" href="images/apple-touch-icon-57x57.png">
        <link rel="apple-touch-icon" sizes="72x72" href="images/apple-touch-icon-72x72.png">
        <link rel="apple-touch-icon" sizes="114x114" href="images/apple-touch-icon-114x114.png"> -->
        <!-- animation -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/animate.css" />
        <!-- bootstrap -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/bootstrap.min.css" />
        <!-- et line icon --> 
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/et-line-icons.css" />
        <!-- font-awesome icon -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/font-awesome.min.css" />
        <!-- themify icon -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/themify-icons.css">
        <!-- swiper carousel -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/swiper.min.css">
        <!-- justified gallery  -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/justified-gallery.min.css">
        <!-- magnific popup -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/magnific-popup.css" />
        <!-- revolution slider -->
        <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>maintemp/revolution/css/settings.css" media="screen" />
        <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>maintemp/revolution/css/layers.css">
        <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>maintemp/revolution/css/navigation.css">
        <!-- bootsnav -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/bootsnav.css">
        <!-- style -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/style.css" />
        <!-- responsive css -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/responsive.css" />
        <!--[if IE]>
            <script src="js/html5shiv.js"></script>
        <![endif]-->
    </head>
    <body>
        

    <?php $page = 'services';?>
    <?php include 'header.php';?>


    <!-- start page title section -->
    <section class="   padding-0px-tb  top-space"></section>
    <!-- end page title section -->


        <!-- start hero section -->
        <section class="pb-0 wow fadeIn" id="section-down">
            <div class="container">
                <div class="row ">
                    <div class="col-12  col-lg-7  text-left  last-paragraph-no-margin">
                        <h5 class="alt-font text-extra-dark-gray font-weight-600">KYW program (Know Your Workforce)</h5>
                        <p class=" mx-auto d-inline-block sm-width-100">To build a productive and competent team of workforce at your organization, ITPCWS offers your employees a range of holistic and rewarding employee empowerment and engagement activities. The latest researches suggest that empowering your team results in improved productivity, job satisfaction, and significantly boosts the commitment of employees to meet the business goals.<br><br> 

We all know that the success of an enterprise depends largely on the performance of their employees. Why most of the companies fail to achieve desired growth in today’s competitive world is mainly because of the unmotivated and less enthusiastic workforce. To address the critical concerns of the employees and equipping them to think, act, and take business-decisions in self-sufficient and graceful ways, ITPWCS offers key secret employee empowerment plans for companies.
</p><br><br>
                        
                    </div>
                    <div class="col-12 col-lg-5 text-left   md-margin-40px-bottom sm-margin-30px-bottom">
                        <img src="images/smart-1.png">
                    </div>
<!-- 

                    <div class="col-md-12">
                        <div class="caption">
                            <h5>Our professional job hiring strategy goes through three levels of talent acquisition.</h5>
                            <div class="caption-qa"></div>
                        </div>
                    </div> -->
            </div>
        </section>
        <!-- end banner section -->
   <section>
<div class="container">
  <div class="row">
    <div class="col-md-12  ">
    <h6 class="text-extra-dark-gray  alt-font ">Key Benefits</h6>

                         <ul class="p-0 list-style-1 list-2">
                            <ol>
                            <li class="bg-green"> Discover employees’ prospects, increasing potency & effectiveness.</li>
                            <li class="bg-green"> HR coaching & development supported worker talent</li>
                            <li class="bg-green"> Know your worker Leadership style and qualities</li>
                            <li class="bg-green"> Know your internal talents your employee’s</li>
                            <li class="bg-green"> Reduce expense & maximize company price.</li>
                            <li class="bg-green"> Know your worker designing and delivery vogue</li>
                            <li class="bg-green"> Develop an all star employees.</li>
                            <li class="bg-green"> Reorganize the utilized pool for prime productivity.</li>
                            <li class="bg-green"> Entrust your employee WHO has the foremost potential.</li>
                            <li class="bg-green"> Improve human resources management additional with efficiency</li>
                            </ol>
                        </ul>
                    </div>
                </div>
            </div>
 </section>


        <!-- start feature box section -->
        <section style="padding-top: 0px;" class="parallax bg2 wow fadeIn" data-stellar-background-ratio="0.4"  >

            <div class="container">
 
        <div class="row">
            <div class="col-md-12 text-center">
                <h6>The 3 Key Steps to Employee Empowerment</h6>
            </div>
        </div>

        <div class="row step three">
            <div style="padding-top: 4px;" class="col-4 col-lg-4 activestep" onclick="javascript: resetActive(event, 0, 'step-1');">
               <div class="padding-35px-all d-inline-block rounded-circle sm-margin-30px-bottom "><img src="<?php echo base_url() ?>maintemp/images/pro-11.png" alt=""/></div>
                
            </div>

            <div class="col-4 col-lg-4" onclick="javascript: resetActive(event, 10, 'step-2');">
              <div class="padding-35px-all d-inline-block rounded-circle sm-margin-30px-bottom "><img src="<?php echo base_url() ?>maintemp/images/pro-22.png" alt=""/></div>
                
            </div>

            <div class="col-4 col-lg-4" onclick="javascript: resetActive(event, 20, 'step-3');">
                 <div class="padding-35px-all d-inline-block rounded-circle sm-margin-30px-bottom "><img src="<?php echo base_url() ?>maintemp/images/pro-33.png" alt=""/></div>
                 
            </div>
            
        </div>
 
   
  
    
 
</div>



                </div>
            </div>
        </section>
        <!-- end feature box section -->
       
 <section>



<section style=" padding-top: 0px; padding-bottom: 50px;" class="wow fadeIn">
            <div class="container tab-style2">
                <div class="row">
                    <div class="col-12">
                        <!-- tab navigation -->
                        <ul class="nav nav-tabs alt-font text-uppercase text-small text-center font-weight-600 justify-content-center">

                            <li class="nav-item"><a href="#tab_sec1" class="nav-link active" data-toggle="tab">Collect Employee Details & Job Roles</a></li>
                            <li class="nav-item" style="margin-right: 190px; margin-left: 190px;"><a href="#tab_sec2" class="nav-link" data-toggle="tab">Screening</a></li>
                            <li class="nav-item"><a href="#tab_sec3" class="nav-link" data-toggle="tab">Reengineering</a></li>
                           
                        </ul>
                        <!-- tab end navigation -->
                    </div>
                </div>                                
                <div class="tab-content">
                    <!-- start tab content -->
                    <div class="tab-pane med-text fade show active" id="tab_sec1">
                        <div class="row align-items-center">
                            <div class="col-12 col-md-6 sm-margin-30px-bottom">
                                <img src="<?php echo base_url() ?>maintemp/images/pro-11.png" class="w-100" alt=""/>
                            </div>
                            <div class="col-12 col-lg-6 col-md-6 ">
                                <h6 class="alt-font font-weight-700 ged-txt margin-20px-bottom text-uppercase">Job Role Analysis</h6>

                            
                                <p>Our team gathers the updated employee information to identify the personal attributes, skills, demographic information, and professional roles of each employee. Other details such as their association with various projects and teams, promotion hierarchy, awards and achievements, and health status are collected by maintaining the highest degree of confidentiality.</p>
                                
                            </div>
                        </div>
                    </div>
                    <!-- end tab content -->
                    <!-- start tab content -->
                    <div class="tab-pane fade in" id="tab_sec2">
                        <div class="row align-items-center">
                            <div class="col-12 col-md-6 sm-margin-30px-bottom">
                                <img src="<?php echo base_url() ?>maintemp/images/pro-22.png" class="w-100" alt=""/>
                            </div>
                            <div class="col-12 col-lg-6 col-md-6 ">
                                <h6 class="alt-font font-weight-700 ged-txt margin-20px-bottom text-uppercase">Screening Assessment Planning</h6>
                            
                                <p>An effective psychological assessment or a psychometric test is conducted for the employees to identify the mental abilities, behavioral style, and the appropriateness for the assigned job roles. ITPWCS has a well-seasoned team of experts who have a proven track record of assessing the problems of employees and defining beneficial solutions for the development of employees and organizations.</p>
                                
                                
                            </div>
                        </div>
                    </div>
                    <!-- end tab content -->
                    <!-- start tab content -->
                    <div class="tab-pane fade in" id="tab_sec3">
                        <div class="row align-items-center">
                            <div class="col-12 col-md-6 sm-margin-30px-bottom">
                                <img src="<?php echo base_url() ?>maintemp/images/pro-33.png" class="w-100" alt=""/>
                            </div>
                            <div class="col-12 col-lg-6 col-md-6 ">
                                <h6 class="alt-font font-weight-700  ged-txt margin-20px-bottom text-uppercase">Schedule an interview</h6>
                                
                                <p>The result of our employee assessment test is analyzed by our team of examiners to learn the underlying problems and challenges they face, realize their suitability, strengths, and provide feedback to the top-level management with an efficient solution that proposes for valuable initiatives and specific areas that are subjected to development.</p>

                            </div>
                        </div>
                    </div>
                    <!-- end tab content -->
                    <!-- start tab content -->
                    <!-- end tab content -->
                </div>       
            </div>
        </section>
        <!-- end tabs section -->

           
     <section style="padding-top: 0px;">
     
    <div class="container">
       <div class="row">
          <div class="col-md-12  ">
            <h6 class="text-extra-dark-gray  alt-font ">Why we are unique?</h6>
        </div>
           <div class="col-md-6  ">
             <div class=" bg-drk">  
             <div class=" row ">   
                <div class="col-md-4">
                <img src="<?php echo base_url() ?>maintemp/images/unique1.png" width="100%" alt=""/></div>
                <div class="col-md-8  padding-45px-tb">
                <b>Reliable Assessment for IT Job Positions</b>
                <p>350+ job identification and assessment adhering to best industrial practices</p>
            </div>
            </div>
        </div></div>
           <div class="col-md-6  ">
             <div class=" bg-drk">  
             <div class=" row ">     
                <div class="col-md-4">
               <img src="<?php echo base_url() ?>maintemp/images/unique2.png" alt=""/>
                </div>
                <div class="col-md-8 padding-45px-tb">
                <b> Big Participation of 100+ IT Companies</b>
                <p>Emerge with the participation of high-performing and major tech companies</p>
                </div>
            </div>
            </div></div>

            <div class="col-md-6  ">
             <div class=" bg-drk">  
             <div class=" row ">    
                <div class="col-md-4">
                    <img src="<?php echo base_url() ?>maintemp/images/unique3.png" alt=""/>
                </div>
                <div class="col-md-8  padding-45px-top padding-25px-bottom">
                    <b>The Trusted Society Backed By Govt. & Private Sector</b>
                    <p>Dedicated to promoting technology adoption across diverse IT sectors to capitalize on productivity and performance</p>
                 </div>
            </div>
            </div>            </div>
                 
            <div class="col-md-6  ">
             <div class=" bg-drk">  
             <div class=" row ">   
                <div class="col-md-4">               
                 <img src="<?php echo base_url() ?>maintemp/images/unique4.png" alt=""/>
                </div>
                <div class="col-md-8 padding-45px-tb">

                <b>24/7/365 Limitless Support from Top Tech Giantsr</b>
                <p>Tremendous professional support from the biggest technology companies in Kerala</p>
             </div>
            </div>     
            </div>
             
    </div>
</div>
</div>

 </section>

 <section class="wow fadeIn testiminial">
    <h4>TESTIMONIALS</h4>
     <div class="container px-2 px-md-4 py-5 mx-auto wow fadeInUp" data-wow-delay="0.6s">

     <div class="row d-flex justify-content-center ">
         <div class="col-md-10">
             <div id="carouselExampleIndicators" class="carousel slide d-flex" data-ride="carousel">
                 <ol class="carousel-indicators">
                     <li data-target="#carouselExampleIndicators" data-slide-to="0"></li>
                     <li data-target="#carouselExampleIndicators" data-slide-to="1" class="active"></li>
                     <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                 </ol>
                 <div class="carousel-inner ">
                     <div class="carousel-item testi">
                         <div class="card border-0 ">
                             <div class="card-header">
                                <h5>I believe that one defines oneself by reinvention. To not be like your parents. To not be like your friends. To be yourself. To cut yourself out of stone.</h5>
                             </div>
                             <div class="card-body text-center "><img class="img-1 img-fluid" src="https://i.imgur.com/nUNhspp.jpg">
                                 <div class="testi-p">
                                     
                                     <h6>Sophia V./ Company Inc</h6>
                                     <p>Wholises</p>
                                 </div>
                             </div>
                         </div>
                     </div>
                     <div class="carousel-item testi active">
                         <div class="card border-0 ">
                             <div class="card-header">
                                <h5>I believe that one defines oneself by reinvention. To not be like your parents. To not be like your friends. To be yourself. To cut yourself out of stone.</h5>
                             </div>
                             <div class="card-body text-center "><img class="img-1 img-fluid" src="https://i.imgur.com/kkjs7EC.png">
                                 <div class="testi-p">
                                     
                                     <h6>Sophia V./ Company Inc</h6>
                                     <p>Wholises</p>
                                 </div>
                             </div>
                         </div>
                     </div>
                     <div class="carousel-item testi">
                         <div class="card border-0 ">
                             <div class="card-header">
                               <h5>I believe that one defines oneself by reinvention. To not be like your parents. To not be like your friends. To be yourself. To cut yourself out of stone.</h5>
                             </div>
                             <div class="card-body text-center "><img class="img-1 img-fluid" src="https://i.imgur.com/At1IG6H.png">
                                 <div class="testi-p">
                                     
                                    <h6>Sophia V./ Company Inc</h6>
                                     <p>Wholises</p>
                                 </div>
                             </div>
                         </div>
                     </div>
                 </div>
             </div>
         </div>
     </div>
 </div>
</section>
       
    <?php include 'footer.php';?>


        <!-- end footer -->
        <!-- start scroll to top -->
        <a class="scroll-top-arrow" href="javascript:void(0);"><i class="ti-arrow-up"></i></a>

        <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
        <!-- end scroll to top  -->
        <!-- javascript libraries -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/modernizr.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/bootstrap.bundle.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.easing.1.3.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/skrollr.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/smooth-scroll.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.appear.js"></script>
        <!-- menu navigation -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/bootsnav.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.nav.js"></script>
        <!-- animation -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/wow.min.js"></script>
        <!-- page scroll -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/page-scroll.js"></script>
        <!-- swiper carousel -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/swiper.min.js"></script>
        <!-- counter -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.count-to.js"></script>
        <!-- parallax -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.stellar.js"></script>
        <!-- magnific popup -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.magnific-popup.min.js"></script>
        <!-- portfolio with shorting tab -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/isotope.pkgd.min.js"></script>
        <!-- images loaded -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/imagesloaded.pkgd.min.js"></script>
        <!-- pull menu -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/classie.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/hamburger-menu.js"></script>
        <!-- counter  -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/counter.js"></script>
        <!-- fit video  -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.fitvids.js"></script>
        <!-- skill bars  -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/skill.bars.jquery.js"></script> 
        <!-- justified gallery  -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/justified-gallery.min.js"></script>
        <!--pie chart-->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.easypiechart.min.js"></script>
        <!-- instagram -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/instafeed.min.js"></script>
        <!-- retina -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/retina.min.js"></script>
        <!-- revolution -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/revolution/js/jquery.themepunch.tools.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/revolution/js/jquery.themepunch.revolution.min.js"></script>
        <!-- revolution slider extensions (load below extensions JS files only on local file systems to make the slider work! The following part can be removed on server for on demand loading) -->
        <!--<script type="text/javascript" src="revolution/js/extensions/revolution.extension.actions.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.carousel.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.kenburn.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.layeranimation.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.migration.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.navigation.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.parallax.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.slideanims.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.video.min.js"></script>-->
        <!-- setting -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/main.js"></script>





<script type="text/javascript">
    
function resetActive(event, percent, step) {
        $(".progress-bar").css("width", percent + "%").attr("aria-valuenow", percent);
        $(".progress-completed").text(percent + "%");

        $("div").each(function () {
            if ($(this).hasClass("activestep")) {
                $(this).removeClass("activestep");
            }
        });

        if (event.target.className == "col-md-2") {
            $(event.target).addClass("activestep");
        }
        else {
            $(event.target.parentNode).addClass("activestep");
        }

        hideSteps();
        showCurrentStepInfo(step);
    }

    function hideSteps() {
        $("div").each(function () {
            if ($(this).hasClass("activeStepInfo")) {
                $(this).removeClass("activeStepInfo");
                $(this).addClass("hiddenStepInfo");
            }
        });
    }

    function showCurrentStepInfo(step) {        
        var id = "#" + step;
        $(id).addClass("activeStepInfo");
    }



</script>
    </body>
</html>