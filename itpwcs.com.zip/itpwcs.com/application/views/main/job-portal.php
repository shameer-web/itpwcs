﻿<!doctype html>
<html class="no-js" lang="en">
    <head>
        <!-- title -->
        <title>ITPWCS</title>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1" />
        <meta name="author" content=" ">
        <!-- description -->
        <meta name="description" content="ITPWCS">
        <!-- keywords -->
        <meta name="keywords" content="ITPWCS">
        <!-- favicon -->
        <link rel="shortcut icon" href="<?php echo base_url() ?>maintemp/images/favicon.png">
<!--         <link rel="apple-touch-icon" href="images/apple-touch-icon-57x57.png">
        <link rel="apple-touch-icon" sizes="72x72" href="images/apple-touch-icon-72x72.png">
        <link rel="apple-touch-icon" sizes="114x114" href="images/apple-touch-icon-114x114.png"> -->
        <!-- animation -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/animate.css" />
        <!-- bootstrap -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/bootstrap.min.css" />
        <!-- et line icon --> 
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/et-line-icons.css" />
        <!-- font-awesome icon -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/font-awesome.min.css" />
        <!-- themify icon -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/themify-icons.css">
        <!-- swiper carousel -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/swiper.min.css">
        <!-- justified gallery  -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/justified-gallery.min.css">
        <!-- magnific popup -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/magnific-popup.css" />
        <!-- revolution slider -->
        <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>maintemp/revolution/css/settings.css" media="screen" />
        <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>maintemp/revolution/css/layers.css">
        <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>maintemp/revolution/css/navigation.css">
        <!-- bootsnav -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/bootsnav.css">
        <!-- style -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/style.css" />
        <!-- responsive css -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/responsive.css" />
        <!--[if IE]>
            <script src="js/html5shiv.js"></script>
        <![endif]-->
    </head>
    <body>
        

    <?php $page = 'members';?>
    <?php include 'header.php';?>

    <!-- start page title section -->
    <section class="   padding-0px-tb  top-space"></section>
    <!-- end page title section -->

 
    
        
        <!-- end page title section -->
         
        
           <section class="  padding-0px-tb  memb  fadeIn">
            <div class="container job-search">
                <h2 style="font-family: 'Montserrat', sans-serif; color: #000; font-size: 30px; padding-top: 40px; font-weight: 600; text-align: center;">Welcome to ITPWCS Job Portal</h2>
                <div class="row">
                   <div class="col-md-8 m-auto">
                    <div class="row">
                       <div class="col-md-4"> <div class="frm-drp"><div class="form-group mb-2">
                <label>Sort by City<span style="color: #cc0202;">*</span></label>
                   <select class="browser-default custom-select mb-4">
            <option value="" selected="">Select Country</option>
            <option value="1" selected="">India</option>
            <option value="2">Brazil</option>
            <option value="3">China</option>
          </select>

               </div>
            </div></div>
                       <div class="col-md-4"> <div class="frm-drp"><div class="form-group mb-2">
                <label>Sort by Digree</label>
                   <select class="browser-default custom-select mb-4">
            <option value="" selected="">Select Country</option>
            <option value="1" selected="">India</option>
            <option value="2">Brazil</option>
            <option value="3">China</option>
          </select>

               </div>
            </div></div>
                       <div class="col-md-4"> <div class="frm-drp"><div class="form-group mb-2">
                <label>Sort by 
Experience<span style="color: #cc0202;">*</span></label>
                   <select class="browser-default custom-select mb-4">
            <option value="" selected="">Select Country</option>
            <option value="1" selected="">India</option>
            <option value="2">Brazil</option>
            <option value="3">China</option>
          </select>

               </div>
            </div>
        </div>

            <!-- Search form -->
            <div style="background-color: #09c976; border-radius: 50px;" class="col-md-8 search-btn m-auto">
                <form class="form-inline active-cyan-4">
  <input style="border: 1px solid #09c976; border-radius: 30px; height: 46px; margin-top: 30px; margin-left: 55px;" class="form-control form-control-sm mr-3 w-75" type="text" placeholder="Search"
    aria-label="Search">
  <i style="font-size: 24px; padding-top: 10px; color: #fff;" class="fas fa-search" aria-hidden="true"></i>
</form>
            </div>

<div style="display: block; width: 100%; clear: both; margin-bottom: 50px;" class="clearfix"></div>

                   </div>
                   </div>
                </div>
            </div>
        </section>
        <!-- start feature box section -->
        

 
     
       
    <?php include 'footer.php';?>

        <!-- javascript libraries -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/modernizr.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/bootstrap.bundle.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.easing.1.3.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/skrollr.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/smooth-scroll.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.appear.js"></script>
        <!-- menu navigation -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/bootsnav.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.nav.js"></script>
        <!-- animation -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/wow.min.js"></script>
        <!-- page scroll -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/page-scroll.js"></script>
        <!-- swiper carousel -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/swiper.min.js"></script>
        <!-- counter -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.count-to.js"></script>
        <!-- parallax -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.stellar.js"></script>
        <!-- magnific popup -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.magnific-popup.min.js"></script>
        <!-- portfolio with shorting tab -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/isotope.pkgd.min.js"></script>
        <!-- images loaded -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/imagesloaded.pkgd.min.js"></script>
        <!-- pull menu -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/classie.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/hamburger-menu.js"></script>
        <!-- counter  -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/counter.js"></script>
        <!-- fit video  -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.fitvids.js"></script>
        <!-- skill bars  -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/skill.bars.jquery.js"></script> 
        <!-- justified gallery  -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/justified-gallery.min.js"></script>
        <!--pie chart-->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.easypiechart.min.js"></script>
        <!-- instagram -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/instafeed.min.js"></script>
        <!-- retina -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/retina.min.js"></script>
        <!-- revolution -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/revolution/js/jquery.themepunch.tools.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/revolution/js/jquery.themepunch.revolution.min.js"></script>
        <!-- revolution slider extensions (load below extensions JS files only on local file systems to make the slider work! The following part can be removed on server for on demand loading) -->
        <!--<script type="text/javascript" src="revolution/js/extensions/revolution.extension.actions.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.carousel.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.kenburn.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.layeranimation.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.migration.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.navigation.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.parallax.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.slideanims.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.video.min.js"></script>-->
        <!-- setting -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/main.js"></script>
    </body>
</html>