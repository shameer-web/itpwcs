<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <header class="header-with-topbar join-btn">
             
            <div class="top-header-area bg-white sm-no-padding   padding-7px-top">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-md-6 text-uppercase alt-font d-flex align-items-center justify-content-center justify-content-md-start">
                             
                            
                        </div>  
                        <div class="col-md-6 d-none text-uppercase d-md-flex align-items-center justify-content-end">
                            <!-- <div class="icon-social-very-small display-inline-block line-height-normal">
                                <a href="https://www.facebook.com/" title="Facebook" target="_blank" class="text-link-white-2"><i class="fab fa-facebook-f" aria-hidden="true"></i></a>
                                <a href="https://twitter.com/" title="Twitter" target="_blank" class="text-link-white-2"><i class="fab fa-twitter"></i></a>
                                <a href="https://linkedin.com/" title="Linked In" target="_blank" class="text-link-white-2"><i class="fab fa-linkedin-in"></i></a>
                                <a href="https://plus.google.com" title="Google Plus" target="_blank" class="text-link-white-2"><i class="fab fa-google-plus-g"></i></a>                            
                            </div> -->  
                             <a href="<?php echo base_url() ?>Main/about" class="text-link-dark-gray-2 line-height-normal">About Us</a>  <div class="separator-line-verticle-extra-small bg-dark-gray display-inline-block margin-two-half-lr position-relative vertical-align-middle top-1px"></div>
                                    <a href="<?php echo base_url() ?>Main/contact" class="text-link-dark-gray-2 line-height-normal">Contact Us</a> 
                                    <div class="separator-line-verticle-extra-small bg-dark-gray display-inline-block margin-two-half-lr position-relative vertical-align-middle top-1px"></div> 
                            
                       <a href="mailto:info@itpwcs.com" class="text-link-dark-gray-2 line-height-normal" title="info@itpwcs.com">info@itpwcs.com</a>
                        

                         
                        
                     
                           <a id="desk" class="btn btn-very-small mrg-lft btn-dark-gray btn-rounded lg-margin-15px-bottom d-table d-lg-inline-block md-margin-lr-auto " href="<?php echo base_url() ?>Main/already_member">login</a>
                           
             <a id="desk" class="btn btn-very-small mrg-lft btn-dark-gray btn-rounded lg-margin-15px-bottom d-table d-lg-inline-block md-margin-lr-auto " href="<?php echo base_url() ?>Main/membership">Join</a>
<!--<button type="button" class="btn btn-primary"  href="membership.php">Join</button>-->
                         
                      

                             
                        </div>
                    </div>
                </div>
            </div>
          
           
            <nav class="navbar navbar-default bootsnav navbar-top header-light-transparent background-transparent nav-box-width navbar-expand-lg">
                <div class="container nav-header-container">
                    <!-- start logo -->
                    <div class="col-auto pl-lg-0">
                        <a href="<?php echo base_url() ?>Main/home" title="Itpwcs" class="logo"><img src="<?php echo base_url() ?>maintemp/images/logo.png" data-rjs="images/logo@2x.png" class="logo-dark default" alt="Itpwcs"><!-- <img src="images/logo-white.png" data-rjs="images/logo-white@2x.png" alt="Pofo" class="logo-light"> --></a>
                    </div>
                    <!-- end logo -->
                    <div class="col accordion-menu pr-0 pr-md-3">
                        <button type="button" class="navbar-toggler collapsed" data-toggle="collapse" data-target="#navbar-collapse-toggle-1">
                            <span class="sr-only">toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <div class="navbar-collapse collapse justify-content-end" id="navbar-collapse-toggle-1">
                            <ul id="accordion" class="nav navbar-nav navbar-left no-margin alt-font text-normal" data-in="fadeIn" data-out="fadeOut">

                                <li id="mob"><a class="btn btn-very-small mrg-lft btn-dark-gray btn-rounded   d-table d-lg-inline-block md-margin-lr-auto one" href="<?php echo base_url() ?>Main/already_member">login</a></li>
                     <li id="mob"><a class="btn mrg-lft btn-very-small btn-dark-new  btn-rounded   d-table d-lg-inline-block md-margin-lr-auto two" href="#">Join</a></li>
                                <!-- start menu item -->
                                <li class="dropdown megamenu-fw">
                                    <a href="<?php echo base_url() ?>Main/home">Itpwcs</a>  
                                    <!-- start sub menu -->
                                </li>


                                <li class="dropdown megamenu-fw">
                                    <a href="#">Members </a><i class="fas fa-angle-down dropdown-toggle" data-toggle="dropdown" aria-hidden="true"></i>
                                    <!-- start sub menu -->
                                    <div class="menu-back-div dropdown-menu megamenu-content mega-menu collapse mega-menu-full">
                                        <ul>

                                                  <!-- start sub menu column  -->
                                            <li class="mega-menu-column col-lg-3 d-none d-lg-block">
                                                <!-- start sub menu item  -->
                                                <ul>
                                                    <li>
                                                        <a href="#" class="menu-banner-image"><img src="<?php echo base_url() ?>maintemp/images/menu-banner-02.png" height="100px" alt="portfolio"/></a>
                                                    </li>
                                             
                                                </ul>
                                                <!-- end sub menu item  -->
                                            </li>
                                            <!-- end sub menu column  -->
                                            <!-- start sub menu column  -->
                           
                                            <!-- end sub menu column -->
                                            <!-- start sub menu column -->
                                            <li class="mega-menu-column col-lg-3">
                                                <!-- start sub menu item  -->
                                               <ul>
                                                    <li class="dropdown-header"><a style="padding: 0px; color: black;" href="<?php echo base_url() ?>Main/membership">STUDENTS </li>
                                                      <li><a href="<?php echo base_url() ?>Main/students">Students Membership</a></li>
                                                    
                                                    <li><a href="<?php echo base_url() ?>Main/stdntmfrm">Students Join Form</a></li>
                                                    <li><a href="<?php echo base_url() ?>Main/general">Genaral Membership</a></li>
                                                    
                                                    <li><a href="<?php echo base_url() ?>Main/general_form">Genaral Join Form</a></li>
     
                                                </ul>
                                     
                                           
                                            </li>
                                            <!-- end sub menu column  -->

                                            <li class="mega-menu-column col-lg-3">
                                             <ul>
                                                    <li class="dropdown-header"><a style="padding: 0px; color: black;" href="<?php echo base_url() ?>Main/membership">IT PROFESSIONAL</a> </li>
                                                    <li><a href="<?php echo base_url() ?>Main/professional">Professional Membership</a></li>
                                                   
                                                    <li><a href="<?php echo base_url() ?>Main/proffesional_form">Professional Join Form</a></li>
                                                   
                                                </ul>
                                      

                                            <!-- start sub menu column  -->
                                            <li class="mega-menu-column col-lg-3">
                                               
                                                <ul>
                                                    <li class="dropdown-header"><a style="padding: 0px; color: black;" href="<?php echo base_url() ?>Main/membership">CORPORATES</a></li>
                                                    
                                                    <li><a href="<?php echo base_url() ?>Main/corporates">Corporates Membership</a></li>
                                                    
                                                    <li><a href="<?php echo base_url() ?>Main/corporates_form">Corporates Join Form</a></li>
                                                </ul>
                                
                                            </li>
                                            <!-- end sub menu column  -->
                                      
                                        </ul>
                                        <!-- end sub menu -->
                                    </div>
                                </li>

                            
                            <li class="dropdown megamenu-fw">
                                    <a href="#">Services</a><i class="fas fa-angle-down dropdown-toggle" data-toggle="dropdown" aria-hidden="true"></i>
                                    <!-- start sub menu -->
                                    <div class="menu-back-div dropdown-menu megamenu-content mega-menu collapse mega-menu-full">
                                        <ul>
                                                                                      
                                            <li class="mega-menu-column col-lg-2 d-none d-lg-block">
                                                <!-- start sub menu item  -->
                                                <ul>
                                                    <li>
                                                        <a href="#" class="menu-banner-image"><img src="<?php echo base_url() ?>maintemp/images/menu-banner-03.png" height="100px" alt="portfolio"/></a>
                                                    </li>
                                             
                                                </ul>
                                                <!-- end sub menu item  -->
                                            </li>
                                            <!-- end sub menu column -->
                                            <!-- start sub menu column -->
                                            <li class="mega-menu-column col-lg-3">
                                                <!-- start sub menu item  -->
                                                <ul>
                                                    <li class="dropdown-header"><a style="padding: 0px; color: black;" href="">BRAIN MAPPING</a></li>
                                                    
                                                    <li><a href="<?php echo base_url() ?>Main/whatisbmit">What is BMIT</a></li>
                                                    <li><a href="<?php echo base_url() ?>Main/bmp">BMP(Brain Mapping for IT Professionals)</a></li>
                                                    <li><a href="<?php echo base_url() ?>Main/bms">BMS(Brain Mapping for Students)</a></li>
                                                   
                                                   
                                                </ul>
                                                <!-- end sub menu item  -->
                                            </li>
                                            <!-- end sub menu column  -->

                                            <!-- start sub menu column  -->
                                            <li class="mega-menu-column col-lg-4">
                                                <!-- start sub menu item  -->
                                                <ul>
                                                    
                                                    <li class="dropdown-header"><a style="padding: 0px; color: black;" href="">RECRUITMENT</a></li>
                                                    <li><a href="<?php echo base_url() ?>Main/smart_hiring">Smart Hiring Platform</a></li><li><a href="<?php echo base_url() ?>Main/intelligent_campus">Intelligent Campus Recruitment</a></li>
                                                    <li><a href="<?php echo base_url() ?>Main/kyw_program">KYW program (Know Your Workforce</a></li>
                                      
                                                    
                                                </ul>
                                                <!-- end sub menu item  -->
                                            </li>
                                            <!-- end sub menu column  -->
                                            <!-- start sub menu column  -->
                                           
                                            <!-- end sub menu column  -->
                                        </ul>
                                        <!-- end sub menu -->
                                    </div>
                                </li>
                                <li class="dropdown megamenu-fw">
                                    <a href="<?php echo base_url() ?>Main/job_portal">Job portal </a><i class="fas fa-angle-down dropdown-toggle" aria-hidden="true"></i>
                                    <!-- start sub menu -->
                                    
                                </li>
                                <li class="dropdown megamenu-fw">
                                    <a href="#">News & Blogs </a><i class="fas fa-angle-down dropdown-toggle" data-toggle="dropdown" aria-hidden="true"></i>
                                    <!-- start sub menu -->
                                    <div class="menu-back-div dropdown-menu megamenu-content mega-menu collapse mega-menu-full">
                                        <ul>

                                             <li class="mega-menu-column col-lg-3 d-none d-lg-block">
                                                <!-- start sub menu item  -->
                                                <ul>
                                                    <li>
                                                        <a href="#" class="menu-banner-image"><img src="<?php echo base_url() ?>maintemp/images/menu-banner-02.png" height="100px" alt="portfolio"/></a>
                                                    </li>
                                             
                                                </ul>
                                                <!-- end sub menu item  -->
                                            </li>

                                                  <!-- start sub menu column  -->
                                            
                                            <!-- end sub menu column  -->
                                            <!-- start sub menu column  -->
                           
                                            <!-- end sub menu column -->
                                            <!-- start sub menu column -->
                                            <li class="mega-menu-column col-lg-3">
                                                <!-- start sub menu item  -->
                                               <ul>
                                                    <li class="dropdown-header"><a style="padding: 0px; color: black;" href="">SUCCESS STORIES</a></li>
                                                     
                                                      <li><a href="">Lorem ipsoum</a></li>
                                                    <li><a href="">Lorem ipsoum</a></li>
                                                    <li><a href="">Lorem ipsoum</a></li>
                                                    <li class="dropdown-header"><a style="padding: 0px; color: black;" href="">CAREER DEVELOPEMENT</a></li>
                                                     
                                                      
                                                      <li><a href="">Lorem ipsoum</a></li>
                                                    <li><a href="">Lorem ipsoum</a></li>
                                                    
     
                                                </ul>
                                     
                                           
                                            </li>
                                            <!-- end sub menu column  -->

                                            <li class="mega-menu-column col-lg-3">
                                             <ul>
                                                    <li class="dropdown-header"><a style="padding: 0px; color: black;" href="">FOR COMPANIES</a> </li>
                                                    
                                                    <li><a href="">Lorem ipsoum</a></li>
                                                    <li><a href="">Lorem ipsoum</a></li>
                                                    <li><a href="">Lorem ipsoum</a></li>
                                                    <li class="dropdown-header"><a style="padding: 0px; color: black;" href="">RECENT POST</a></li>
                                                   
                                                    <li><a href="">Lorem ipsoum</a></li>
                                                    <li><a href="">Lorem ipsoum</a></li>
                                                   
                                                </ul>
                                      

                                            <!-- start sub menu column  -->
                                            <li class="mega-menu-column col-lg-3">
                                               
                                                <ul>
                                                    <li class="dropdown-header"><a style="padding: 0px; color: black;" href="">NEWS</a></li>
                                                    
                                                    
                                                    <li><a href="">Lorem ipsoum</a></li>
                                                    <li><a href="">Lorem ipsoum</a></li>
                                                </ul>
                                
                                            </li>
                                            <!-- end sub menu column  -->
                                      
                                        </ul>
                                        <!-- end sub menu -->
                                    </div>
                                </li>
                                  <!-- end menu item -->
                                <li class="dropdown simple-dropdown"><a href="#">Events</a><i class="fas fa-angle-down dropdown-toggle" data-toggle="dropdown" aria-hidden="true"></i>
                                    <!-- start sub menu -->
                                    <ul class="dropdown-menu" role="menu">
                                         
                                        <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="<?php echo base_url() ?>Main/webinar"> Webinar <i class="fas fa-angle-right"></i></a>
                                            <ul class="dropdown-menu">
                                                <li><a href="<?php echo base_url() ?>Main/ondemand_webinar">Ondemand  Webinars</a></li>
                                                
                                                <li><a href="<?php echo base_url() ?>Main/webinar">Webinars</a></li>
                                                 
                                            </ul>
                                        </li>
                                        <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="<?php echo base_url() ?>Main/seminars">Seminars <i class="fas fa-angle-right"></i></a>
                                            <ul class="dropdown-menu">
                                                <li><a href="<?php echo base_url() ?>Main/college_seminar">College Seminars </a></li>
                                                
                                            </ul>
                                        </li>


                                    
                                         
                                    </ul>
                                </li>

                                <li id="mob" class="dropdown megamenu-fw" ><a href="<?php echo base_url() ?>Main/about">About</a></li>
                                         <li id="mob" class="dropdown megamenu-fw"><a href="<?php echo base_url() ?>Main/contact">Contact</a></li>
                                
                            </ul>
                        </div>
                    </div>
                    <div class="col-auto pr-lg-0">
                        <div class="header-searchbar">
                            <a href="#search-header" class="header-search-form"><i class="fas fa-search search-button"></i></a>
                            <!-- search input-->
                            <form id="search-header" method="post" action="search-result.html" name="search-header" class="mfp-hide search-form-result">
                                <div class="search-form position-relative">
                                    <button type="submit" class="fas fa-search close-search search-button"></button>
                                    <input type="text" name="search" class="search-input" placeholder="Enter your keywords..." autocomplete="off">
                                </div>
                            </form>
                        </div>
                    </div>

                   
                </div>
            </nav>
            <!-- end navigation --> 
            <!-- end navigation --> 
        </header>


        <!-- Button trigger modal-->

<!-- Modal: modalCart -->
<section style="padding: 0px; z-index: 100000000;">
<div style="margin-top: 100px;" class="modal fade" id="modalCart" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
  aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <!--Header-->








 


      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true"><i style="font-size: 28px; color: #09c976" class="far fa-times-circle"></i></span>
        </button>
      </div>
      <div class="row">

    <div class="col-md-12 price-bg">
        <h1 style="font-weight: 400; font-size: 22px; color: #fff; text-align: center;">ITPWCS Membership Option</h1>
        <div class="row">
    <div class="col-md-3"><div class="price-bg1"><h3>General<br> Membership</h3><h6>Starting from<br><span>1500</span></h6>
<ul>
  <li>Lorens mirk so now</li>
  <li>Lorens mirk so now</li>
  <li>Lorens mirk so now</li>
  <li>Lorens mirk so now</li>
</ul> 
<button type="button" class="btn btn-primary">Sign Up</button>
    </div></div>
     <div class="col-md-3"><div class="price-bg2"><h3>Students<br> Membership</h3><h6>Starting from<br><span>1500</span></h6>
<ul>
  <li>Lorens mirk so now</li>
  <li>Lorens mirk so now</li>
  <li>Lorens mirk so now</li>
  <li>Lorens mirk so now</li>
</ul> 
<button type="button" class="btn btn-primary">Sign Up</button>
     </div></div>
      <div class="col-md-3"><div class="price-bg3"><h3>Proffesional<br> Membership</h3><h6>Starting from<br><span>2000</span></h6>
<ul>
  <li>Lorens mirk so now</li>
  <li>Lorens mirk so now</li>
  <li>Lorens mirk so now</li>
  <li>Lorens mirk so now</li>
</ul> 
<button type="button" class="btn btn-primary">Sign Up</button>
      </div></div>
       <div class="col-md-3"><div class="price-bg4"><h3>Corparate<br> Membership</h3><h6>Starting from<br><span>5000</span></h6>
<ul>
  <li>Lorens mirk so now</li>
  <li>Lorens mirk so now</li>
  <li>Lorens mirk so now</li>
  <li>Lorens mirk so now</li>
</ul> 
<button type="button" class="btn btn-primary">Sign Up</button>

       </div></div>
</div>
    </div>
</div>
    </div>
  </div>
</div>
</section>
<!-- Modal: modalCart -->


