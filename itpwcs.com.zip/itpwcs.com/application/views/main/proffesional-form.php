<!doctype html>
<html class="no-js" lang="en">
    <head>
        <!-- title -->
        <title>ITPWCS</title>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1" />
        <meta name="author" content=" ">
        <!-- description -->
        <meta name="description" content="ITPWCS">
        <!-- keywords -->
        <meta name="keywords" content="ITPWCS">
        <!-- favicon -->
        <link rel="shortcut icon" href="<?php echo base_url() ?>maintemp/images/favicon.png">
<!--         <link rel="apple-touch-icon" href="images/apple-touch-icon-57x57.png">
        <link rel="apple-touch-icon" sizes="72x72" href="images/apple-touch-icon-72x72.png">
        <link rel="apple-touch-icon" sizes="114x114" href="images/apple-touch-icon-114x114.png"> -->
        <!-- animation -->

        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/animate.css" />
        <!-- bootstrap -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/bootstrap.min.css" />
        <!-- et line icon --> 
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/et-line-icons.css" />
        <!-- font-awesome icon -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/font-awesome.min.css" />
        <!-- themify icon -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/themify-icons.css">
        <!-- swiper carousel -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/swiper.min.css">
        <!-- justified gallery  -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/justified-gallery.min.css">
        <!-- magnific popup -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/magnific-popup.css" />

        <!-- revolution slider -->
        <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>maintemp/revolution/css/settings.css" media="screen" />
        <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>maintemp/revolution/css/layers.css">
        <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>maintemp/revolution/css/navigation.css">
        <!-- bootsnav -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/bootsnav.css">
        <!-- style -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/style.css" />
        <!-- responsive css -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/responsive.css" />
        <!--[if IE]>
            <script src="js/html5shiv.js"></script>
        <![endif]-->

<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker.css'>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


<!-- Vendor CSS-->


<!-- Main CSS-->
<link href="newcss/main.css" rel="stylesheet" media="all">

    </head>
    <body>
        

    <?php $page = 'services';?>
    <?php include 'header.php';?>


    <!-- start page title section -->
    <section class="   padding-0px-tb  top-space"></section>
    <!-- end page title section -->


  


<section>
   
<div class="container stdntform">
    <div class="col-md-9 mx-auto" style=" border-radius: 20px; border: 1px solid #09c976; padding-top: 60px; padding-bottom: 60px;">
    <div class="col-md-8 mx-auto membership">
        <h2 style="font-family: 'Montserrat', sans-serif; color: #09c976; font-size: 30px; text-align: center; padding-bottom: 30px; font-weight: 600;">PROFFESIONAL JOIN FORM</h2>
<form action="" method="post" enctype="multipart/form-data" >
    <div class="row">
        <div class="col-md-6 frm-lyt"><div class="form-group mb-2">
                  <label>Full Name <span style="color: #cc0202;">*</span></label>
                  <input type="text" class="form-control" name="name" placeholder="Full Name">
                </div></div>
       <div class="col-md-6 frm-lyt"><div class="form-group mb-2">
                  <label>Email Address <span style="color: #cc0202;">*</span></label>
                  <input type="text" class="form-control" name="email" placeholder="Email Address">
                </div></div>
                <div class="col-md-6 frm-lyt"><div class="form-group mb-2">
                  <label>Organization Name <span style="color: #cc0202;">*</span></label>
                  <input type="text" class="form-control" name="organization_name" placeholder="Organization Name">
                </div></div>
                <div class="col-md-6 frm-lyt"><div class="form-group mb-2">
                  <label>Job Title <span style="color: #cc0202;">*</span></label>
                  <input type="text" class="form-control" name="job_title" placeholder="Job Title">
                </div></div>
                <div class="col-md-6 frm-lyt"><div class="form-group mb-2">
                  <label>DOB <span style="color: #cc0202;">*</span></label>
<div id="datepicker" class="input-group date" data-date-format="mm-dd-yyyy">
    <input class="form-control" name="dob" type="text" readonly />
    <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
</div>
                </div></div>
               <div class="col-md-6 frm-drp"><div class="form-group mb-2">
                <label>Select Country <span style="color: #cc0202;">*</span></label>
                   <select class="browser-default custom-select mb-4" name="country">
            <option value="" selected="">Select Country</option>
            <option value="1" selected="">India</option>
            <option value="2">Brazil</option>
            <option value="3">China</option>
          </select>

               </div>
            </div>
            <div class="col-md-6 frm-drp"><div class="form-group mb-2">
                <label>State <span style="color: #cc0202;">*</span></label>
                   <select class="browser-default custom-select mb-4" name="state">
            <option value="" selected="">Select State</option>
            <option value="1" selected="">Kerala</option>
            <option value="2">Tamilnadu</option>
            <option value="3">Karnataka</option>
          </select>

               </div>
            </div>
            <div class="col-md-6 frm-drp"><div class="form-group mb-2">
                <label>City<span style="color: #cc0202;">*</span></label>
                   <select class="browser-default custom-select mb-4" name="city">
            <option value="" selected="">Select City</option>
            <option value="1" selected="">Kasargod</option>
            <option value="2">Kozhikode</option>
            <option value="3">Malappuram</option>
          </select>

               </div>
            </div>

           
        <div class="col-md-12 frm-txt-area" data-for="message"><div class="form-group mb-2">
             <label>Address<span style="color: #cc0202;">*</span></label>
                                <textarea class="form-control input" name="address" rows="3" data-form-field="Message" placeholder="Address" style="resize:none; background-color: #e8e8e8; border: 1px solid #09c976;" id="message-form4-4v"></textarea>
                            </div>
            </div>
            <div class="col-md-6 frm-lyt"><div class="form-group mb-2">
          <label for="inputZip" class="active">Pin Code<span style="color: #cc0202;">*</span></label>
          <input type="text" class="form-control" name="pin_code" id="inputZip" placeholder="673-633">
        </div></div>




<div class="col-md-6"><div class="form-group mb-2">
             
              <div class="input-group">
                <label style="color: #6f6f6f; font-size: 14px;" class="label">Gender<span style="color: #cc0202;">*</span></label>
                <div class="p-t-10">
                  <label style="color: #6f6f6f; font-weight: normal;" class="radio-container m-r-45">Male
                    <input type="radio" checked="checked" name="gender">
                    <span class="checkmark"></span> </label>
                  <label style="color: #6f6f6f; font-weight: normal;" class="radio-container">Female
                    <input type="radio" name="gender">
                    <span class="checkmark"></span> </label>
                </div>
              </div>
            </div>
          
            </div>
<h4>Preferred mode of Contact<span style="color: #cc0202;">*</span></h4>
</div>
<div class="row social">
    <div class="col-md-4 whtsap"><button type="button" class="btn btn-primary" name="preferred_mode_of_contact"><i class="fab fa-whatsapp"></i>Whatsapp</button></div>
    <div class="col-md-4 mail"><button type="button" class="btn btn-primary" name="preferred_mode_of_contact"><i class="fas fa-paper-plane"></i>E-mail</button></div>
    <div class="col-md-4 mobile"><button type="button" class="btn btn-primary" name="preferred_mode_of_contact"><i class="fas fa-mobile-alt"></i>Phone</button></div>

</div>
<div class="row">
        <div class="col-md-6 frm-lyt"><div class="form-group mt-5 mb-2">
                  <label>Institution Name</label>
                  <input type="text" class="form-control" name="institution_name" placeholder="Institution Name">
                </div></div>
<div class="col-md-6 frm-lyt"><div class="form-group mt-5 mb-2">
                  <label>Place</label>
                  <input type="text" class="form-control" name="place" placeholder="Location Of The Institute">
                </div></div>
               <div class="col-md-6 frm-drp"><div class="form-group mb-2">
                <label>Graduation Date (Expected Completion)</label>
                   <select class="browser-default custom-select mb-4" name="graduation_date">
            <option value="" selected="">Select Date</option>
            <option value="1" selected="">India</option>
            <option value="2">Brazil</option>
            <option value="3">China</option>
          </select>

               </div>
            </div>
            <div class="col-md-6 frm-drp">
            </div>
            

             <div class="col-md-6 frm-drp"><div class="form-group mb-2">
                <label>Graduation Type</label>
                   <select class="browser-default custom-select mb-4" name="graduation_type">
            <option value="" selected="">Graduation Type</option>
            <option value="1" selected="">India</option>
            <option value="2">Brazil</option>
            <option value="3">China</option>
          </select>

               </div>
            </div>
            <div class="col-md-6 frm-drp"><div class="form-group mb-2">
                <label>Stream</label>
                   <select class="browser-default custom-select mb-4" name="stream">
            <option value="" selected="">Stream</option>
            <option value="1" selected="">Kerala</option>
            <option value="2">Tamilnadu</option>
            <option value="3">Karnataka</option>
          </select>

               </div>
            </div>
            <div class="col-md-6 frm-drp"><div class="form-group mb-2">
                <label>Major Type</label>
                   <select class="browser-default custom-select mb-4" name="major_type">
            <option value="" selected="">Major Type</option>
            <option value="1" selected="">India</option>
            <option value="2">Brazil</option>
            <option value="3">China</option>
          </select>

               </div>
            </div>
            <div class="col-md-6 frm-drp"><div class="form-group mb-2">
                <label>Stream</label>
                   <select class="browser-default custom-select mb-4" name="major_stream">
            <option value="" selected="">Stream</option>
            <option value="1" selected="">Kerala</option>
            <option value="2">Tamilnadu</option>
            <option value="3">Karnataka</option>
          </select>

               </div>
            </div>



</div>
<div class="form-group upld-btn mt-2">
<label class="btn btn-primary">
                Add<i class="fas fa-upload"></i> <input type="file" name="pdf1" style="display: none;">
            </label>
</div>

<div class="row">
    <h4>Internalship Experience (if yes)</h4>
        <div class="col-md-6 frm-lyt"><div class="form-group mb-2 mt-3">
                  <label>Company Name</label>
                  <input type="text" class="form-control" name="company_name" placeholder="Company Name ">
                </div></div>
<div class="col-md-6 frm-lyt"><div class="form-group mb-2 mt-3">
                  <label>Place</label>
                  <input type="text" class="form-control" name="place1" placeholder="Place">
                </div></div>
                <div class="col-md-6 frm-lyt"><div class="form-group mb-2 mt-3">
                  <label>Course</label>
                  <input type="text" class="form-control" name="course" placeholder="Course">
                </div>
 <h4 style="padding-left: 0px;">Familiar tool</h4>
            </div>

<div class="col-md-6 frm-lyt"></div>



<div class="col-md-6 frm-drp"><div class="form-group mb-2 mt-3">
    
               
                   <select class="browser-default custom-select mb-4" name="familiar_tool">
            <option value="" selected="">Name</option>
            <option value="1" selected="">India</option>
            <option value="2">Brazil</option>
            <option value="3">China</option>
          </select>

               </div>
            </div>



<div class="col-md-6">
 <div class="row">
        
        <div class="col-md-4">
            <div class="form-group mb-2 mt-3">
                 <div class="input-group">
                <label style="color: #6f6f6f;" class="label"></label>
                <div class="p-t-10">
                  <label class="radio-container" style="color: #6f6f6f; font-weight: normal; margin-right:0px; padding-left: 22px;">Bigginer
                    <input type="radio" checked="checked" name="familiar_tools">
                    <span class="checkmark"></span> </label>
                  
                </div>
              </div>
            </div>
        </div>
        <div class="col-md-4"><div class="form-group mb-2 mt-3">
                 <div class="input-group">
                <label style="color: #6f6f6f;" class="label"></label>
                <div class="p-t-10">
                  <label class="radio-container" style="color: #6f6f6f; font-weight: normal; margin-right:0px; padding-left: 22px;">Moderate
                    <input type="radio" checked="checked" name="familiar_tools">
                    <span class="checkmark"></span> </label>
                  
                </div>
              </div>
            </div></div>
        <div class="col-md-4"><div class="form-group mb-2 mt-3">
                 <div class="input-group">
                <label style="color: #6f6f6f;" class="label"></label>
                <div class="p-t-10">
                  <label class="radio-container" style="color: #6f6f6f; font-weight: normal; margin-right:0px;  padding-left: 22px;">Expert
                    <input type="radio" checked="checked" name="familiar_tools">
                    <span class="checkmark"></span> </label>
                  
                </div>
              </div>
            </div></div>

    </div>
    
          
            </div>
<div class="container-fluid"><div class="form-group upld-btn mt-2">
<label class="btn btn-primary">
                Add<i class="fas fa-upload"></i> <input type="file" name="pdf2" style="display: none;">
            </label>
</div>
<h4 style="padding-left: 0px;">Intrested Career</h4>
</div>
<div class="col-md-6 frm-drp"><div class="form-group mb-2">
               
                   <select class="browser-default custom-select mb-4" name="intrested_career">
            <option value="" selected="">Name</option>
            <option value="1" selected="">Kerala</option>
            <option value="2">Tamilnadu</option>
            <option value="3">Karnataka</option>
          </select>

               </div>
            </div>
            <div class="col-md-6 frm-drp"><div class="form-group mb-2">
                

               </div>
            </div>
<div class="container-fluid"><div class="form-group upld-btn mt-2 mb-5">
<label class="btn btn-primary">
                Add<i class="fas fa-upload"></i> <input type="file" name="pdf3" style="display: none;">
            </label>
</div>

<div class="form-group upld-btn">
    <label>Upload Resume</label><br>
<label class="btn btn-primary">
                Upload<i class="fas fa-upload"></i> <input type="file" name="resume" style="display: none;">
            </label>
</div>

<div class="row"><div class="col-md-12"><div class="form-group mb-2">
             
              <div class="custom-control custom-checkbox">
            <input type="checkbox" class="custom-control-input" name="" id="defaultRegisterFormNewsletter">
            <label style="font-weight: normal;" class="custom-control-label" for="defaultRegisterFormNewsletter">I would like to do join in the ITPWCS student chapter<br> and the agree the following <span style="text-decoration: underline;">Terms and conditions</span></label>
          </div>
          
            </div>

</div> 
<div class="sub-btn mt-5 mb-5" style="margin: auto;">
<button class="btn btn-primary" type="submit" name="submit" value="submit" style="background-color: #09c976; border-radius: 30px; border: 1px #9f9f9f solid; text-transform: none; line-height: 40px; padding: 0px 30px; margin: auto;">Submit</button>
        </div>

</div>
 <p style="text-align: center;">Let us have a look at your resume<br> we will Contact you back soon</p>
</div>
            
</div>
</form>
</section>








 
           
           
    
    <?php include 'footer.php';?>


        <!-- end footer -->
        <!-- start scroll to top -->
        <a class="scroll-top-arrow" href="javascript:void(0);"><i class="ti-arrow-up"></i></a>

        <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
      
        <!-- end scroll to top  -->
        <!-- javascript libraries -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/modernizr.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/bootstrap.bundle.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.easing.1.3.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/skrollr.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/smooth-scroll.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.appear.js"></script>
        <!-- menu navigation -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/bootsnav.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.nav.js"></script>
        <!-- animation -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/wow.min.js"></script>
        <!-- page scroll -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/page-scroll.js"></script>
        <!-- swiper carousel -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/swiper.min.js"></script>
        <!-- counter -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.count-to.js"></script>
        <!-- parallax -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.stellar.js"></script>
        <!-- magnific popup -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.magnific-popup.min.js"></script>
        <!-- portfolio with shorting tab -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/isotope.pkgd.min.js"></script>
        <!-- images loaded -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/imagesloaded.pkgd.min.js"></script>
        <!-- pull menu -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/classie.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/hamburger-menu.js"></script>
        <!-- counter  -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/counter.js"></script>
        <!-- fit video  -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.fitvids.js"></script>
        <!-- skill bars  -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/skill.bars.jquery.js"></script> 
        <!-- justified gallery  -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/justified-gallery.min.js"></script>
        <!--pie chart-->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.easypiechart.min.js"></script>
        <!-- instagram -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/instafeed.min.js"></script>
        <!-- retina -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/retina.min.js"></script>
        <!-- revolution -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/revolution/js/jquery.themepunch.tools.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/revolution/js/jquery.themepunch.revolution.min.js"></script>
        <!-- revolution slider extensions (load below extensions JS files only on local file systems to make the slider work! The following part can be removed on server for on demand loading) -->
        <!--<script type="text/javascript" src="revolution/js/extensions/revolution.extension.actions.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.carousel.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.kenburn.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.layeranimation.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.migration.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.navigation.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.parallax.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.slideanims.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.video.min.js"></script>-->
        <!-- setting -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/main.js"></script>

<script>

$(function() {

  // We can attach the `fileselect` event to all file inputs on the page
  $(document).on('change', ':file', function() {
    var input = $(this),
        numFiles = input.get(0).files ? input.get(0).files.length : 1,
        label = input.val().replace(/\\/g, '/').replace(/.*\//, '');
    input.trigger('fileselect', [numFiles, label]);
  });

  // We can watch for our custom `fileselect` event like this
  $(document).ready( function() {
      $(':file').on('fileselect', function(event, numFiles, label) {

          var input = $(this).parents('.input-group').find(':text'),
              log = numFiles > 1 ? numFiles + ' files selected' : label;

          if( input.length ) {
              input.val(log);
          } else {
              if( log ) alert(log);
          }

      });
  });
  
});

</script>



<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.js"></script>
<script>$(function () {
  $("#datepicker").datepicker({ 
        autoclose: true, 
        todayHighlight: true
  }).datepicker('update', new Date());
});</script>



<script type="text/javascript">
    
function resetActive(event, percent, step) {
        $(".progress-bar").css("width", percent + "%").attr("aria-valuenow", percent);
        $(".progress-completed").text(percent + "%");

        $("div").each(function () {
            if ($(this).hasClass("activestep")) {
                $(this).removeClass("activestep");
            }
        });

        if (event.target.className == "col-md-2") {
            $(event.target).addClass("activestep");
        }
        else {
            $(event.target.parentNode).addClass("activestep");
        }

        hideSteps();
        showCurrentStepInfo(step);
    }

    function hideSteps() {
        $("div").each(function () {
            if ($(this).hasClass("activeStepInfo")) {
                $(this).removeClass("activeStepInfo");
                $(this).addClass("hiddenStepInfo");
            }
        });
    }

    function showCurrentStepInfo(step) {        
        var id = "#" + step;
        $(id).addClass("activeStepInfo");
    }



</script>
    </body>
</html>