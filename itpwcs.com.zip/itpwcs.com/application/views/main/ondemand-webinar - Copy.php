<!doctype html>
<html class="no-js" lang="en">
    <head>
        <!-- title -->
        <title>ITPWCS</title>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1" />
        <meta name="author" content=" ">
        <!-- description -->
        <meta name="description" content="ITPWCS">
        <!-- keywords -->
        <meta name="keywords" content="ITPWCS">
        <!-- favicon -->
        <link rel="shortcut icon" href="<?php echo base_url() ?>maintemp/images/favicon.png">
 
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/animate.css" />
        <!-- bootstrap -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/bootstrap.min.css" />
        <!-- et line icon --> 
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/et-line-icons.css" />
        <!-- font-awesome icon -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/font-awesome.min.css" />
        <!-- themify icon -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/themify-icons.css">
        <!-- swiper carousel -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/swiper.min.css">
        <!-- justified gallery  -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/justified-gallery.min.css">
        <!-- magnific popup -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/magnific-popup.css" />
        <!-- revolution slider -->
        <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>maintemp/revolution/css/settings.css" media="screen" />
        <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>maintemp/revolution/css/layers.css">
        <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>maintemp/revolution/css/navigation.css">
        <!-- bootsnav -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/bootsnav.css">
        <!-- style -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/style.css" />
        <!-- responsive css -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/responsive.css" />
        <!--[if IE]>
            <script src="js/html5shiv.js"></script>
        <![endif]-->
    </head>
    <body>
        

    <?php $page = 'events';?>
    <?php include 'header.php';?>


    <!-- start page title section -->
    <section class="   padding-0px-tb  top-space"></section>
    <!-- end page title section -->
        
        <!-- start feature box section -->
        <section class="wow fadeIn">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-12 col-xl-7 col-lg-6 col-md-8 margin-eight-bottom md-margin-40px-bottom sm-margin-30px-bottom text-center">
                        <div class="alt-font text-medium-gray margin-10px-bottom text-uppercase text-small">Lorem Ipsum is simply dummy </div>
                        <h5 class="alt-font text-extra-dark-gray font-weight-600 mb-0">Lorem Ipsum is simply dummy text of the printing and typesetting industry. </h5>
                    </div>
                </div>
                <div class="row">
                    <!-- start feature box item -->
                    <div class="col-12 col-md-4 text-center text-md-left sm-margin-30px-bottom last-paragraph-no-margin wow fadeInUp">
                        <div class="margin-ten-bottom overflow-hidden image-hover-style-1 md-margin-20px-bottom">
                            <a href="#"><img src="<?php echo base_url() ?>maintemp/images/events.jpg" alt=""/></a>
                        </div>
                        <a href="services-modern.html" class="alt-font margin-5px-bottom d-block text-extra-dark-gray font-weight-600 text-uppercase text-small">Lorem Ipsum</a>
                        <p class="width-95 md-width-100">Lorem Ipsum is simply text the printing and typesetting standard industry. Lorem Ipsum has been the industry's standard dummy text.</p>
                        <div class="separator-line-horrizontal-full bg-medium-light-gray margin-20px-tb md-margin-15px-tb"></div>
                        <a href="services-modern.html" class="text-uppercase alt-font text-extra-dark-gray font-weight-600 text-extra-small">View All <i class="fas fa-long-arrow-alt-right margin-5px-left text-deep-pink text-medium position-relative top-2" aria-hidden="true"></i></a>
                    </div>
                    <!-- end feature box item -->
                    <!-- start feature box item -->
                    <div class="col-12 col-md-4 text-center text-md-left last-paragraph-no-margin sm-margin-30px-bottom wow fadeInUp" data-wow-delay="0.2s">
                        <div class="margin-ten-bottom overflow-hidden image-hover-style-1 md-margin-20px-bottom">
                            <a href="#"><img src="<?php echo base_url() ?>maintemp/images/events.jpg" alt=""/></a>
                        </div>
                        <a href="services-modern.html" class="alt-font margin-5px-bottom d-block text-extra-dark-gray font-weight-600 text-uppercase text-small">Lorem Ipsum</a>
                        <p class="width-95 md-width-100">Lorem Ipsum is simply text the printing and typesetting standard industry. Lorem Ipsum has been the industry's standard dummy text.</p>
                        <div class="separator-line-horrizontal-full bg-medium-light-gray margin-20px-tb md-margin-15px-tb"></div>
                        <a href="services-modern.html" class="text-uppercase alt-font text-extra-dark-gray font-weight-600 text-extra-small">View All <i class="fas fa-long-arrow-alt-right margin-5px-left text-deep-pink text-medium position-relative top-2" aria-hidden="true"></i></a>
                    </div>
                    <!-- end feature box item -->
                    <!-- start feature box item -->
                    <div class="col-12 col-md-4 text-center text-md-left last-paragraph-no-margin wow fadeInUp" data-wow-delay="0.4s">
                        <div class="margin-ten-bottom overflow-hidden image-hover-style-1 md-margin-20px-bottom">
                            <a href="#"><img src="<?php echo base_url() ?>maintemp/images/events.jpg" alt=""/></a>
                        </div>
                        <a href="services-modern.html" class="alt-font margin-5px-bottom d-block text-extra-dark-gray font-weight-600 text-uppercase text-small">Lorem Ipsum</a>
                        <p class="width-95 md-width-100">Lorem Ipsum is simply text the printing and typesetting standard industry. Lorem Ipsum has been the industry's standard dummy text.</p>
                        <div class="separator-line-horrizontal-full bg-medium-light-gray margin-20px-tb md-margin-15px-tb"></div>
                        <a href="services-modern.html" class="text-uppercase alt-font text-extra-dark-gray font-weight-600 text-extra-small">View All <i class="fas fa-long-arrow-alt-right margin-5px-left text-deep-pink text-medium position-relative top-2" aria-hidden="true"></i></a>
                    </div>                    
                    <!-- end feature box item -->
                </div>
            </div>
        </section>
        <!-- end  feature box section -->
        <!-- start feature box section -->
        <section class="no-padding wow fadeIn bg-extra-dark-gray">
            <div class="container-fluid">
                <div class="row">
                  
                    <div class="col-12 col-lg-12 padding-six-tb padding-seven-half-lr lg-padding-four-half-tb lg-padding-seven-half-lr md-padding-nine-half-tb md-padding-30px-lr sm-padding-50px-tb wow fadeInRight">
                        <div class="row">
                            <!-- start feature box item -->
                            <div class="col-12 col-xl-6 col-lg-12 col-md-12 margin-six-bottom lg-margin-30px-bottom last-paragraph-no-margin">
                                <div class="feature-box-5 position-relative">
                                    <i class="icon-target text-medium-gray icon-medium"></i>
                                    <div class="feature-content">
                                        <div class="text-white-2 margin-5px-bottom alt-font">Lorem Ipsum</div>
                                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem standard dummy text.</p>
                                    </div>
                                </div>
                            </div>
                            <!-- end feature box item -->
                            <!-- start feature box item -->
                            <div class="col-12 col-xl-6 col-lg-12 col-md-6 margin-six-bottom lg-margin-30px-bottom last-paragraph-no-margin">
                                <div class="feature-box-5 position-relative">
                                    <i class="icon-desktop text-medium-gray icon-medium"></i>
                                    <div class="feature-content">
                                        <div class="text-white-2 margin-5px-bottom alt-font">Lorem Ipsum</div>
                                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem standard dummy text.</p>
                                    </div>
                                </div>
                            </div>
                            <!-- end feature box item -->
                            <!-- start feature box item -->
                            <div class="col-12 col-xl-6 col-lg-12 col-md-6 margin-six-bottom lg-margin-30px-bottom last-paragraph-no-margin">
                                <div class="feature-box-5 position-relative">
                                    <i class="icon-puzzle text-medium-gray icon-medium"></i>
                                    <div class="feature-content">
                                        <div class="text-white-2 margin-5px-bottom alt-font">Web Development</div>
                                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem standard dummy text.</p>
                                    </div>
                                </div>
                            </div>
                            <!-- end feature box item -->
                            <!-- start feature box item -->
                            <div class="col-12 col-xl-6 col-lg-12 col-md-6 margin-six-bottom lg-margin-30px-bottom last-paragraph-no-margin">
                                <div class="feature-box-5 position-relative">
                                    <i class="icon-tools text-medium-gray icon-medium"></i>
                                    <div class="feature-content">
                                        <div class="text-white-2 margin-5px-bottom alt-font">Lorem Ipsum</div>
                                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem standard dummy text.</p>
                                    </div>
                                </div>
                            </div>
                            <!-- end feature box item -->
                            <!-- start feature box item -->
                            <div class="col-12 col-xl-6 col-lg-12 col-md-6 lg-margin-30px-bottom last-paragraph-no-margin">
                                <div class="feature-box-5 position-relative">
                                    <i class="icon-briefcase text-medium-gray icon-medium"></i>
                                    <div class="feature-content">
                                        <div class="text-white-2 margin-5px-bottom alt-font">Lorem Ipsum</div>
                                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem standard dummy text.</p>
                                    </div>
                                </div>
                            </div>
                            <!-- end feature box item -->
                            <!-- start feature box item -->
                            <div class="col-12 col-xl-6 col-lg-12 col-md-6 last-paragraph-no-margin">
                                <div class="feature-box-5 position-relative ">
                                    <i class="icon-basket text-medium-gray icon-medium"></i>
                                    <div class="feature-content">
                                        <div class="text-white-2 margin-5px-bottom alt-font">Lorem Ipsum</div>
                                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem standard dummy text.</p>
                                    </div>
                                </div>
                            </div>
                            <!-- end feature box item -->
                        </div>
                    </div> 
                </div>
            </div>
        </section>
        <!-- end feature box section -->
       
        <!-- start information section -->
        <section class="bg-light-gray">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-12 col-lg-5 md-margin-30px-bottom wow fadeInLeft">
                        <img src="http://placehold.it/558x675" class="w-100" alt=""/>
                    </div>
                    <div class="col-12 col-lg-6 offset-lg-1 wow fadeInRight">
                        <span class="text-medium text-deep-pink alt-font margin-10px-bottom d-inline-block">Easy way to build perfect websites</span>
                        <h5 class="alt-font text-extra-dark-gray font-weight-600">Beautifully handcrafted templates for your website</h5>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since. Lorem Ipsum has been the industry's standard dummy text ever since. Lorem Ipsum is simply dummy text.</p>
                        <div class="margin-30px-tb">
                            <ul class="p-0 list-style-5">
                                <li>Beautiful and easy to understand UI, professional animations</li>
                                <li>Theme advantages are pixel perfect design &amp; clear code delivered</li>
                                <li>Present your services with flexible, convenient and multipurpose</li>
                                <li>Find more creative ideas for your projects </li>
                                <li>Unlimited power and customization possibilities</li> 
                            </ul>                                
                        </div>
                        <a href="services-modern.html" class="btn btn-dark-gray btn-small text-extra-small">View more info</a>
                    </div>
                </div>
            </div>
        </section>
        <!-- end information box section  -->
       

  
    <?php include 'footer.php';?>

 
        <!-- start scroll to top -->
        <a class="scroll-top-arrow" href="javascript:void(0);"><i class="ti-arrow-up"></i></a>
        <!-- end scroll to top  -->
        <!-- javascript libraries -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/modernizr.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/bootstrap.bundle.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.easing.1.3.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/skrollr.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/smooth-scroll.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.appear.js"></script>
        <!-- menu navigation -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/bootsnav.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.nav.js"></script>
        <!-- animation -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/wow.min.js"></script>
        <!-- page scroll -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/page-scroll.js"></script>
        <!-- swiper carousel -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/swiper.min.js"></script>
        <!-- counter -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.count-to.js"></script>
        <!-- parallax -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.stellar.js"></script>
        <!-- magnific popup -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.magnific-popup.min.js"></script>
        <!-- portfolio with shorting tab -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/isotope.pkgd.min.js"></script>
        <!-- images loaded -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/imagesloaded.pkgd.min.js"></script>
        <!-- pull menu -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/classie.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/hamburger-menu.js"></script>
        <!-- counter  -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/counter.js"></script>
        <!-- fit video  -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.fitvids.js"></script>
        <!-- skill bars  -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/skill.bars.jquery.js"></script> 
        <!-- justified gallery  -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/justified-gallery.min.js"></script>
        <!--pie chart-->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.easypiechart.min.js"></script>
        <!-- instagram -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/instafeed.min.js"></script>
        <!-- retina -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/retina.min.js"></script>
        <!-- revolution -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/revolution/js/jquery.themepunch.tools.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/revolution/js/jquery.themepunch.revolution.min.js"></script>
        <!-- revolution slider extensions (load below extensions JS files only on local file systems to make the slider work! The following part can be removed on server for on demand loading) -->
        <!--<script type="text/javascript" src="revolution/js/extensions/revolution.extension.actions.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.carousel.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.kenburn.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.layeranimation.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.migration.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.navigation.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.parallax.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.slideanims.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.video.min.js"></script>-->
        <!-- setting -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/main.js"></script>
    </body>
</html>