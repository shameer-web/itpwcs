<?php
class database
{
    public function __construct()
    {

        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "itpwcs";

        // Create connection
        $this->sql = new mysqli($servername, $username, $password, $dbname);
        // Check connection
        mysqli_set_charset($this->sql,"utf8");
        if ($this->sql->connect_error) {
            die("Connection failed: " . $this->sql->connect_error);
        }


    }
    
   
    public function insert_data($name,$email,$organization_name,$job_title,$dob,$country,$state,$city,$address,$pincode,$gender,$preferred_mode_of_contact,$institution_name,$place,$graduation_date,$graduation_type,$stream,$major_type,$major_stream,$resume)
    {
        $sql ="insert into `students`(name,email,organization_name,job_title,dob,country,state,city,address,pincode,gender,preferred_mode_of_contact,institution_name,place,graduation_date,graduation_type,stream,major_type,major_stream,resume) values ('$name','$email','$organization_name','$job_title','$dob','$country','$state','$city','$address','$pincode','$gender','$preferred_mode_of_contact','$institution_name','$place','$graduation_date','$graduation_type','$stream','$major_type','$major_stream','$resume')";


        $query = $this->sql->query($sql);
        return $query;


    }



}
?>