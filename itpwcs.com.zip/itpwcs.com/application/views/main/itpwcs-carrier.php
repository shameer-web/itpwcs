﻿<!doctype html>
<html class="no-js" lang="en">
    <head>
        <!-- title -->
        <title>ITPWCS</title>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1" />
        <meta name="author" content=" ">
        <!-- description -->
        <meta name="description" content="ITPWCS">
        <!-- keywords -->
        <meta name="keywords" content="ITPWCS">
        <!-- favicon -->
        <link rel="shortcut icon" href="<?php echo base_url() ?>maintemp/images/favicon.png">
<!--         <link rel="apple-touch-icon" href="images/apple-touch-icon-57x57.png">
        <link rel="apple-touch-icon" sizes="72x72" href="images/apple-touch-icon-72x72.png">
        <link rel="apple-touch-icon" sizes="114x114" href="images/apple-touch-icon-114x114.png"> -->
        <!-- animation -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/animate.css" />
        <!-- bootstrap -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/bootstrap.min.css" />
        <!-- et line icon --> 
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/et-line-icons.css" />
        <!-- font-awesome icon -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/font-awesome.min.css" />
        <!-- themify icon -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/themify-icons.css">
        <!-- swiper carousel -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/swiper.min.css">
        <!-- justified gallery  -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/justified-gallery.min.css">
        <!-- magnific popup -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/magnific-popup.css" />
        <!-- revolution slider -->
        <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>maintemp/revolution/css/settings.css" media="screen" />
        <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>maintemp/revolution/css/layers.css">
        <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>maintemp/revolution/css/navigation.css">
        <!-- bootsnav -->
        <link rel="stylesheet" href="css/bootsnav.css">
        <!-- style -->
        <link rel="stylesheet" href="css/style.css" />
        <!-- responsive css -->
        <link rel="stylesheet" href="css/responsive.css" />
        <!--[if IE]>
            <script src="js/html5shiv.js"></script>
        <![endif]-->
    </head>
    <body>
        

    <?php $page = 'members';?>
    <?php include 'header.php';?>
 
    <!-- start page title section -->
    <section class="   padding-0px-tb  top-space"></section>
    <!-- end page title section -->


 <!-- start feature box section -->
        <section class=" padding-140px-tb  new-bg  wow fadeIn"  >
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-12 col-xl-5 col-md-6 margin-eight-bottom md-margin-40px-bottom sm-margin-30px-bottom text-center">
                         
                        <h5 class="alt-font text-white-2 font-weight-600 mb-0">Free e-Learning for ITPWCS IT Fundamentals</h5><br>

                        <a class="btn btn-small btn-white btn-rounded lg-margin-5px-bottom d-table d-lg-inline-block md-margin-lr-auto" href="#">SIGN UP</a>

                    </div>
                </div>
                <div class="row">
                    <!-- start features box -->
                    <div class="col-12 col-lg-4 col-md-6 md-margin-30px-bottom wow fadeInUp">
                         <a class="btn btn-medium btn-transparent-white lg-margin-15px-bottom d-table d-lg-inline-block md-margin-lr-auto" href="#">Support for Educators</a>
                    </div>
                    <!-- end feature box -->
                    
                    <!-- start features box -->
                    <div class="col-12 col-lg-4 col-md-6 wow fadeInUp sm-margin-30px-bottom" data-wow-delay="0.4s">
                         <a class="btn btn-medium btn-transparent-white lg-margin-15px-bottom d-table d-lg-inline-block md-margin-lr-auto" href="#">Support for Displaced Workers</a>
                    </div>
                    <!-- end feature box -->
                    <!-- start features box -->
                    <div class="col-12 col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.6s">
                         <a class="btn btn-medium btn-transparent-white lg-margin-15px-bottom d-table d-lg-inline-block md-margin-lr-auto" href="#">Support for Technology Business</a>
                    </div>
                    <!-- end feature box -->
                </div>
            </div>
        </section>
        <!-- start feature box section -->

        
        <!-- end page title section -->
        <!-- start information section -->
        <section class="wow fadeIn">
            <div class="container">
                <div class="row">
                    <div class="col-12 col-md-6 wow fadeIn">
                        <div class="position-relative icon-with-paragraph">
                            <span class="text-deep-pink position-absolute left-0 top-0 alt-font special-char-extra-large d-none d-lg-block">*</span> 
                            <h5 class="font-weight-300 text-extra-dark-gray width-90 padding-nineteen-left lg-padding-twenty-left lg-width-100 md-no-padding-left sm-margin-five-bottom">A Lorem Ipsum is simply dummy text of the printing and typesetting industry.</h5>
                        </div>
                    </div>
                    <div class="col-12 col-xl-6 col-lg-5 offset-lg-1 offset-xl-0 col-md-6 wow fadeIn last-paragraph-no-margin" data-wow-delay="0.2s">
                        <p class="text-medium font-weight-300 width-70 line-height-26 lg-width-100">We are idea-driven, working with a strong focus on design and user experience. Our projects should engage your audience, we want to create wonderful digital things that people love to be part of and use. That's what your brand and audience deserve.</p>
                        <a href="#expertise" class="inner-link text-uppercase alt-font margin-15px-top d-inline-block font-weight-600 text-deep-pink text-extra-small">Check My Expertise <i class="fas fa-long-arrow-alt-right margin-5px-left text-medium position-relative top-2" aria-hidden="true"></i></a>
                    </div>
                </div>
            </div>
        </section>
        <!-- end information section -->
        <!-- start feature box section -->
        <section class="wow fadeIn p-0">
            <div class="container-fluid">
                <div class="row">
                    <!-- start feature box item -->
                    <div class="col-12 col-lg-4 banner-style2 md-margin-30px-bottom wow fadeInUp">
                        <figure> 
                            <div class="banner-image bg-black height-400px cover-background" style="background-image:url('<?php echo base_url() ?>maintemp/images/bg-comp.jpg');"></div>
                            <figcaption class="padding-seven-all bg-white d-flex align-items-center last-paragraph-no-margin">
                                <div class="text-center text-md-left">
                                    <span class="text-medium-gray alt-font text-uppercase">1999 to 2001</span>
                                    <span class="text-large font-weight-600 text-extra-dark-gray alt-font text-uppercase padding-15px-bottom d-block">Rubber Studio</span>
                                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                                    <a href="#
<html class="no-js" lang="en">pofo-creative-agency-corporate-and-portfolio-multipurpose-template/20645944?ref=themezaa" target="_blank" class="btn btn-dark-gray btn-small margin-30px-top sm-margin-15px-top">Visit Website</a>
                                </div>
                            </figcaption>
                        </figure>
                    </div>  
                    <!-- end feature box -->
                    <!-- start feature box item -->
                    <div class="col-12 col-lg-4 banner-style2 md-margin-30px-bottom wow fadeInUp" data-wow-delay="0.2s">
                        <figure> 
                            <div class="banner-image bg-black height-400px cover-background" style="background-image:url('<?php echo base_url() ?>maintemp/images/ser3.jpg');"></div>
                            <figcaption class="padding-seven-all bg-white d-flex align-items-center last-paragraph-no-margin">
                                <div class="text-center text-md-left">
                                    <span class="text-medium-gray alt-font text-uppercase">2001 to 2005</span>
                                    <span class="text-large font-weight-600 text-extra-dark-gray alt-font text-uppercase padding-15px-bottom d-block">Motion Picture</span>
                                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                                    <a href="#
<html class="no-js" lang="en">pofo-creative-agency-corporate-and-portfolio-multipurpose-template/20645944?ref=themezaa" target="_blank" class="btn btn-dark-gray btn-small margin-30px-top sm-margin-15px-top">Visit Website</a>
                                </div>
                            </figcaption>
                        </figure>
                    </div>  
                    <!-- end feature box -->
                    <!-- start feature box item -->
                    <div class="col-12 col-lg-4 banner-style2 wow fadeInUp" data-wow-delay="0.4s">
                        <figure>
                            <div class="banner-image bg-black height-400px cover-background" style="background-image:url('<?php echo base_url() ?>maintemp/images/ser2.jpg');"></div>
                            <figcaption class="padding-seven-all bg-white d-flex align-items-center last-paragraph-no-margin">
                                <div class="text-center text-md-left">
                                    <span class="text-medium-gray alt-font text-uppercase">2005 to 2012</span>
                                    <span class="text-large font-weight-600 text-extra-dark-gray alt-font text-uppercase padding-15px-bottom d-block">Black Design</span>
                                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry</p>
                                    <a href="#
<html class="no-js" lang="en">pofo-creative-agency-corporate-and-portfolio-multipurpose-template/20645944?ref=themezaa" target="_blank" class="btn btn-dark-gray btn-small margin-30px-top sm-margin-15px-top">Visit Website</a>
                                </div>
                            </figcaption>
                        </figure>
                    </div>  
                    <!-- end feature box -->
                </div>
            </div>
        </section>
        <!-- end feature box section -->
        <!-- start features box section -->
        <section class="wow fadeIn">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-12 col-lg-8 col-md-10 text-center">
                        <i class="fas fa-quote-left icon-small text-deep-pink d-block margin-25px-bottom"></i>
                        <h5 class="alt-font text-extra-dark-gray font-weight-600 margin-5px-bottom">Unity is strength...</h5>
                        <h5 class="alt-font text-extra-dark-gray font-weight-300">When there is teamwork and collaboration, wonderful things can be achieved.</h5>
                        <span class="text-uppercase text-extra-small alt-font letter-spacing-3 text-medium-gray">Mattie Stepanek</span>
                    </div>
                </div>
            </div>
        </section>
        <!-- end features box section -->
        <!-- start information section -->
        <section class="p-0 wow fadeIn bg-light-gray">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12 col-lg-6 cover-background md-height-450px wow fadeInLeft"  style="background-image:url('<?php echo base_url() ?>maintemp/images/bg-ser.jpg');"></div>
                    <div class="col-12 col-lg-6 wow fadeInRight padding-five-tb padding-five-lr md-padding-nine-half-tb lg-no-padding-lr md-padding-15px-lr sm-padding-50px-tb">
                        <div class="row m-0">
                            <!-- start feature box item -->
                            <div class="col-12 col-md-6 margin-six-bottom sm-margin-30px-bottom sm-no-padding-lr last-paragraph-no-margin wow fadeIn">
                                <div class="row m-0">
                                    <div class="col-12 col-lg-3 text-center sm-no-padding-lr">
                                        <h3 class="text-light-gray font-weight-300 mb-0 letter-spacing-minus-2">01</h3>
                                    </div>
                                    <div class="col-12 col-lg-9 margin-5px-top text-center text-lg-left sm-no-padding-lr">
                                        <span class="alt-font text-extra-dark-gray font-weight-600 margin-one-bottom d-block">Lorem Ipsum</span>
                                        <span class="alt-font text-extra-small text-uppercase margin-10px-bottom d-block">Bachelor of arts 1990</span>
                                        <p class="width-90 lg-width-100">Lorem Ipsum is simply text the printing and typesetting standard industry.</p>
                                    </div>
                                </div>
                            </div>
                            <!-- end feature box item -->
                            <!-- start feature box item -->
                            <div class="col-12 col-md-6 margin-six-bottom sm-margin-30px-bottom wow fadeIn last-paragraph-no-margin sm-no-padding-lr">
                                <div class="row m-0">
                                    <div class="col-12 col-lg-3 text-center sm-no-padding-lr">
                                        <h3 class="text-light-gray font-weight-300 mb-0 letter-spacing-minus-2">02</h3>
                                    </div>
                                    <div class="col-12 col-lg-9 margin-5px-top text-center text-lg-left sm-no-padding-lr">
                                        <span class="alt-font text-extra-dark-gray font-weight-600 margin-one-bottom d-block">Lorem Ipsum</span>
                                        <span class="alt-font text-extra-small text-uppercase margin-10px-bottom d-block">Degree of Web Design 2003</span>
                                        <p class="width-90 lg-width-100">Lorem Ipsum is simply text the printing and typesetting standard industry.</p>
                                    </div>
                                </div>
                            </div>
                            <!-- end feature box item -->
                            <!-- start feature box item -->
                            <div class="col-12 col-md-6 sm-margin-30px-bottom wow fadeIn last-paragraph-no-margin sm-no-padding-lr">
                                <div class="row m-0">
                                    <div class="col-12 col-lg-3 text-center sm-no-padding-lr">
                                        <h3 class="text-light-gray font-weight-300 mb-0 letter-spacing-minus-2">03</h3>
                                    </div>
                                    <div class="col-12 col-lg-9 margin-5px-top text-center text-lg-left sm-no-padding-lr">
                                        <span class="alt-font text-extra-dark-gray font-weight-600 margin-one-bottom d-block">Lorem Ipsum</span>
                                        <span class="alt-font text-extra-small text-uppercase margin-10px-bottom d-block">Master of branding 2006</span>
                                        <p class="width-90 lg-width-100">Lorem Ipsum is simply text the printing and typesetting standard industry.</p>
                                    </div>
                                </div>
                            </div>
                            <!-- end feature box item -->
                            <!-- start feature box item -->
                            <div class="col-12 col-md-6 wow fadeIn last-paragraph-no-margin sm-no-padding-lr">
                                <div class="row m-0">
                                    <div class="col-12 col-lg-3 text-center sm-no-padding-lr">
                                        <h3 class="text-light-gray font-weight-300 mb-0 letter-spacing-minus-2">04</h3>
                                    </div>
                                    <div class="col-12 col-lg-9 margin-5px-top text-center text-lg-left sm-no-padding-lr">
                                        <span class="alt-font text-extra-dark-gray font-weight-600 margin-one-bottom d-block">Lorem Ipsum</span>
                                        <span class="alt-font text-extra-small text-uppercase margin-10px-bottom d-block">Master of Graphics 2007</span>
                                        <p class="width-90 lg-width-100">Lorem Ipsum is simply text the printing and typesetting standard industry.</p>
                                    </div>
                                </div>
                            </div>
                            <!-- end feature box item -->
                        </div>
                    </div> 
                </div>
            </div>
        </section>    
        <!-- end information section -->
               <!-- start skills section -->
        <section id="expertise" class="wow fadeIn parallax" data-stellar-background-ratio="0.4" style="background-image:url('<?php echo base_url() ?>maintemp/images/bg-comp.jpg');">
            <div class="opacity-full bg-black"></div>
            <div class="container">
                <div class="row">
                    <!-- start pie charts item -->
                    <div class="col-12 col-lg-3 col-md-6 chart-style3 wow fadeInUp text-center md-margin-30px-bottom">
                        <div class="chart-percent"><span class="chart3" data-percent="90"><span class="percent font-weight-500 text-medium"></span></span></div>
                        <div class="chart-text">
                            <span class="alt-font text-white font-weight-600 margin-5px-bottom margin-30px-top md-margin-15px-top d-block">Lorem Ipsum</span>
                            <p class="width-90 mx-auto text-medium-gray sm-width-100">Lorem Ipsum is simply text of the printing typesetting industry.</p>
                        </div>
                    </div>
                    <!-- end pie charts item -->
                    <!-- start pie charts item -->
                    <div class="col-12 col-lg-3 col-md-6 chart-style3 wow fadeInUp text-center md-margin-30px-bottom" data-wow-delay="0.2s">
                        <div class="chart-percent"><span class="chart3" data-percent="96"><span class="percent font-weight-500 text-medium"></span></span></div>
                        <div class="chart-text">
                            <span class="alt-font text-white font-weight-600 margin-5px-bottom margin-30px-top md-margin-15px-top d-block">Lorem Ipsum</span>
                            <p class="width-90 mx-auto text-medium-gray sm-width-100">Lorem Ipsum is simply text of the printing typesetting industry.</p>
                        </div>
                    </div>
                    <!-- end pie charts item -->
                    <!-- start pie charts item -->
                    <div class="col-12 col-lg-3 col-md-6 chart-style3 wow fadeInUp text-center sm-margin-30px-bottom" data-wow-delay="0.4s">
                        <div class="chart-percent"><span class="chart3" data-percent="95"><span class="percent font-weight-500 text-medium"></span></span></div>
                        <div class="chart-text">
                            <span class="alt-font text-white font-weight-600 margin-5px-bottom margin-30px-top md-margin-15px-top d-block">Lorem Ipsum</span>
                            <p class="width-90 mx-auto text-medium-gray sm-width-100">Lorem Ipsum is simply text of the printing typesetting industry.</p>
                        </div>
                    </div>
                    <!-- end pie charts item -->
                    <!-- start pie charts item -->
                    <div class="col-12 col-lg-3 col-md-6 chart-style3 wow fadeInUp text-center" data-wow-delay="0.6s">
                        <div class="chart-percent"><span class="chart3" data-percent="90"><span class="percent font-weight-500 text-medium"></span></span></div>
                        <div class="chart-text">
                            <span class="alt-font text-white font-weight-600 margin-5px-bottom margin-30px-top md-margin-15px-top d-block">Lorem Ipsum</span>
                            <p class="width-90 mx-auto text-medium-gray sm-width-100 sm-no-margin">Lorem Ipsum is simply text of the printing typesetting industry.</p>
                        </div>
                    </div>
                    <!-- end pie charts item -->
                </div>
            </div>
        </section> 
        <!-- end skills section -->




        <!-- start feature box section -->
        <section class="p-0 wow fadeIn">
            <div class="container-fluid">
                <div class="row feature-box-14">
                    <!-- start feature box item -->
                    <div class="col-12 col-lg-3 col-md-6 d-flex align-items-center text-center last-paragraph-no-margin p-0 wow fadeInRight">
                        <div class="padding-fifteen-all md-padding-50px-all sm-padding-30px-all">
                            <h2 class="text-light-gray alt-font letter-spacing-minus-3 mb-0">01</h2>
                            <span class="d-block alt-font text-large text-extra-dark-gray margin-15px-top margin-10px-bottom sm-margin-5px-bottom">I am creative</span>
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard text.</p>
                        </div>
                    </div>
                    <!-- end feature box -->
                    <!-- start feature box item -->
                    <div class="col-12 col-lg-3 col-md-6 d-flex align-items-center text-center last-paragraph-no-margin p-0 wow fadeInRight" data-wow-delay="0.2s">
                        <div class="padding-fifteen-all md-padding-50px-all sm-padding-30px-all">
                            <h2 class="text-light-gray alt-font letter-spacing-minus-3 mb-0">02</h2>
                            <span class="d-block alt-font text-large text-extra-dark-gray margin-15px-top margin-10px-bottom sm-margin-5px-bottom">I am naughty</span>
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard text.</p>
                        </div>
                    </div>
                    <!-- end feature box -->
                    <!-- start feature box item -->
                    <div class="col-12 col-lg-3 col-md-6 d-flex align-items-center text-center last-paragraph-no-margin p-0 wow fadeInRight" data-wow-delay="0.4s">
                        <div class="padding-fifteen-all md-padding-50px-all sm-padding-30px-all">
                            <h2 class="text-light-gray alt-font letter-spacing-minus-3 mb-0">03</h2>
                            <span class="d-block alt-font text-large text-extra-dark-gray margin-15px-top margin-10px-bottom sm-margin-5px-bottom">I am business men</span>
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard text.</p>
                        </div>
                    </div>
                    <!-- end feature box -->
                    <!-- start feature box item -->
                    <div class="col-12 col-lg-3 col-md-6 d-flex align-items-center text-center last-paragraph-no-margin p-0 wow fadeInRight" data-wow-delay="0.6s">
                        <div class="padding-fifteen-all md-padding-50px-all sm-padding-30px-all">
                            <h2 class="text-light-gray alt-font letter-spacing-minus-3 mb-0">04</h2>
                            <span class="d-block alt-font text-large text-extra-dark-gray margin-15px-top margin-10px-bottom sm-margin-5px-bottom">I am hungry</span>
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard text.</p>
                        </div>
                    </div>
                    <!-- end feature box -->
                </div>
            </div>
        </section>
        <!-- end feature box section -->
     
       
    <?php include 'footer.php';?>

        <!-- javascript libraries -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/modernizr.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/bootstrap.bundle.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.easing.1.3.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/skrollr.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/smooth-scroll.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.appear.js"></script>
        <!-- menu navigation -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/bootsnav.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.nav.js"></script>
        <!-- animation -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/wow.min.js"></script>
        <!-- page scroll -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/page-scroll.js"></script>
        <!-- swiper carousel -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/swiper.min.js"></script>
        <!-- counter -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.count-to.js"></script>
        <!-- parallax -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.stellar.js"></script>
        <!-- magnific popup -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.magnific-popup.min.js"></script>
        <!-- portfolio with shorting tab -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/isotope.pkgd.min.js"></script>
        <!-- images loaded -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/imagesloaded.pkgd.min.js"></script>
        <!-- pull menu -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/classie.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/hamburger-menu.js"></script>
        <!-- counter  -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/counter.js"></script>
        <!-- fit video  -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.fitvids.js"></script>
        <!-- skill bars  -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/skill.bars.jquery.js"></script> 
        <!-- justified gallery  -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/justified-gallery.min.js"></script>
        <!--pie chart-->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.easypiechart.min.js"></script>
        <!-- instagram -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/instafeed.min.js"></script>
        <!-- retina -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/retina.min.js"></script>
        <!-- revolution -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/revolution/js/jquery.themepunch.tools.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/revolution/js/jquery.themepunch.revolution.min.js"></script>
        <!-- revolution slider extensions (load below extensions JS files only on local file systems to make the slider work! The following part can be removed on server for on demand loading) -->
        <!--<script type="text/javascript" src="revolution/js/extensions/revolution.extension.actions.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.carousel.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.kenburn.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.layeranimation.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.migration.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.navigation.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.parallax.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.slideanims.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.video.min.js"></script>-->
        <!-- setting -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/main.js"></script>
    </body>
</html>