<!DOCTYPE html>
<html class="no-js" lang="en">
    <head>
        <!-- title -->
        <title>ITPWCS</title>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1" />
        <meta name="author" content=" " />
        <!-- description -->
        <meta name="description" content="ITPWCS" />
        <!-- keywords -->
        <meta name="keywords" content="ITPWCS" />
        <!-- favicon -->
        <link rel="shortcut icon" href="<?php echo base_url() ?>maintemp/images/favicon.png" />
        <!--         <link rel="apple-touch-icon" href="images/apple-touch-icon-57x57.png">
        <link rel="apple-touch-icon" sizes="72x72" href="images/apple-touch-icon-72x72.png">
        <link rel="apple-touch-icon" sizes="114x114" href="images/apple-touch-icon-114x114.png"> -->
        <!-- animation -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/animate.css" />
        <!-- bootstrap -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/bootstrap.min.css" />
        <!-- et line icon -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/et-line-icons.css" />
        <!-- font-awesome icon -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/font-awesome.min.css" />
        <!-- themify icon -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/themify-icons.css" />
        <!-- swiper carousel -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/swiper.min.css" />
        <!-- justified gallery  -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/justified-gallery.min.css" />
        <!-- magnific popup -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/magnific-popup.css" />
        <!-- revolution slider -->
        <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>maintemp/revolution/css/settings.css" media="screen" />
        <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>maintemp/revolution/css/layers.css" />
        <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>maintemp/revolution/css/navigation.css" />
        <!-- bootsnav -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/bootsnav.css" />
        <!-- style -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/style.css" />
        <!-- responsive css -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/responsive.css" />
        <!--[if IE]>
            <script src="js/html5shiv.js"></script>

        <![endif]-->

    </head>
    <body>
        <?php $page = 'home';?>
        <?php include 'header.php';?>

        <!-- start slider section -->
        <section class="p-0 main-slider h-100 mobile-height wow fadeIn">
            <div class="swiper-full-screen swiper-container h-100 w-100 white-move">
                <div class="swiper-wrapper">
                    <!-- start slider item -->
                    <div class="swiper-slide cover-background" style="background-image: url('<?php echo base_url() ?>maintemp/images/slider-1.jpg');">
                         <!-- bg black 
                        <div class="opacity-extra-medium bg-black"></div>
                        -->
                        <div class="container position-relative full-screen">
                            <div class="slider-typography text-center">
                                <div class="slider-text-middle-main">
                                    <div class="slider-text-middle">
                                        <div
                                            class="banner wow fadeInLeft" data-wow-delay="0.4s" style="visibility: visible; animation-delay: 0.4s; animation-name: fadeInLeft;">
                                            <h4>Take your 6 dimentional scientific<br> <span>employee assessment tool</span></h4>
                                            <h6>Get your 30 pages employee assement report<br> to choose the right career option</h6>
                                        </div>
                                       
                                        <div class="btn-dual banner-btn">
                                            <a href="whatisbmit.php" class="btn btn-transparent-white btn-small sm-margin-two-all">Get Started</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- end slider item -->

                    <!-- start slider item -->
                    <div class="swiper-slide cover-background" style="background-image: url('images/slider-2.jpg');">
                         <!-- bg black 
                        <div class="opacity-extra-medium bg-black"></div>
                        -->
                        <div class="container position-relative full-screen wow fadeInUp">
                            <div class="slider-typography text-center">
                                <div class="slider-text-middle-main">
                                    <div class="slider-text-middle">
                                        <div
                                            class="banner-2 wow">
                                            <h4>Choose Your Right<br> Tech Companion</h4>
                                            <h6> 300+ Jobs matching assessments , Professional Mentorship , Digital badges</h6>
                                            
                                        </div>
                                        
                                        <div class="btn-dual banner-btn-2">
                                            <a href="whatisbmit.php" class="btn btn-transparent-white btn-small sm-margin-two-all">Get Started</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- start slider item -->
                    <div class="swiper-slide cover-background" style="background-image: url('<?php echo base_url() ?>maintemp/images/slider-3.jpg');">
                         <!-- bg black 
                        <div class="opacity-extra-medium bg-black"></div>
                        -->
                        <div class="container position-relative full-screen">
                            <div class="slider-typography text-center">
                                <div class="slider-text-middle-main">
                                    <div class="slider-text-middle">
                                        <div
                                            class="banner-3">
                                            <h4>WE MAKE RIGHT EMPLOYEE<br>FOR YOU</h4>
                                            <h6>ASSESSING 300+ IT JOB PROFILES</h6>
                                        </div>
                                        
                                        <div class="btn-dual banner-btn-3">
                                            <a href="smart-hiring.php" class="btn btn-transparent-white btn-small sm-margin-two-all">Get Started</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- start slider pagination -->
                <div class="swiper-pagination swiper-pagination-square swiper-pagination-white swiper-full-screen-pagination"></div>
                <div class="swiper-button-next swiper-button-black-highlight d-none"></div>
                <div class="swiper-button-prev swiper-button-black-highlight d-none"></div>
                <!-- end slider pagination -->
            </div>
        </section>
        <!-- end slider section -->

        <!-- start about agency -->
        <section class="wow fadeIn">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-12 col-lg-10 col-md-11 text-center wow fadeInUp margin-two-bottom">
                        <h4 class="text-extra-dark-gray font-weight-700">Get the Skills you want and employers need.</h4>
                    </div>
                </div>
                <div class="row hm-ser">
                    <!-- start features box -->
                    <div class="col-12 col-lg-4 col-md-6 md-margin-30px-bottom wow fadeInUp">
                        <img src="<?php echo base_url() ?>maintemp/images/hm-1.png" />
                        <h6>Smart<br>Hiring Platform</h6>
                        <p>A great talent acquisition platform dedicated to hiring smart and skilled candidates suitable for a wide range of IT professional roles</p>
                        
                    
     <a class="btn btn-medium lg-margin-15px-bottom d-table d-lg-inline-block md-margin-lr-auto" href="smart-hiring.php">Learn More</a>
                    </div>
                    <!-- end feature box -->

                    <!-- start features box -->
                    <div class="col-12 col-lg-4 col-md-6 wow fadeInUp sm-margin-30px-bottom" data-wow-delay="0.4s">
                        <img src="<?php echo base_url() ?>maintemp/images/hm-2.png" />
                        <h6>Intelligent<br>Campus Recruitment</h6>
                        <p>A perfect campus hiring solution that manages everything from sourcing to screening and providing re-engineering activities and L&D programs</p>
                        <a class="btn btn-medium lg-margin-15px-bottom d-table d-lg-inline-block md-margin-lr-auto" href="intelligent-campus.php">Learn More</a>
                    </div>
                    <!-- end feature box -->
                    <!-- start features box -->
                    <div class="col-12 col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.6s">
                        <img src="<?php echo base_url() ?>maintemp/images/hm-3.png" />
                        <h6>KYW Program<br> (Know Your Workforce)</h6>
                        <p>The right way to empower your employees for guaranteed growth and increase your bottom-line<br>likenever before</p>
                        <a class="btn btn-medium lg-margin-15px-bottom d-table d-lg-inline-block md-margin-lr-auto" href="kyw-program.php">Learn More</a>
                    </div>
                    <!-- end feature box -->
                </div>
            </div>
        </section>
        <!-- end about agency section -->
        <!-- start feature box section -->
      <!--   <section class="padding-140px-tb new-bg wow fadeIn">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-12 col-xl-5 col-md-6 margin-eight-bottom md-margin-40px-bottom sm-margin-30px-bottom text-center">
                        <h5 class="alt-font text-white-2 font-weight-600 mb-0">Free e-Learning for ITPWCS IT Fundamentals</h5>
                        <br />

                        <a class="btn btn-small btn-white btn-rounded lg-margin-5px-bottom d-table d-lg-inline-block md-margin-lr-auto" href="#">SIGN UP</a>
                    </div>
                </div>
                <div class="row">
 
                    <div class="col-12 col-lg-4 col-md-6 md-margin-30px-bottom wow fadeInUp">
                        <a class="btn btn-medium btn-transparent-white lg-margin-15px-bottom d-table d-lg-inline-block md-margin-lr-auto" href="#">Support for Educators</a>
                    </div>
         
                    <div class="col-12 col-lg-4 col-md-6 wow fadeInUp sm-margin-30px-bottom" data-wow-delay="0.4s">
                        <a class="btn btn-medium btn-transparent-white lg-margin-15px-bottom d-table d-lg-inline-block md-margin-lr-auto" href="#">Support for Displaced Workers</a>
                    </div>
             
                    <div class="col-12 col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.6s">
                        <a class="btn btn-medium btn-transparent-white lg-margin-15px-bottom d-table d-lg-inline-block md-margin-lr-auto" href="#">Support for Technology Business</a>
                    </div>
 
                </div>
            </div>
        </section> -->



        <section style="padding-bottom: 20px;" class="solution-bg wow fadeIn">
            <div class="container">
                <div class="job-portal">
                <div class="row">
                    <div class="col-md-8 col-12 col-sm-12"><h2>Checkout Our <span style="font-weight: bold;">Job Portal</span></h2><p>Finding the right job is like discivering your own soul in the world</p></div>
                    <div class="col-md-2 col-6 col-sm-6"><a href="index.php"><button style="float: right;" type="button" class="btn btn-primary">Find Job</button></a></div>
                    <div class="col-md-2 col-6 col-sm-6"><a href="index.php"><button type="button" class="btn btn-primary">Find Internship</button></a></div>
                </div>
                </div>
            </div>
        </section>

        <!-- start blog post style 03 section -->
        <section class="wow fadeIn bg-light-gray bg-new">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-12 col-lg-8 text-center   sm-margin-40px-bottom">
                        <div class="position-relative overflow-hidden w-100">
                            <h4 class="text-extra-dark-gray text-outside-line-full alt-font font-weight-600">Get Involved with ITPWCS Today</h4>
                           <!--  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p> -->
                        </div>
                    </div>
                </div>
                <div class="row">
                    <!-- start blog post item -->
                    <div class="col-12 col-md-3 blog-post-style5 last-paragraph-no-margin sm-margin-30px-bottom wow fadeInUp">
                        <div class="blog-post bg-white text-center">
                            <div class="post-details padding-40px-all sm-padding-20px-lr sm-padding-30px-tb">
                                 <img src="<?php echo base_url() ?>maintemp/images/memb-4.png">
                                <h6 class="alt-font font-weight-600">General <br> Membership </h6>
                                <div class="separator-line-horrizontal-full bg-medium-gray margin-20px-tb"></div>
                                <a href="#" class="alt-font gmi post-title text-medium text-extra-dark-gray d-block lg-width-60 margin-5px-bottom">Reach your full potentials with Digital badge, seminars/webinars, events , scholarship etc..</a><br />

                                <a class="btn btn-small btn-dark-new btn-rounded lg-margin-15px-bottom d-table d-lg-inline-block md-margin-lr-auto" href="general.php">SIGN UP</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-md-3 blog-post-style5 last-paragraph-no-margin sm-margin-30px-bottom wow fadeInUp">
                        <div class="blog-post bg-white text-center">
                            <div class="post-details padding-40px-all sm-padding-20px-lr sm-padding-30px-tb">
                                 <img src="<?php echo base_url() ?>maintemp/images/memb-1.png">
                                <h6 class="alt-font font-weight-600">Student <br> Membership </h6>
                                <div class="separator-line-horrizontal-full bg-medium-gray margin-20px-tb"></div>
                                <a href="#" class="alt-font gmi post-title text-medium text-extra-dark-gray d-block lg-width-60 margin-5px-bottom">Take the charge of your career - to get an scholarships , IT reasearch program , industry network programs , access to our events , webinars , seminars Etc.. </a><br/>

                                <a class="btn btn-small btn-dark-new btn-rounded lg-margin-15px-bottom d-table d-lg-inline-block md-margin-lr-auto" href="students.php">SIGN UP</a>
                            </div>
                        </div>
                    </div>
                    <!-- end blog post item -->
                    <!-- start blog post item -->
                    <div class="col-12 col-md-3 blog-post-style5 last-paragraph-no-margin sm-margin-30px-bottom wow fadeInUp">
                        <div class="blog-post bg-white text-center">
                            <div class="post-details padding-40px-all sm-padding-20px-lr sm-padding-30px-tb">
                                <div class="blog-hover-color"></div>
                                <img src="<?php echo base_url() ?>maintemp/images/memb-2.png">
                                <h6 class="alt-font font-weight-600">Professionals Membership </h6>
                                <div class="separator-line-horrizontal-full bg-medium-gray margin-20px-tb"></div>
                                <a href="#" class="alt-font gmi post-title text-medium text-extra-dark-gray d-block lg-width-100 margin-5px-bottom">Take your next plan of your career to get an industrial chapter program , IT research programs , events , webinars , seminars , IT career planner, ... </a><br />

                                <a class="btn btn-small btn-dark-new btn-rounded lg-margin-15px-bottom d-table d-lg-inline-block md-margin-lr-auto" href="professional.php">SIGN UP</a>
                            </div>
                        </div>
                    </div>
                    <!-- end blog post item -->
                    <!-- start blog post item -->
                    <div class="col-12 col-md-3 blog-post-style5 last-paragraph-no-margin sm-margin-30px-bottom wow fadeInUp">
                        <div class="blog-post bg-white text-center">
                            <div class="post-details padding-40px-all sm-padding-20px-lr sm-padding-30px-tb">
                                <div class="blog-hover-color"></div>
                                 <img src="<?php echo base_url() ?>maintemp/images/memb-3.png">
                                <h6 class="alt-font font-weight-600">Corporate Membership </h6>
                                <div class="separator-line-horrizontal-full bg-medium-gray margin-20px-tb"></div>
                                <a href="#" class="alt-font gmi post-title text-medium text-extra-dark-gray d-block lg-width-100 margin-5px-bottom">
                                Growing together with ITPWCS program - Unlimited IT workforce accessing, partner level programs , product demo webinars with Top IT companies etc.</a><br />

                                <a class="btn btn-small btn-dark-new btn-rounded lg-margin-15px-bottom d-table d-lg-inline-block md-margin-lr-auto" href="corporates.php">SIGN UP</a>
                            </div>
                        </div>
                    </div>
                    <!-- end blog post item -->
                </div>
            </div>
        </section>
        <!-- end blog post style 03 section -->

        <!-- start blog section -->
        <section class="border-top border-color-extra-light-gray wow fadeIn">
            <div class="container">
                <div class="row">
                    <!-- start blog post item -->
                    <div class="col-12 col-lg-7 col-md-7 md-margin-50px-bottom sm-margin-30px-bottom last-paragraph-no-margin text-center text-md-left wow fadeInUp">
                        <div class="blog-post blog-post-style1">
                            <h5 class="alt-font text-extra-dark-gray font-weight-600 mb-0">Latest Blogs & News</h5>
                            <br />

                            <a class="btn btn-small btn-dark-new btn-rounded lg-margin-15px-bottom d-table d-lg-inline-block md-margin-lr-auto" href="#">View All</a><br />
                            <br />
                            <br />
                        </div>
                        <div class="row">
                            <!-- start blog post item -->
                            <div class="col-12 col-lg-12 col-md-12 sm-margin-30px-bottom last-paragraph-no-margin text-center text-md-left sm-clear-both wow fadeInUp" data-wow-delay="0.4s">
                                <div class="blog-post blog-post-style1 row">
                                    <div class="blog-post-images col-lg-3 overflow-hidden margin-25px-bottom md-margin-20px-bottom">
                                        <a href="#">
                                            <img src="<?php echo base_url() ?>maintemp/images/slide-2.jpg" alt="" />
                                        </a>
                                    </div>
                                    <div class="post-details col-lg-9">
                                        <span class="post-author text-extra-small text-medium-gray text-uppercase d-block margin-10px-bottom">15 march 2017 | by <a href="#" class="text-link-dark-gray">Hugh Macleod</a></span>
                                        <a href="#" class="post-title text-medium text-extra-dark-gray width-90 sm-width-100 d-block">
                                            Recognizing the need is the primary condition for design.Recognizing the need is the primary condition for design. Recognizing the need is the primary condition for design.
                                        </a>
                                        <div class="separator-line-horrizontal-full bg-medium-light-gray margin-15px-tb"></div>
                                    </div>
                                </div>
                            </div>
                            <!-- end blog post item -->
                        </div>

                        <div class="row">
                            <!-- start blog post item -->
                            <div class="col-12 col-lg-12 col-md-12 sm-margin-30px-bottom last-paragraph-no-margin text-center text-md-left sm-clear-both wow fadeInUp" data-wow-delay="0.4s">
                                <div class="blog-post blog-post-style1 row">
                                    <div class="blog-post-images col-lg-3 overflow-hidden margin-25px-bottom md-margin-20px-bottom">
                                        <a href="#">
                                            <img src="<?php echo base_url() ?>maintemp/images/slide-2.jpg" alt="" />
                                        </a>
                                    </div>
                                    <div class="post-details col-lg-9">
                                        <span class="post-author text-extra-small text-medium-gray text-uppercase d-block margin-10px-bottom">15 march 2017 | by <a href="#" class="text-link-dark-gray">Hugh Macleod</a></span>
                                        <a href="#" class="post-title text-medium text-extra-dark-gray width-90 sm-width-100 d-block">
                                            Recognizing the need is the primary condition for design.Recognizing the need is the primary condition for design. Recognizing the need is the primary condition for design.
                                        </a>
                                        <div class="separator-line-horrizontal-full bg-medium-light-gray margin-15px-tb"></div>
                                    </div>
                                </div>
                            </div>
                            <!-- end blog post item -->
                        </div>



                        <div class="row">
                            <!-- start blog post item -->
                            <div class="col-12 col-lg-12 col-md-12 sm-margin-30px-bottom last-paragraph-no-margin text-center text-md-left sm-clear-both wow fadeInUp" data-wow-delay="0.4s">
                                <div class="blog-post blog-post-style1 row">
                                    <div class="blog-post-images col-lg-3 overflow-hidden margin-25px-bottom md-margin-20px-bottom">
                                        <a href="#">
                                            <img src="<?php echo base_url() ?>maintemp/images/slide-2.jpg" alt="" />
                                        </a>
                                    </div>
                                    <div class="post-details col-lg-9">
                                        <span class="post-author text-extra-small text-medium-gray text-uppercase d-block margin-10px-bottom">15 march 2017 | by <a href="#" class="text-link-dark-gray">Hugh Macleod</a></span>
                                        <a href="#" class="post-title text-medium text-extra-dark-gray width-90 sm-width-100 d-block">
                                            Recognizing the need is the primary condition for design.Recognizing the need is the primary condition for design. Recognizing the need is the primary condition for design.
                                        </a>
                                        <div class="separator-line-horrizontal-full bg-medium-light-gray margin-15px-tb"></div>
                                    </div>
                                </div>
                            </div>
                            <!-- end blog post item -->
                        </div>
                        
                       




                    </div>


                    <!-- start blog post item -->
                    <div class="col-12 col-lg-5 col-md-5 last-paragraph-no-margin text-center text-md-left wow fadeInUp" data-wow-delay="0.6s">
                        <div class="blog-post blog-post-style1  ">
                            <div class="blog-post-images overflow-hidden margin-25px-bottom md-margin-20px-bottom ">
                                <a href="#">
                                    <img src="<?php echo base_url() ?>maintemp/images/slide-1.jpg" alt="" />
                                </a>
                            </div>
                            <div class="post-details ">
                                <span class="post-author text-extra-small text-medium-gray text-uppercase d-block margin-10px-bottom">10 march 2017 | by <a href="#" class="text-link-dark-gray">Jay Benjamin</a></span>
                                <a href="#" class="post-title text-medium text-extra-dark-gray width-90 sm-width-100 d-block">
                                    Get in over your head as often and as joyfully as possible. 
                                </a>
                                <div class="separator-line-horrizontal-full bg-medium-light-gray margin-20px-tb sm-margin-15px-tb"></div>
                            </div>
                        </div>
                    <!-- end blog post item -->

                        <div class="blog-post blog-post-style1 ">
                            <div class="blog-post-images overflow-hidden margin-25px-bottom md-margin-20px-bottom ">
                                <a href="#">
                                    <img src="<?php echo base_url() ?>maintemp/images/slide-2.jpg" alt="" />
                                </a>
                            </div>
                            <div class="post-details ">
                                <span class="post-author text-extra-small text-medium-gray text-uppercase d-block margin-10px-bottom">10 march 2017 | by <a href="#" class="text-link-dark-gray">Jay Benjamin</a></span>
                                <a href="#" class="post-title text-medium text-extra-dark-gray width-90 sm-width-100 d-block">
                                    Get in over your head as often and as joyfully as possible. 
                                </a>
                                <div class="separator-line-horrizontal-full bg-medium-light-gray margin-20px-tb sm-margin-15px-tb"></div>
                            </div>
                        </div>
                    <!-- end blog post item -->

                </div>
            </div>
        </div>


        <!-- PRICING TABLe -->

     

        <!-- end table -->
        </section>

        <section class="wow fadeIn">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-12 col-lg-7 text-center margin-100px-bottom sm-margin-40px-bottom">
                        <div class="position-relative overflow-hidden w-100">
                            <span class="text-small text-outside-line-full alt-font font-weight-600 text-uppercase">Our Partners</span>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12 col-md-3 margin-three-bottom text-center wow fadeInRight">
                        <a href="javascript:void(0);"><img src="<?php echo base_url() ?>maintemp/images/c-logo-1.png" alt=""></a>
                    </div>
                    <div class="col-12 col-md-3 margin-three-bottom text-center wow fadeInRight" data-wow-delay="0.2s">
                        <a href="javascript:void(0);"><img src="<?php echo base_url() ?>maintemp/images/c-logo-2.png" alt=""></a>
                    </div>
                    <div class="col-12 col-md-3 margin-three-bottom text-center wow fadeInRight" data-wow-delay="0.4s">
                        <a href="javascript:void(0);"><img src="<?php echo base_url() ?>maintemp/images/c-logo-3.png" alt=""></a>
                    </div>
                    <div class="col-12 col-md-3 margin-three-bottom text-center wow fadeInRight" data-wow-delay="0.6s">
                        <a href="javascript:void(0);"><img src="<?php echo base_url() ?>maintemp/images/c-logo-4.png" alt=""></a>
                    </div>
                    <div class="col-12 col-md-3 sm-margin-three-bottom text-center wow fadeInRight" data-wow-delay="0.8s">
                        <a href="javascript:void(0);"><img src="<?php echo base_url() ?>maintemp/images/c-logo-5.png" alt=""></a>
                    </div>
                    <div class="col-12 col-md-3 sm-margin-three-bottom text-center wow fadeInRight" data-wow-delay="1s">
                        <a href="javascript:void(0);"><img src="<?php echo base_url() ?>maintemp/images/c-logo-6.png" alt=""></a>
                    </div>
                    <div class="col-12 col-md-3 sm-margin-three-bottom text-center wow fadeInRight" data-wow-delay="1.2s">
                        <a href="javascript:void(0);"><img src="<?php echo base_url() ?>maintemp/images/c-logo-7.png" alt=""></a>
                    </div>
                    <div class="col-12 col-md-3 sm-margin-three-bottom text-center wow fadeInRight" data-wow-delay="1.4s">
                        <a href="javascript:void(0);"><img src="<?php echo base_url() ?>maintemp/images/c-logo-8.png" alt=""></a>
                    </div>
                    <div class="col-12 col-md-3 sm-margin-three-bottom text-center wow fadeInRight" data-wow-delay="0.8s">
                        <a href="javascript:void(0);"><img src="<?php echo base_url() ?>maintemp/images/c-logo-9.png" alt=""></a>
                    </div>
                    <div class="col-12 col-md-3 sm-margin-three-bottom text-center wow fadeInRight" data-wow-delay="1s">
                        <a href="javascript:void(0);"><img src="<?php echo base_url() ?>maintemp/images/c-logo-10.png" alt=""></a>
                    </div>
                    <div class="col-12 col-md-3 sm-margin-three-bottom text-center wow fadeInRight" data-wow-delay="1.2s">
                        <a href="javascript:void(0);"><img src="<?php echo base_url() ?>maintemp/images/c-logo-11.png" alt=""></a>
                    </div>
                    <div class="col-12 col-md-3 sm-margin-three-bottom text-center wow fadeInRight" data-wow-delay="1.4s">
                        <a href="javascript:void(0);"><img src="<?php echo base_url() ?>maintemp/images/c-logo-12.png" alt=""></a>
                    </div>
                </div>
            </div>
        </section>
<section class="wow fadeIn testiminial">
    <h4>TESTIMONIALS</h4>
     <div class="container px-2 px-md-4 py-5 mx-auto wow fadeInUp" data-wow-delay="0.6s">

     <div class="row d-flex justify-content-center ">
         <div class="col-md-10">
             <div id="carouselExampleIndicators" class="carousel slide d-flex" data-ride="carousel">
                 <ol class="carousel-indicators">
                     <li data-target="#carouselExampleIndicators" data-slide-to="0"></li>
                     <li data-target="#carouselExampleIndicators" data-slide-to="1" class="active"></li>
                     <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                 </ol>
                 <div class="carousel-inner ">
                     <div class="carousel-item testi">
                         <div class="card border-0 ">
                             <div class="card-header">
                                <h5>I believe that one defines oneself by reinvention. To not be like your parents. To not be like your friends. To be yourself. To cut yourself out of stone.</h5>
                             </div>
                             <div class="card-body text-center "><img class="img-1 img-fluid" src="https://i.imgur.com/nUNhspp.jpg">
                                 <div class="testi-p">
                                     
                                     <h6>Sophia V./ Company Inc</h6>
                                     <p>Wholises</p>
                                 </div>
                             </div>
                         </div>
                     </div>
                     <div class="carousel-item testi active">
                         <div class="card border-0 ">
                             <div class="card-header">
                                <h5>I believe that one defines oneself by reinvention. To not be like your parents. To not be like your friends. To be yourself. To cut yourself out of stone.</h5>
                             </div>
                             <div class="card-body text-center "><img class="img-1 img-fluid" src="https://i.imgur.com/kkjs7EC.png">
                                 <div class="testi-p">
                                     
                                     <h6>Sophia V./ Company Inc</h6>
                                     <p>Wholises</p>
                                 </div>
                             </div>
                         </div>
                     </div>
                     <div class="carousel-item testi">
                         <div class="card border-0 ">
                             <div class="card-header">
                               <h5>I believe that one defines oneself by reinvention. To not be like your parents. To not be like your friends. To be yourself. To cut yourself out of stone.</h5>
                             </div>
                             <div class="card-body text-center "><img class="img-1 img-fluid" src="https://i.imgur.com/At1IG6H.png">
                                 <div class="testi-p">
                                     
                                    <h6>Sophia V./ Company Inc</h6>
                                     <p>Wholises</p>
                                 </div>
                             </div>
                         </div>
                     </div>
                 </div>
             </div>
         </div>
     </div>
 </div>
</section>






        <!-- end blog section -->

        <?php include 'footer.php';?>

        <!-- start scroll to top -->
        <a class="scroll-top-arrow" href="javascript:void(0);"><i class="ti-arrow-up"></i></a>
        <!-- end scroll to top  -->
        <!-- javascript libraries -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/modernizr.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/bootstrap.bundle.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.easing.1.3.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/skrollr.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/smooth-scroll.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.appear.js"></script>




        <!-- menu navigation -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/bootsnav.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.nav.js"></script>
        <!-- animation -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/wow.min.js"></script>
        <!-- page scroll -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/page-scroll.js"></script>
        <!-- swiper carousel -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/swiper.min.js"></script>
        <!-- counter -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.count-to.js"></script>
        <!-- parallax -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.stellar.js"></script>
        <!-- magnific popup -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.magnific-popup.min.js"></script>
        <!-- portfolio with shorting tab -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/isotope.pkgd.min.js"></script>
        <!-- images loaded -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/imagesloaded.pkgd.min.js"></script>
        <!-- pull menu -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/classie.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/hamburger-menu.js"></script>
        <!-- counter  -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/counter.js"></script>
        <!-- fit video  -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.fitvids.js"></script>
        <!-- skill bars  -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/skill.bars.jquery.js"></script>
        <!-- justified gallery  -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/justified-gallery.min.js"></script>
        <!--pie chart-->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.easypiechart.min.js"></script>
        <!-- instagram -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/instafeed.min.js"></script>
        <!-- retina -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/retina.min.js"></script>
        <!-- revolution -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/revolution/js/jquery.themepunch.tools.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/revolution/js/jquery.themepunch.revolution.min.js"></script>

        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/main.js"></script>

        <script type="text/javascript">
            

function resetActive(event, percent, step) {
        $(".progress-bar").css("width", percent + "%").attr("aria-valuenow", percent);
        $(".progress-completed").text(percent + "%");

        $("div").each(function () {
            if ($(this).hasClass("activestep")) {
                $(this).removeClass("activestep");
            }
        });

        if (event.target.className == "col-md-2") {
            $(event.target).addClass("activestep");
        }
        else {
            $(event.target.parentNode).addClass("activestep");
        }

        hideSteps();
        showCurrentStepInfo(step);
    }

    function hideSteps() {
        $("div").each(function () {
            if ($(this).hasClass("activeStepInfo")) {
                $(this).removeClass("activeStepInfo");
                $(this).addClass("hiddenStepInfo");
            }
        });
    }

    function showCurrentStepInfo(step) {        
        var id = "#" + step;
        $(id).addClass("activeStepInfo");
    }


            
        </script>
    </body>
</html>
