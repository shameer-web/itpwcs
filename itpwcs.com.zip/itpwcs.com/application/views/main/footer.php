  

         <!-- start footer --> 
        <footer class="footer-classic-dark bg-extra-dark-gray padding-five-bottom sm-padding-30px-bottom">
            
            <div class="footer-widget-area padding-five-tb sm-padding-30px-tb">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-3 col-md-6 widget border-right border-color-medium-dark-gray md-no-border-right md-margin-30px-bottom sm-text-center">
                            <!-- start logo -->
                            <div class="widget-title alt-font text-small text-medium-gray text-uppercase margin-15px-bottom font-weight-600">About ITPWCS</div>
                            <p class="text-small width-95 sm-width-100">ITPWCS is Kerala’s largest IT professional organization dedicated to implementation of technology in an advanced way. Since 2013 ITPWCS has helped substantially to strengthen Kerala’s IT industry by establishing standards and sharing best practices for the benefit of individual IT professionals and the sector as a whole.  </p>
                            <!-- start social media -->
                            <div class="social-icon-style-8 d-inline-block vertical-align-middle">
                                <ul class="small-icon no-margin-bottom">
                                    <li><a class="facebook text-white-2" href="https://www.facebook.com/itpwcsindia/?modal=admin_todo_tour" target="_blank"><i class="fab fa-facebook-f" aria-hidden="true"></i></a></li>
                                    <li><a class="twitter text-white-2" href="https://twitter.com/" target="_blank"><i class="fab fa-twitter"></i></a></li>
                                    <li><a class="linkdin text-white-2" href="https://www.linkedin.com/company/68279505/admin/" target="_blank"><i class="fab fa-linkedin"></i></a></li>
                                    <li><a class="instagram text-white-2" href="https://www.instagram.com/itpwcsindia/" target="_blank"><i class="fab fa-instagram no-margin-right" aria-hidden="true"></i></a></li>
                                </ul>
                            </div>
                            <!-- end social media -->
                        </div>
                        <!-- start additional links -->
                        <div class="col-lg-2 col-md-6 widget border-right border-color-medium-dark-gray padding-45px-left md-padding-15px-left md-no-border-right md-margin-30px-bottom text-center text-md-left">
                            <div class="widget-title alt-font text-small text-medium-gray text-uppercase margin-10px-bottom font-weight-600">Main  Links</div>
                            <ul class="list-unstyled">
                                <li><a class="text-small" href="index.php">Home</a></li>
                                <li><a class="text-small" href="members.php">Members</a></li>
                                <li><a class="text-small" href="services.php">Services</a></li>
                                <li><a class="text-small" href="job-portal.php">Jobportel</a></li>
                                <li><a class="text-small" href="about.php">About Us</a></li>
                                <li><a class="text-small" href="events.php">Events</a></li>
                                <li><a class="text-small" href="contact.php">Contact Us</a></li>
                            </ul>
                        </div>
                        <!-- end additional links -->
                        <!-- start contact information -->
                        <div class="col-lg-4 col-md-6 widget border-right border-color-medium-dark-gray padding-45px-left md-padding-15px-left md-clear-both md-no-border-right sm-margin-30px-bottom text-center text-md-left">
                            <div class="widget-title alt-font text-small text-medium-gray text-uppercase margin-10px-bottom font-weight-600">Contact Info</div>
                            <p class="text-small d-block margin-15px-bottom width-80 sm-width-100"><b>HQ: Trivandrum</b><br> ITPWCS, 2rd floor, KNMS Building, AIR Road, Vazhuthacaud, TVPM  695014</p>

                              <p class="text-small d-block margin-15px-bottom width-80 sm-width-100"><b>Cochin</b><br> ITPWCS, 48/1286, 1st Floor, Mabara Road, Ponnurunni, Kochin 682019</p>

                            <div class="text-small">Email: <a href="mailto:info@itpwcs.in">info@itpwcs.in</a></div>
                            <div class="text-small">Phone: +91 8590895992, +91 7012674903</div>
               
                        </div>
                        <!-- end contact information -->
                        <!-- start instagram -->
                        <div class="col-lg-3 col-md-6 widget padding-45px-left md-padding-15px-left text-center text-md-left">
                            <div class="widget-title alt-font text-small text-medium-gray text-uppercase margin-20px-bottom font-weight-600">Instagram portfolio</div>
                            <div class="instagram-follow-api">
                                <ul id="instaFeed-footer"></ul>
                            </div>
                        </div>
                        <!-- end instagram -->
                    </div>
                </div>
            </div>
 


            <div class="container">
 
                <!-- start copyright -->
                <div class="footer-bottom border-top border-color-medium-dark-gray padding-40px-top sm-padding-30px-top">
                    <div class="row align-items-center">
                        <div class="col-md-6 text-md-left text-center text-small">ITPWCS |<a style="margin-left: 30px; font-size: 12px;" href="terms-conditions.php"> Terms and Conditions</a>  </div>
                        <div class="col-md-6 text-md-right text-center text-small">&copy; 2020 ITPWCS  Powered by <a href="http://www.willowy.in/" target="_blank" title="Willowy Solutions">Willowy Solutions</a></div>
                    </div>
                </div>
                <!-- end copyright -->
 
            </div>
        </footer>
        <!-- end footer -->