<!doctype html>
<html class="no-js" lang="en">
    <head>
        <!-- title -->
        <title>ITPWCS</title>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1" />
        <meta name="author" content=" ">
        <!-- description -->
        <meta name="description" content="ITPWCS">
        <!-- keywords -->
        <meta name="keywords" content="ITPWCS">
        <!-- favicon -->
        <link rel="shortcut icon" href="<?php echo base_url() ?>maintemp/images/favicon.png">
<!--         <link rel="apple-touch-icon" href="images/apple-touch-icon-57x57.png">
        <link rel="apple-touch-icon" sizes="72x72" href="images/apple-touch-icon-72x72.png">
        <link rel="apple-touch-icon" sizes="114x114" href="images/apple-touch-icon-114x114.png"> -->
        <!-- animation -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/animate.css" />
        <!-- bootstrap -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/bootstrap.min.css" />
        <!-- et line icon --> 
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/et-line-icons.css" />
        <!-- font-awesome icon -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/font-awesome.min.css" />
        <!-- themify icon -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/themify-icons.css">
        <!-- swiper carousel -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/swiper.min.css">
        <!-- justified gallery  -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/justified-gallery.min.css">
        <!-- magnific popup -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/magnific-popup.css" />
        <!-- revolution slider -->
        <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>maintemp/revolution/css/settings.css" media="screen" />
        <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>maintemp/revolution/css/layers.css">
        <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>maintemp/revolution/css/navigation.css">
        <!-- bootsnav -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/bootsnav.css">
        <!-- style -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/style.css" />
        <!-- responsive css -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/responsive.css" />
        <!--[if IE]>
            <script src="js/html5shiv.js"></script>
        <![endif]-->
    </head>
    <body>
        

    <?php $page = 'contact';?>
    <?php include 'header.php';?>


    <!-- start page title section -->
    <section class="   padding-0px-tb  top-space"></section>
    <!-- end page title section -->
       
        <!-- end help section -->
        <!-- start contact section -->
        <section class="no-padding bg-extra-dark-gray">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12 col-lg-6 p-0 cover-background md-height-450px sm-height-350px wow fadeInLeft" ><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d4016382.3035029946!2d74.95974836151257!3d10.559729364683534!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3b0812ffd49cf55b%3A0x64bd90fbed387c99!2sKerala!5e0!3m2!1sen!2sin!4v1592074899038!5m2!1sen!2sin" width="100%" height="640" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe></div>

                    <div class="col-12 col-lg-6 p-0 wow fadeInRight">
                        <div class="row m-0">
                            <!-- start contact item -->
                            <div class="col-12 col-md-6 bg-extra-dark-gray d-flex flex-column justify-content-center align-items-center text-center height-321px last-paragraph-no-margin">
                                <i class="icon-map text-deep-pink icon-medium margin-25px-bottom"></i>
                                <div class="text-white-2 text-uppercase alt-font font-weight-600 margin-5px-bottom">Head Office Address</div>
                                <p class="width-60 lg-width-80 mx-auto text-medium"> ITPWCS, 2rd floor, KNMS Building, AIR Road, Vazhuthacaud, Trivandrum-695014</p>
                            </div>
                            <!-- end contact item -->
                            <!-- start contact item -->
                            <div class="col-12 col-md-6 bg-black d-flex flex-column justify-content-center align-items-center text-center height-321px last-paragraph-no-margin">
                                 <i class="icon-map text-deep-pink icon-medium margin-25px-bottom"></i>
                                <div class="text-white-2 text-uppercase alt-font font-weight-600 margin-5px-bottom">Kochin Address</div>
                                <p class="width-60 lg-width-80 mx-auto text-medium"> ITPWCS, 48/1286, 1st Floor, Mabara Road, Ponnurunni, Kochin-682019</p>
                            </div>
                            <!-- end contact item -->
                            <!-- start contact item -->
                            <div class="col-12 col-md-6 bg-black d-flex flex-column justify-content-center align-items-center text-center height-321px last-paragraph-no-margin">
                               <i class="icon-chat text-deep-pink icon-medium margin-25px-bottom"></i>
                                <div class="text-white-2 text-uppercase alt-font font-weight-600 margin-5px-bottom">Let's Talk</div>
                                <p class="mx-auto text-medium mb-0">Phone: +91 8590895992, <br>+91 7012674903</p>
                            
                            </div>
                            <!-- end contact item -->
                            <!-- start contact item -->
                            <div class="col-12 col-md-6 bg-extra-dark-gray d-flex flex-column justify-content-center align-items-center text-center height-321px last-paragraph-no-margin">

                                 <i class="icon-envelope text-deep-pink icon-medium margin-25px-bottom"></i>
                                <div class="text-white-2 text-uppercase alt-font font-weight-600 margin-5px-bottom">Email Us</div>
                                <p class="mx-auto text-medium mb-0"><a href="mailto:info@itpwcs.in">info@itpwcs.in</a></p>
                                 
                               
                            </div>
                            <!-- end contact item -->
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- end contact section -->        
        <!-- start form section -->
        <section class="wow fadeIn" id="start-your-project">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-12 col-lg-6 col-md-8   md-margin-10px-bottom sm-margin-10px-bottom text-center last-paragraph-no-margin">
                        <h5 class="alt-font font-weight-700 text-extra-dark-gray text-uppercase">Tell us about you</h5>
                    </div>  
                </div>
                <form id="project-contact-form" action="" method="post">
                    <div class="row">
                        <div class="col-12">
                            <div id="success-project-contact-form" class="mx-0"></div>
                        </div>
                        <div class="col-12 col-lg-6">
                            <input type="text" name="name" id="name" placeholder="Name *" required class="big-input">
                        </div>
                        <div class="col-12 col-lg-6">
                            <input type="text" name="phone" id="phone" placeholder="Phone" required class="big-input">
                        </div>
                        <div class="col-12 col-lg-6">
                            <input type="text" name="email" id="email" placeholder="E-mail *" required class="big-input">
                        </div>
                        <div class="col-12 col-lg-6">
                            <input type="text" name="company" id="company" placeholder="Company *"  class="big-input">
                        </div>
                        <div class="col-12">
                            <textarea name="comment" id="comment" placeholder="Comments" rows="4" class="big-textarea"></textarea>
                        </div>
                        <div class="col-12 text-center">
                            <button id="project-contact-us-button" type="submit" class="btn btn-transparent-dark-gray btn-large margin-20px-top">send message</button>
                        </div>
                    </div>
                </form>
            </div>
        </section>
      


  
    <?php include 'footer.php';?>
        
        <!-- start scroll to top -->
        <a class="scroll-top-arrow" href="javascript:void(0);"><i class="ti-arrow-up"></i></a>
        <!-- end scroll to top  -->
        <!-- javascript libraries -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/modernizr.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/bootstrap.bundle.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.easing.1.3.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/skrollr.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/smooth-scroll.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.appear.js"></script>
        <!-- menu navigation -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/bootsnav.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.nav.js"></script>
        <!-- animation -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/wow.min.js"></script>
        <!-- page scroll -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/page-scroll.js"></script>
        <!-- swiper carousel -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/swiper.min.js"></script>
        <!-- counter -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.count-to.js"></script>
        <!-- parallax -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.stellar.js"></script>
        <!-- magnific popup -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.magnific-popup.min.js"></script>
        <!-- portfolio with shorting tab -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/isotope.pkgd.min.js"></script>
        <!-- images loaded -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/imagesloaded.pkgd.min.js"></script>
        <!-- pull menu -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/classie.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/hamburger-menu.js"></script>
        <!-- counter  -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/counter.js"></script>
        <!-- fit video  -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.fitvids.js"></script>
        <!-- skill bars  -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/skill.bars.jquery.js"></script> 
        <!-- justified gallery  -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/justified-gallery.min.js"></script>
        <!--pie chart-->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.easypiechart.min.js"></script>
        <!-- instagram -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/instafeed.min.js"></script>
        <!-- retina -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/retina.min.js"></script>
        <!-- revolution -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/revolution/js/jquery.themepunch.tools.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/revolution/js/jquery.themepunch.revolution.min.js"></script>
         
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/main.js"></script>
    </body>
</html>