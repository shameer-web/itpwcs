<!doctype html>
<html class="no-js" lang="en">
    <head>
        <!-- title -->
        <title>ITPWCS</title>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1" />
        <meta name="author" content=" ">
        <!-- description -->
        <meta name="description" content="ITPWCS">
        <!-- keywords -->
        <meta name="keywords" content="ITPWCS">
        <!-- favicon -->
        <link rel="shortcut icon" href="<?php echo base_url() ?>maintemp/images/favicon.png">
<!--         <link rel="apple-touch-icon" href="images/apple-touch-icon-57x57.png">
        <link rel="apple-touch-icon" sizes="72x72" href="images/apple-touch-icon-72x72.png">
        <link rel="apple-touch-icon" sizes="114x114" href="images/apple-touch-icon-114x114.png"> -->
        <!-- animation -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/animate.css" />
        <!-- bootstrap -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/bootstrap.min.css" />
        <!-- et line icon --> 
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/et-line-icons.css" />
        <!-- font-awesome icon -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/font-awesome.min.css" />
        <!-- themify icon -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/themify-icons.css">
        <!-- swiper carousel -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/swiper.min.css">
        <!-- justified gallery  -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/justified-gallery.min.css">
        <!-- magnific popup -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/magnific-popup.css" />
        <!-- revolution slider -->
        <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>maintemp/revolution/css/settings.css" media="screen" />
        <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>maintemp/revolution/css/layers.css">
        <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>maintemp/revolution/css/navigation.css">
        <!-- bootsnav -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/bootsnav.css">
        <!-- style -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/style.css" />
        <!-- responsive css -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/responsive.css" />
        <!--[if IE]>
            <script src="js/html5shiv.js"></script>
        <![endif]-->
    </head>
    <body>
        

    <?php $page = 'about';?>
    <?php include 'header.php';?>

    <!-- start page title section -->
    <section class="   padding-0px-tb  top-space"></section>
    <!-- end page title section -->



        <!-- end page title section -->     
        <!-- start story section -->
        <section class="wow fadeIn">
            <div class="container"> 
               <div class="row align-items-center">
                    <div class="col-12 col-lg-4 md-margin-15px-bottom">
                        <span class="text-extra-large text-extra-dark-gray alt-font width-90 display-block">ITPWCS is Kerala’s largest IT professional organization dedicated to implementation of technology in an advanced way.  </span>
                    </div>
                    <div class="col-12 col-lg-4 md-margin-15px-bottom">
                       
                        <p>Since 2013 ITPWCS has helped substantially to strengthen Kerala’s IT industry by establishing standards and sharing best practices for the benefit of individual IT professionals and the sector as a whole. ITPWCS has affiliations from several government structures like NYKS and Kerala state youth welfare board. We provide our members with the advocacy, networking and professional development services that help them to thrive nationally and compete globally. As Information technology professional’s welfare and charitable society (ITPWS), encourages technology adoption to capitalize on productivity and performance opportunities across all sectors.</p>
                    </div>
                    <div class="col-12 col-lg-4">
                   
                        <p>We, as an integrated rooftop, focus on the bases of New Start-ups functioning across India and outside and their fluency in rapid growth and evolvement. Keeping the fact in the mind that new start-ups and small agencies do not have much resources and higher-level connections compared to the Big Giants of Tech-World,  We, try our best attempts in sincerity to help them out with substantial nurturing and special care. These special measures, taken by us, not only provide them a good solidity of exposure in the wider IT world but also gives them a bigger sense of ‘Umbrella’ protection for overall alimentation and self-acknowledging potentials.</p>
                    </div> 

                    <div class="col-12 col-lg-4"></div>
                    <div class="col-12 col-lg-8">
                        <h6>The standard for the ITPCWCS includes:</h6>
                        <ul class="p-0 list-style-3 list-style-color">
                            <li>Demonstrated breadth of IT knowledge, well developed and broad technical understanding of IT</li> 
                            <li>Competence in one or more specialist areas of IT (technical /domain knowledge at SFIA Level 5 / equivalent/above)</li> 
                            <li>Demonstrated understanding of the strategic nature of IT and how it applies to the business model</li> 
                            <li>Capability to operate at the Skills Framework for the Information Age (SFIA) Level 5 or equivalent or above).</li> 
                        </ul>
                    </div>                   
                </div>
                
            </div>
        </section>
        <!-- end story section -->

   <!-- end page title section -->     
        <!-- start story section -->
        <section class="wow new-bg2 fadeIn">
            <div class="container"> 
               <div class="row align-items-center">

                    <div class="col-12 col-lg-7">
                        <h6 class="alt-font text-white font-weight-700 ged-txt3 margin-20px-bottom text-uppercase">Mission</h6>
                        <p class="text-white">ITPWCS's mission is to promote and enhance significant contribution that digital technology can make to Kerala’s economic prosperity. Our true mission of objectives is to ensure the supreme productive innovation in Techno-Digital world by upholding the various technological tools of our modern living society. We are committed to serve ‘You’ through the latest developments of digital world scenarios along with the various advancements of the recent most technology.</p>
                        <h6 class="ged-txt3">To do this we are focused on the expansion of an innovation ecosystem that:</h6>
                        <ul class="p-0 list-style-3 list-style-color text-white">
                            <li>Improves productivity through the robust adoption of technology.</li> 
                            <li>Drives innovation and competitiveness within the technology sector. </li> 
                            <li>Improves the talent pool, skills & diversity of the technology sector.</li> 
                            <li>Modernizes the general public sector in its use of data technology.</li> 
                        </ul>
                    </div>  
                    <div class="col-12 col-lg-5 md-margin-15px-bottom">
<h6 class="alt-font font-weight-700 text-white ged-txt3 margin-20px-bottom text-uppercase">Vision</h6>

                        <p class="text-white"> ITPWCS's core purpose is to foster technological innovation and excellence for the advancement of humanity.  We provide our members with the advocacy, networking and professional development services that help them to thrive nationally and compete globally.<br><br>
                        As Information technology professional’s welfare and charitable society (ITPWS), encourages technology adoption to capitalize on productivity and performance opportunities across all sectors</p>
                    </div>

                </div>
                
            </div>
        </section>
        <!-- end story section -->

 




       
         


 
 
        
        
    
    <?php include 'footer.php';?>

        
        <!-- start scroll to top -->
        <a class="scroll-top-arrow" href="javascript:void(0);"><i class="ti-arrow-up"></i></a>
        <!-- end scroll to top  -->
        <!-- javascript libraries -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/modernizr.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/bootstrap.bundle.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.easing.1.3.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/skrollr.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/smooth-scroll.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.appear.js"></script>
        <!-- menu navigation -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/bootsnav.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.nav.js"></script>
        <!-- animation -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/wow.min.js"></script>
        <!-- page scroll -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/page-scroll.js"></script>
        <!-- swiper carousel -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/swiper.min.js"></script>
        <!-- counter -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.count-to.js"></script>
        <!-- parallax -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.stellar.js"></script>
        <!-- magnific popup -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.magnific-popup.min.js"></script>
        <!-- portfolio with shorting tab -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/isotope.pkgd.min.js"></script>
        <!-- images loaded -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/imagesloaded.pkgd.min.js"></script>
        <!-- pull menu -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/classie.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/hamburger-menu.js"></script>
        <!-- counter  -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/counter.js"></script>
        <!-- fit video  -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.fitvids.js"></script>
        <!-- skill bars  -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/skill.bars.jquery.js"></script> 
        <!-- justified gallery  -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/justified-gallery.min.js"></script>
        <!--pie chart-->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.easypiechart.min.js"></script>
        <!-- instagram -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/instafeed.min.js"></script>
        <!-- retina -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/retina.min.js"></script>
        <!-- revolution -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/revolution/js/jquery.themepunch.tools.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/revolution/js/jquery.themepunch.revolution.min.js"></script>
         
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/main.js"></script>
    </body>
</html>