<!doctype html>
<html class="no-js" lang="en">
    <head>
        <!-- title -->
        <title>ITPWCS</title>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1" />
        <meta name="author" content=" ">
        <!-- description -->
        <meta name="description" content="ITPWCS">
        <!-- keywords -->
        <meta name="keywords" content="ITPWCS">
        <!-- favicon -->
        <link rel="shortcut icon" href="<?php echo base_url() ?>maintemp/images/favicon.png">
<!--         <link rel="apple-touch-icon" href="images/apple-touch-icon-57x57.png">
        <link rel="apple-touch-icon" sizes="72x72" href="images/apple-touch-icon-72x72.png">
        <link rel="apple-touch-icon" sizes="114x114" href="images/apple-touch-icon-114x114.png"> -->
        <!-- animation -->

        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/animate.css" />
        <!-- bootstrap -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/bootstrap.min.css" />
        <!-- et line icon --> 
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/et-line-icons.css" />
        <!-- font-awesome icon -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/font-awesome.min.css" />
        <!-- themify icon -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/themify-icons.css">
        <!-- swiper carousel -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/swiper.min.css">
        <!-- justified gallery  -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/justified-gallery.min.css">
        <!-- magnific popup -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/magnific-popup.css" />

        <!-- revolution slider -->
        <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>maintemp/revolution/css/settings.css" media="screen" />
        <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>maintemp/revolution/css/layers.css">
        <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>maintemp/revolution/css/navigation.css">
        <!-- bootsnav -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/bootsnav.css">
        <!-- style -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/style.css" />
        <!-- responsive css -->
        <link rel="stylesheet" href="<?php echo base_url() ?>maintemp/css/responsive.css" />
        <!--[if IE]>
            <script src="js/html5shiv.js"></script>
        <![endif]-->

<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker.css'>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


<!-- Vendor CSS-->


<!-- Main CSS-->
<link href="<?php echo base_url() ?>maintemp/newcss/main.css" rel="stylesheet" media="all">

    </head>
    <body>
        

    <?php $page = 'services';?>
    <?php include 'header.php';?>


       <section class="   padding-0px-tb  top-space"></section>
    <!-- end page title section -->


        


<div class="container my-4">
        <!--Grid row-->
    <div class="row">

      <!--Grid column-->
      <div style="background: linear-gradient(to right, #64aecd  0%, #84c144  100%);" class="col-md-3 side-tab ">
<p class="font-weight-bold">What is in your test</p>
        <ul style="margin-bottom: 40px;" class="nav md-pills pills-secondary d-flex flex-column">

          <li class="nav-item">

            <a class="nav-link active" data-toggle="tab" href="#panel11" role="tab"><i class="far fa-circle"></i>Choose Membership Type</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" data-toggle="tab" href="#panel12" role="tab"><i class="far fa-circle"></i>ITPWCS Membership Form</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" data-toggle="tab" href="#panel13" role="tab"><i class="far fa-circle"></i>Pre-Feedback</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" data-toggle="tab" href="#panel14" role="tab"><i class="far fa-circle"></i>Take Your Assessment</a>
          </li>
        </ul>

      </div>
      <!--Grid column-->

      <!--Grid column-->
      <div class="col-md-9 mb-4">

        <!-- Tab panels -->
        <div class="tab-content pt-0">

          <!--Panel 1-->
          <div class="tab-pane fade in show active" id="panel11" role="tabpanel">
            <br>
<div class="row">

  <div class="col-md-12 choose-membr">
    <h6>Choose your membership type ?</h6>
  <div style="margin: auto;" class="col-md-6">

  <!-- Group of default radios - option 1 -->
<div class="custom-control custom-radio mb-4">
  <input type="radio" class="custom-control-input" id="defaultGroupExample1" name="groupOfDefaultRadios">
  <label class="custom-control-label" for="defaultGroupExample1">Already a member</label>
</div>

<!-- Group of default radios - option 2 -->
<div class="custom-control custom-radio mb-4">
  <input type="radio" class="custom-control-input" id="defaultGroupExample2" name="groupOfDefaultRadios" checked>
  <label class="custom-control-label" for="defaultGroupExample2">Register as student</label>
</div>

<!-- Group of default radios - option 3 -->
<div class="custom-control custom-radio mb-4">
  <input type="radio" class="custom-control-input" id="defaultGroupExample3" name="groupOfDefaultRadios">
  <label class="custom-control-label" for="defaultGroupExample3">Sign in as Guest</label>
</div>
<a href="already-member.php" target="_self"><button type="button" class="btn btn-primary">Submit</button></a>
</div>
  </div>
            
            </div>
          </div>
          <!--/.Panel 1-->

          <!--Panel 2-->
          <div class="tab-pane fade" id="panel12" role="tabpanel">
            <br>

            <div class="row">

  <div class="col-md-12">
    <div class="col-md-8 mx-auto ">
        <h2 style="font-family: 'Montserrat', sans-serif; color: #09c976; font-size: 30px; text-align: center; padding-bottom: 30px; font-weight: 600;">STUDENT MEMBERSHIP FORM</h2>
    <div class="row">
        <div class="col-md-6 frm-lyt"><div class="form-group mb-2">
                  <label>Full Name <span style="color: #cc0202;">*</span></label>
                  <input type="text" class="form-control" placeholder="Full Name">
                </div></div>
<div class="col-md-6 frm-lyt"><div class="form-group mb-2">
                  <label>Email Address <span style="color: #cc0202;">*</span></label>
                  <input type="text" class="form-control" placeholder="Email Address">
                </div></div>
                <div class="col-md-6 frm-lyt"><div class="form-group mb-2">
                  <label>Organization Name <span style="color: #cc0202;">*</span></label>
                  <input type="text" class="form-control" placeholder="Organization Name">
                </div></div>
                <div class="col-md-6 frm-lyt"><div class="form-group mb-2">
                  <label>Job Title <span style="color: #cc0202;">*</span></label>
                  <input type="text" class="form-control" placeholder="Job Title">
                </div></div>
                <div class="col-md-6 frm-lyt"><div class="form-group mb-2">
                  <label>DOB <span style="color: #cc0202;">*</span></label>
<div id="datepicker" class="input-group date" data-date-format="mm-dd-yyyy">
    <input class="form-control" type="text" readonly />
    <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
</div>
                </div></div>
               <div class="col-md-6 frm-drp"><div class="form-group mb-2">
                <label>Select Country <span style="color: #cc0202;">*</span></label>
                   <select class="browser-default custom-select mb-4">
            <option value="" selected="">Select Country</option>
            <option value="1" selected="">India</option>
            <option value="2">Brazil</option>
            <option value="3">China</option>
          </select>

               </div>
            </div>
            <div class="col-md-6 frm-drp"><div class="form-group mb-2">
                <label>State <span style="color: #cc0202;">*</span></label>
                   <select class="browser-default custom-select mb-4">
            <option value="" selected="">Select State</option>
            <option value="1" selected="">Kerala</option>
            <option value="2">Tamilnadu</option>
            <option value="3">Karnataka</option>
          </select>

               </div>
            </div>
            <div class="col-md-6 frm-drp"><div class="form-group mb-2">
                <label>City<span style="color: #cc0202;">*</span></label>
                   <select class="browser-default custom-select mb-4">
            <option value="" selected="">Select City</option>
            <option value="1" selected="">Kasargod</option>
            <option value="2">Kozhikode</option>
            <option value="3">Malappuram</option>
          </select>

               </div>
            </div>

           
        <div class="col-md-12 frm-txt-area" data-for="message"><div class="form-group mb-2">
             <label>Address<span style="color: #cc0202;">*</span></label>
                                <textarea class="form-control input" name="message" rows="3" data-form-field="Message" placeholder="Address" style="resize:none; background-color: #e8e8e8; border: 1px solid #09c976;" id="message-form4-4v"></textarea>
                            </div>
            </div>
            <div class="col-md-6 frm-lyt"><div class="form-group mb-2">
          <label for="inputZip" class="active">Pin Code<span style="color: #cc0202;">*</span></label>
          <input type="text" class="form-control" id="inputZip" placeholder="673-633">
        </div></div>




<div class="col-md-6"><div class="form-group mb-2">
             
              <div class="input-group">
                <label style="color: #6f6f6f; font-size: 14px;" class="label">Gender<span style="color: #cc0202;">*</span></label>
                <div class="p-t-10">
                  <label style="color: #6f6f6f; font-weight: normal;" class="radio-container m-r-45">Male
                    <input type="radio" checked="checked" name="gender">
                    <span class="checkmark"></span> </label>
                  <label style="color: #6f6f6f; font-weight: normal;" class="radio-container">Female
                    <input type="radio" name="gender">
                    <span class="checkmark"></span> </label>
                </div>
              </div>
            </div>
          
            </div>
<h4>Preferred mode of Contact<span style="color: #cc0202;">*</span></h4>
</div>
<div class="row social">
    <div class="col-md-4 whtsap"><button type="button" class="btn btn-primary"><i class="fab fa-whatsapp"></i>Whatsapp</button></div>
    <div class="col-md-4 mail"><button type="button" class="btn btn-primary"><i class="fas fa-paper-plane"></i>E-mail</button></div>
    <div class="col-md-4 mobile"><button type="button" class="btn btn-primary"><i class="fas fa-mobile-alt"></i>Phone</button></div>

</div>
<div class="row">
        <div class="col-md-6 frm-lyt"><div class="form-group mt-5 mb-2">
                  <label>Institution Name</label>
                  <input type="text" class="form-control" placeholder="Institution Name">
                </div></div>
<div class="col-md-6 frm-lyt"><div class="form-group mt-5 mb-2">
                  <label>Place</label>
                  <input type="text" class="form-control" placeholder="Location Of The Institute">
                </div></div>
               <div class="col-md-6 frm-drp"><div class="form-group mb-2">
                <label>Graduation Date (Expected Completion)</label>
                   <select class="browser-default custom-select mb-4">
            <option value="" selected="">Select Date</option>
            <option value="1" selected="">India</option>
            <option value="2">Brazil</option>
            <option value="3">China</option>
          </select>

               </div>
            </div>
            <div class="col-md-6 frm-drp">
            </div>
            

             <div class="col-md-6 frm-drp"><div class="form-group mb-2">
                <label>Graduation Type</label>
                   <select class="browser-default custom-select mb-4">
            <option value="" selected="">Graduation Type</option>
            <option value="1" selected="">India</option>
            <option value="2">Brazil</option>
            <option value="3">China</option>
          </select>

               </div>
            </div>
            <div class="col-md-6 frm-drp"><div class="form-group mb-2">
                <label>Stream</label>
                   <select class="browser-default custom-select mb-4">
            <option value="" selected="">Stream</option>
            <option value="1" selected="">Kerala</option>
            <option value="2">Tamilnadu</option>
            <option value="3">Karnataka</option>
          </select>

               </div>
            </div>
            <div class="col-md-6 frm-drp"><div class="form-group mb-2">
                <label>Major Type</label>
                   <select class="browser-default custom-select mb-4">
            <option value="" selected="">Major Type</option>
            <option value="1" selected="">India</option>
            <option value="2">Brazil</option>
            <option value="3">China</option>
          </select>

               </div>
            </div>
            <div class="col-md-6 frm-drp"><div class="form-group mb-2">
                <label>Stream</label>
                   <select class="browser-default custom-select mb-4">
            <option value="" selected="">Stream</option>
            <option value="1" selected="">Kerala</option>
            <option value="2">Tamilnadu</option>
            <option value="3">Karnataka</option>
          </select>

               </div>
            </div>



</div>
<div class="form-group upld-btn">
    <label>Upload Resume</label><br>
<label class="btn btn-primary">
                Upload<i class="fas fa-upload"></i> <input type="file" style="display: none;">
            </label>
</div>
<div class="row"><div class="col-md-12"><div class="form-group mb-2">
             
              <div class="custom-control custom-checkbox">
            <input type="checkbox" class="custom-control-input" id="defaultRegisterFormNewsletter">
            <label style="font-weight: normal;" class="custom-control-label" for="defaultRegisterFormNewsletter">I would like to do join in the ITPWCS student chapter<br> and the agree the following <span style="text-decoration: underline;">Terms and conditions</span></label>
          </div>
          
            </div>

</div> 
<div class="sub-btn mt-5 mb-5" style="margin: auto;">
<button class="btn btn-primary" type="submit" style="background-color: #09c976; border-radius: 30px; border: 1px #9f9f9f solid; text-transform: none; line-height: 40px; padding: 0px 30px; margin: auto;">Submit</button>
        </div>

</div>

</div>
         
  </div>
</div>

          </div>
          <!--/.Panel 2-->

          <!--Panel 3-->
          <div class="tab-pane fade" id="panel13" role="tabpanel">
            <br>

            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nihil odit magnam minima, soluta doloribus
              reiciendis molestiae placeat unde eos molestias. Quisquam aperiam, pariatur. Tempora, placeat ratione
              porro voluptate odit minima.</p>

          </div>
          <!--/.Panel 3-->

          <!--Panel 4-->
          <div class="tab-pane fade" id="panel14" role="tabpanel">
            <br>

            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nihil odit magnam minima, soluta doloribus
              reiciendis molestiae placeat unde eos molestias. Quisquam aperiam, pariatur. Tempora, placeat ratione
              porro voluptate odit minima.</p>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nihil odit magnam minima, soluta doloribus
              reiciendis molestiae placeat unde eos molestias. Quisquam aperiam, pariatur. Tempora, placeat ratione
              porro voluptate odit minima.</p>

          </div>
          <!--/.Panel 4-->

        </div>


      </div>
      <!--Grid column-->

    </div>
    <!--Grid row-->

  </div>




 
           
           
    
    <?php include 'footer.php';?>


        <!-- end footer -->
        <!-- start scroll to top -->
        <a class="scroll-top-arrow" href="javascript:void(0);"><i class="ti-arrow-up"></i></a>

        <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
      
        <!-- end scroll to top  -->
        <!-- javascript libraries -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/modernizr.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/bootstrap.bundle.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.easing.1.3.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/skrollr.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/smooth-scroll.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.appear.js"></script>
        <!-- menu navigation -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/bootsnav.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.nav.js"></script>
        <!-- animation -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/wow.min.js"></script>
        <!-- page scroll -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/page-scroll.js"></script>
        <!-- swiper carousel -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/swiper.min.js"></script>
        <!-- counter -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.count-to.js"></script>
        <!-- parallax -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.stellar.js"></script>
        <!-- magnific popup -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.magnific-popup.min.js"></script>
        <!-- portfolio with shorting tab -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/isotope.pkgd.min.js"></script>
        <!-- images loaded -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/imagesloaded.pkgd.min.js"></script>
        <!-- pull menu -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/classie.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/hamburger-menu.js"></script>
        <!-- counter  -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/counter.js"></script>
        <!-- fit video  -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.fitvids.js"></script>
        <!-- skill bars  -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/skill.bars.jquery.js"></script> 
        <!-- justified gallery  -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/justified-gallery.min.js"></script>
        <!--pie chart-->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/jquery.easypiechart.min.js"></script>
        <!-- instagram -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/instafeed.min.js"></script>
        <!-- retina -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/retina.min.js"></script>
        <!-- revolution -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/revolution/js/jquery.themepunch.tools.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/revolution/js/jquery.themepunch.revolution.min.js"></script>
        <!-- revolution slider extensions (load below extensions JS files only on local file systems to make the slider work! The following part can be removed on server for on demand loading) -->
        <!--<script type="text/javascript" src="revolution/js/extensions/revolution.extension.actions.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.carousel.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.kenburn.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.layeranimation.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.migration.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.navigation.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.parallax.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.slideanims.min.js"></script>
        <script type="text/javascript" src="revolution/js/extensions/revolution.extension.video.min.js"></script>-->
        <!-- setting -->
        <script type="text/javascript" src="<?php echo base_url() ?>maintemp/js/main.js"></script>

<script>

$(function() {

  // We can attach the `fileselect` event to all file inputs on the page
  $(document).on('change', ':file', function() {
    var input = $(this),
        numFiles = input.get(0).files ? input.get(0).files.length : 1,
        label = input.val().replace(/\\/g, '/').replace(/.*\//, '');
    input.trigger('fileselect', [numFiles, label]);
  });

  // We can watch for our custom `fileselect` event like this
  $(document).ready( function() {
      $(':file').on('fileselect', function(event, numFiles, label) {

          var input = $(this).parents('.input-group').find(':text'),
              log = numFiles > 1 ? numFiles + ' files selected' : label;

          if( input.length ) {
              input.val(log);
          } else {
              if( log ) alert(log);
          }

      });
  });
  
});

</script>



<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.js"></script>
<script>$(function () {
  $("#datepicker").datepicker({ 
        autoclose: true, 
        todayHighlight: true
  }).datepicker('update', new Date());
});</script>



<script type="text/javascript">
    
function resetActive(event, percent, step) {
        $(".progress-bar").css("width", percent + "%").attr("aria-valuenow", percent);
        $(".progress-completed").text(percent + "%");

        $("div").each(function () {
            if ($(this).hasClass("activestep")) {
                $(this).removeClass("activestep");
            }
        });

        if (event.target.className == "col-md-2") {
            $(event.target).addClass("activestep");
        }
        else {
            $(event.target.parentNode).addClass("activestep");
        }

        hideSteps();
        showCurrentStepInfo(step);
    }

    function hideSteps() {
        $("div").each(function () {
            if ($(this).hasClass("activeStepInfo")) {
                $(this).removeClass("activeStepInfo");
                $(this).addClass("hiddenStepInfo");
            }
        });
    }

    function showCurrentStepInfo(step) {        
        var id = "#" + step;
        $(id).addClass("activeStepInfo");
    }



</script>
    </body>
</html>