<?php 
 
 print_r($student_data);

?>


<?php $this->view("includes/inc_page_head_".$user_role);?>
<!--beginPage Styles -->
<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>template/assets/vendors/custom/DataTables/datatables.min.css"/>
<link href="<?php echo base_url() ?>template/main/plugins/bootstrap-summernote/summernote.css" rel="stylesheet" type="text/css" />
<!-- beginBody -->
<div class="m-grid__item m-grid__item--fluid m-grid m-grid--hor-desktop m-grid--desktop m-body">
    <div class="m-grid__item m-grid__item--fluid  m-grid m-grid--ver	m-container m-container--responsive m-container--xxl m-page__container">
        <div class="m-grid__item m-grid__item--fluid m-wrapper">
            <!-- BEGIN: Subheader -->
            <div class="m-subheader ">
                <div class="d-flex align-items-center">
                    <div class="mr-auto">
                        <h3 class="m-subheader__title m-subheader__title--separator">
                            Student
                        </h3>
                        <ul class="m-subheader__breadcrumbs m-nav m-nav--inline">
                            <li class="m-nav__item m-nav__item--home">
                                <a href="<?php echo base_url()?>dashboard" class="m-nav__link m-nav__link--icon">
                                    <i class="m-nav__link-icon la la-home"></i>
                                </a>
                            </li>
                            <li class="m-nav__separator">
                                -
                            </li>
                            <li class="m-nav__item">
                                <a href="" class="m-nav__link">
											<span class="m-nav__link-text">
												View
											</span>
                                </a>
                            </li>
                            <li class="m-nav__separator">
                                -
                            </li>
                            <li class="m-nav__item">
                                <a href="" class="m-nav__link">
											<span class="m-nav__link-text">
												Students
											</span>
                                </a>
                            </li>
                        </ul>
                    </div>
                    <div style="max-width: 800px">
                        <?php if ($this->session->flashdata('flashdata_msg') != "")
                        {?>
                            <div class="alert alert-<?php echo $this->session->flashdata('alert_type')?> alert-dismissible fade show   m-alert m-alert--air m-alert--outline m-alert--outline-2x" role="alert">
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>
                                <strong>
                                    <?php echo $this->session->flashdata('flashdata_title')?>
                                </strong>
                                <?php echo $this->session->flashdata('flashdata_msg')?>
                            </div>
                        <?php } ?>
                    </div>
                </div>
            </div>
            <!-- END: Subheader -->
            <div class="m-content">
                <div class="m-portlet m-portlet--mobile m-portlet--mobile m-portlet--info m-portlet--head-solid-bg m-portlet--bordered m-portlet--rounded">
                    <div class="m-portlet__head">
                        <div class="m-portlet__head-caption">
                            <div class="m-portlet__head-title">
                                <h3 class="m-portlet__head-text">
                                    List of Students
                                </h3>
                            </div>
                        </div>
                        <div class="m-portlet__head-tools">

                        </div>
                    </div>
                    <div class="m-portlet__body">
                        <!--begin: Search Form -->
                       
                        <!--end: Search Form -->
                        <!--begin: Datatable -->
                       <!--  <style>
                        	table,td,th{
                        		border-collapse: collapse;
                        		border: 1px solid;
                        	}
                        	th,td{
                        		padding: 2px 5px;
                        	}
                        	
                        </style> -->
                       <div class="card pt-5">

                        <div class="ml-auto pb-5 pr-5">
                            
                            <a  href="<?php echo base_url().$user_directory.'students'?>" class="m-menu__link m-menu__toggle">
                             <button type="button" class="btn btn-info ">Back</button>
                         </a>
                            
                        </div>
                        <div class="card pt-5 pb-5" >
                            
                       
                        <center>
                   
                        <table  class="table col-lg-6" style="position: center; width: 50%">
                        	
                        
                        	
                        
                        	

                        	<tbody>
                        		<tr>
                        			<th>Name</th>
                        			<td>     <?= $student_data['name']; ?></td>
                        		</tr>
                        		<tr>
                        			<th>Email	</th>
                        			<td>     <?= $student_data['email']; ?></td>
                        		</tr>
                        		<tr>
                        			<th>Organization_Name	</th>
                        			<td>     <?= $student_data['organization_name']; ?></td>
                        		</tr>

                        		<tr>
                        			<th>Job	</th>
                        			<td>     <?= $student_data['job_title']; ?></td>
                        		</tr>

                        		<tr>
                        			<th>Date Of Birth	</th>
                        			<td>     <?= $student_data['dob']; ?></td>
                        		</tr>

                        		<tr>
                        			<th>Country	</th>
                        			<td>     <?= $student_data['country']; ?></td>
                        		</tr>

                        		<tr>
                        			<th>State	</th>
                        			<td>     <?= $student_data['state']; ?></td>
                        		</tr>

                        		<tr>
                        			<th>City	</th>
                        			<td>     <?= $student_data['city']; ?></td>
                        		</tr>
                                
                                <tr>
                        			<th>Address	</th>
                        			<td>     <?= $student_data['address']; ?></td>
                        		</tr>

                        		 <tr>
                        			<th>Pincode	</th>
                        			<td>     <?= $student_data['pincode']; ?></td>
                        		</tr>



                                 <tr>
                                    <th>Gender </th>
                                    <td>     <?= $student_data['gender']; ?></td>
                                </tr>
                                 <tr>
                                    <th>Preferred Mode Of Contact </th>
                                    <td>     <?= $student_data['preferred_mode_of_contact']; ?></td>
                                </tr>

                                 <tr>
                                    <th>Institution Name </th>
                                    <td>     <?= $student_data['institution_name']; ?></td>
                                </tr>

                                 <tr>
                                    <th>Place </th>
                                    <td>     <?= $student_data['place']; ?></td>
                                </tr>

                                 <tr>
                                    <th>Graduation Date </th>
                                    <td>     <?= $student_data['graduation_date']; ?></td>
                                </tr>

                                 <tr>
                                    <th>Graduation Type </th>
                                    <td>     <?= $student_data['graduation_type']; ?></td>
                                </tr>

                                 <tr>
                                    <th>Stream </th>
                                    <td>     <?= $student_data['stream']; ?></td>
                                </tr>

                                 <tr>
                                    <th>Major Type </th>
                                    <td>     <?= $student_data['major_type']; ?></td>
                                </tr>

                                 <tr>
                                    <th>Major Stream </th>
                                    <td>     <?= $student_data['major_stream']; ?></td>
                                </tr>

                                 <tr>
                                    <th>Resume </th>
                                    <td>     <?= $student_data['resume']; ?></td>
                                </tr>

                                

                                

                                 

                        		





                        	</tbody>
                        </table>
                         </center>
                    </div>
                     </div>
                       

                        <!--end: Datatable -->

                       

                       

                       
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- endBody -->
<?php $this->view("includes/inc_footer");?>

</div>
<!-- end Page -->
<!-- beginQuick Sidebar -->
<?php $this->view("includes/inc_sidebar");?>
<!-- endQuick Sidebar -->
<?php $this->view("includes/inc_quick_navigation");?>
<!--beginBase Scripts -->
<?php $this->view("includes/inc_scripts");?>
<script src="<?php echo base_url() ?>template/main/plugins/bootstrap-summernote/summernote.min.js" type="text/javascript"></script>
<script type="text/javascript" src="<?php echo base_url()?>template/assets/vendors/custom/DataTables/datatables.min.js"></script>
<script>
    // Menu Active
    $("#menu_student").addClass('m-menu__item--active');


</script>
<script>


    $('#summernote_3').summernote({height: 300});
</script>
<!--beginPage Snippets -->
<?php $this->view("custom_scripts/student_scripts");?>
<!--endPage Snippets -->