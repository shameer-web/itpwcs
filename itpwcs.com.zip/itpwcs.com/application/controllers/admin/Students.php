<?php
class Students extends CI_Controller{

    public $page_data=array();
    function __construct()
    {
        parent::__construct();
        //Calling Initial Functions
        $this->initial();
    }

    public function initial()
    {
        ini_set('max_execution_time', 5000);
        ini_set("memory_limit", "-1");
        date_default_timezone_set('Asia/Kolkata');
        $this->load->model('User_model','User');
        $this->load->model('Students_model','Students');

        //        Check User Logged in or Not
        if($this->User->is_logged_in('admin')==false){
            redirect(base_url(), 'refresh');
        }
//        File Directory
        $this->page_data['user_role'] = $this->session->userdata('type');
        $this->page_data['user_directory'] = $this->session->userdata('type')."/";
        $this->page_data['directory'] = "students";
    }
    public function index()
    {
        $this->view();
    }
    public function view()
    {
        $this->page_data['page_name'] = 'students';
        $this->load->view('Index',$this->page_data);
    }
    public function select()
    {
        $json_data=array();
        $j=0;

        $data['delete_status'] = 0;
        $result = $this->Students->select_students($data);
        $result_array=$result->result();

        $json_data['draw']=5;
        $json_data['recordsTotal']=$result->num_rows();
        $json_data['recordsFiltered']=$result->num_rows();
        $array=array();


        
        foreach($result_array as $row):

            $btn_view='<a style="margin-left: 5px;margin-right: 5px" id="news_delete_btn" href="students/views/'.$row->id.'"  class="btn btn-info m-btn m-btn--icon  m-btn--icon-only  m-btn--pill m-btn--air">
                            <i class="la la-eye"></i>
                        </a>';

                        $btn_delete='<a style="margin-left: 5px;margin-right: 5px" id="students_delete_btn" href="#students_delete_modal" data-toggle="modal" class="btn btn-danger m-btn m-btn--icon  m-btn--icon-only  m-btn--pill m-btn--air">
                            <i class="la la-trash"></i>
                        </a>';
           
           


            $array[$j][]=$row->id;
            $array[$j][]=$row->name;
            $array[$j][]=$row->email;
            $array[$j][] =$row->organization_name;
            $array[$j][]=$row->job_title;
            $array[$j][]= $row->country; 
            $array[$j][]=$row->state;
            $array[$j][]=$row->address;
            $array[$j][]=$btn_view.$btn_delete; 


            $j++;
        endforeach;


        $json_data['data']=$array;
        echo json_encode($json_data);  // send data as json format
    }
    public function create()
    {
       
    }
    public function update()
    {
        
         $data['id'] = $this->security->xss_clean($this->input->post('id'));
        
        $data['created_date'] = date('Y-m-d H:i:s');
       


        $result=$this->Students->update_students($data);
        if($result==1)
        {
            $flash_data['flashdata_msg'] = 'Students details Updated Successfully!';
            $flash_data['flashdata_type'] = 'info';
            $flash_data['alert_type'] = 'info';
            $flash_data['flashdata_title'] = 'Success !';
        } else {
            $flash_data['flashdata_msg'] = 'Sorry.. There Have been Some Error Occurred. Please Try Again!';
            $flash_data['flashdata_type'] = 'error';
            $flash_data['alert_type'] = 'danger';
            $flash_data['flashdata_title'] = 'Error !!';
        }
        $this->session->set_flashdata($flash_data);
        redirect(base_url() . $this->page_data['user_directory'].'/students', 'refresh');

    }
    public function delete()
    { 
         print_r($this->input->post('deleteid'));
          $data['id'] = $this->security->xss_clean($this->input->post('deleteid'));
        $data['delete_status']=1;
        $result=$this->Students->update_students($data);
        if($result==1)
        {
            $flash_data['flashdata_msg'] = 'Students details Deleted Successfully!';
            $flash_data['flashdata_type'] = 'error';
            $flash_data['alert_type'] = 'danger';
            $flash_data['flashdata_title'] = 'Error !';
        } else {
            $flash_data['flashdata_msg'] = 'Sorry.. There Have been Some Error Occurred. Please Try Again!';
            $flash_data['flashdata_type'] = 'error';
            $flash_data['alert_type'] = 'danger';
            $flash_data['flashdata_title'] = 'Error !!';
        }
        $this->session->set_flashdata($flash_data);
        redirect(base_url() . $this->page_data['user_directory'].'/students', 'refresh');
    }

     public function views()
    {

        $id = $this->uri->segment(4);
      //  print_r($product_id);
        $data['delete_status'] = 0;
        $data['id']= $id;
        $result = $this->Students->select_students($data);
        $result=$result->row_array();
     //   print_r($result);
        $this->page_data['student_data']=$result;

        $this->page_data['page_name'] = 'single_student';
        $this->load->view('Index',$this->page_data);
    }
}
