<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Main extends CI_Controller {

    function __construct() {
        parent::__construct();

    }

    //Default function, redirects to logged in user area
    public function index(){

        $this->home();
    }
    public function home() {

        $this->load->view('main/home');
    }


    public function about(){
       $this->load->view('main/about'); 
    }


    public function contact(){
       $this->load->view('main/contact');  
    }

    public function membership(){
      $this->load->view('main/membership');  
    }


    public function already_member(){
      $this->load->view('main/already-member');  
    }


    public function students(){
      $this->load->view('main/students');  
    }


    public function general(){
      $this->load->view('main/general');  
    }



    public function general_form(){
      $this->load->view('main/general-form');  
    }

    public function proffesional_form(){
      $this->load->view('main/proffesional-form');  
    }


     public function corporates(){
      $this->load->view('main/corporates');  
    }


     public function corporates_form(){
      $this->load->view('main/corporates-form');  
    }


     public function whatisbmit(){
      $this->load->view('main/whatisbmit');  
    }


     public function bmp(){
      $this->load->view('main/bmp');  
    }


     public function bms(){
      $this->load->view('main/bms');  
    }


     public function smart_hiring(){
      $this->load->view('main/smart-hiring');  
    }

     public function intelligent_campus(){
      $this->load->view('main/intelligent-campus');  
    }

     public function kyw_program(){
      $this->load->view('main/kyw-program');  
    }

     public function job_portal(){
      $this->load->view('main/job-portal');  
    }

     public function webinar(){
      $this->load->view('main/webinar');  
    }

    //  public function ondemand_webinar(){
    //   $this->load->view('main/ondemand-webinar');  
    // }

    public function seminars(){
      $this->load->view('main/seminars');  
    }

    public function college_seminar(){
      $this->load->view('main/webinacollege-seminar');  
    }

    public function professional(){
      $this->load->view('main/professional');  
    }

     public function ondemand_webinar(){
      $this->load->view('main/ondemand-webinar');  
    }

     public function header(){
      $this->load->view('main/header');  
    }

     public function footer(){
      $this->load->view('main/footer');  
    }

   
   

    

   

    

   


    public function stdntmfrm()
    {
        $this->load->view('main/stdntmfrm');
    }

    public function insert_stdntmfrm(){



                    // session_start();
                $this->load->helper(array('form','url'));
                $this->load->library('form_validation');
                $this->load->library('upload');
                $this->load->library('image_lib');


                $this->form_validation->set_rules("product_name"," product_name","required");
                $this->form_validation->set_rules('category_name','category_name','required');
                $this->form_validation->set_rules('description','description','required');
                $this->form_validation->set_rules('prize','prize','required');
                // $this->form_validation->set_rules('file','Photo','validate_image['.$_FILES['file']['size'].']');

              if($this->form_validation->run()== FALSE)
               {

                   //$this->load->view('form');  
                $this->load->view('main/stdntmfrm');
                }
              else
               {
                   if( $this->input->post('submit'))

                     {
                        $this->load->library('resume');
                        $this->load->library('image_lib');
                   if($_FILES['file']['size']!=0)

                     {
                  
                        $upload_path='assets/image';

                        $config['upload_path'] =$upload_path;
                        $config['allowed_types'] = 'gif|jpg|png|jpeg|img|JPG|PNG|PDF';
                        $config['max_size'] = '1048576';
                        $config['max_width'] = '0';
                        $config['max_height'] = '0';
                        $config['encrypt_name']  = FALSE;
                        $config['remove_spaces']  = TRUE;
                        $config['overwrite']  = FALSE;
                        $config['quality'] = 100;

                         $this->upload->initialize($config);
                   if(!$this->upload->do_upload('file'))
                         {
                             echo  $this->upload->display_errors();exit();
                                    $image="";
                         }
                         else
                         {
                            $up_data= $this->upload->data();
                            $image= $up_data['file_name'];
                         }

                }
               

                        $data=['name'=>$this->input->post('name'),
                        'email'=>$this->input->post('email'),
                        'organization_name'=>$this->input->post('organization_name'),
                        'job_title'=>$this->input->post('job_title'),
                        'dob'=>$this->input->post('dob'),
                        'country'=>$this->input->post('country'),'state'=>$this->input->post('state'),'city'=>$this->input->post('city'),'address'=>$this->input->post('address'),'pincode'=>$this->input->post('pincode'),'gender'=>$this->input->post('gender'),'preferred_mode_of_contact'=>$this->input->post('preferred_mode_of_contact'),'institution_name'=>$this->input->post('institution_name'),'place'=>$this->input->post('place'),'graduation_date'=>$this->input->post('graduation_date'),'graduation_type'=>$this->input->post('graduation_type'),'stream'=>$this->input->post('stream'),'major_type'=>$this->input->post('major_type'),'major_stream'=>$this->input->post('major_stream'),
                            'resume'=>$image

                        
                    ];  
                
                   // $user_data=$data['product_name'];

                    
                $result=$this->Main_model->save_stdntmfrm($data); 
                if($result)

                {
                    
                   // $a=$this->session->set_userdata('session_var',$user_data);

          
                // $this->index();
                    echo "succesfully upload";
                }
                else
                {
                    echo "failed";
                }
            }
            
        }

    }
}